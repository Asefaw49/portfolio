<?php
include 'header.php';
include 'db.php';

// Check if user is a regular User
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'User') {
    header("Location: login.php"); // Redirect to login if not a user
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the form submission
    if (isset($_POST['submit_request'])) {
        $asset_code = intval($_POST['asset_code']); // Sanitize input
        $reason = htmlspecialchars($_POST['reason']);
        $issue_date = $_POST['issue_date']; // Assuming the date is valid
        $user_id = $_SESSION['UserID'];

        // 1. Check if the AssetCode exists in the 'asset' table
        $check_sql = "SELECT AssetCode FROM asset WHERE AssetCode = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $asset_code);
        $check_stmt->execute();
        $check_stmt->store_result(); // Store the result to check the number of rows
        $asset_exists = $check_stmt->num_rows > 0;
        $check_stmt->close();

        if ($asset_exists) {
            // 2. If the AssetCode exists, proceed with the insert
            $sql = "INSERT INTO transfer (AssetCode, UserID, Reason, IssueDate, ToOwnerFirstName, ToOwnerLastName, FromOwnerFirstName, FromOwnerLastName, Quantity, Observer)
                    VALUES (?, ?, ?, ?, '', '', '', '', 1, '')"; // Simplified for demonstration
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iiss", $asset_code, $user_id, $reason, $issue_date); // Corrected parameters

            if ($stmt->execute()) {
                echo "<p class='success'>Asset request submitted successfully!</p>";
            } else {
                echo "<p class='error'>Error submitting request: " . $conn->error . "</p>";
            }
            $stmt->close();
        } else {
            // 3. If the AssetCode does NOT exist, display an error message
            echo "<p class='error'>Error: Invalid Asset Code. Asset code does not exist.</p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Asset</title>
    <style>
        /* Basic reset for margin, padding, and box-sizing */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: white;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        h2 {
            text-align: center;
            font-size: 28px;
            color: black;
            margin-bottom: 20px;
        }

        /* Form container */
        form {
            width: 100%;
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        label {
            font-size: 16px;
            color: black;
            margin-bottom: 5px;
        }

        input[type="number"],
        input[type="date"],
        textarea {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
        }

        input[type="submit"] {
            width: 100%;
            padding: 14px;
            background-color: black; /* Button color changed to black */
            color: white;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #333; /* Darker shade on hover */
        }

        .error {
            color: red;
            font-size: 16px;
            margin-top: 15px;
        }

        .success {
            color: green;
            font-size: 16px;
            margin-top: 15px;
        }

        /* Link styling */
        a {
            display: inline-block;
            text-decoration: none;
            color: black;
            font-size: 16px;
            margin-top: 20px;
            text-align: center;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Footer */
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

    <h2>Request Asset</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="asset_code">Asset Code:</label>
        <input type="number" id="asset_code" name="asset_code" required>

        <label for="reason">Reason for Request:</label>
        <textarea id="reason" name="reason" rows="4" required></textarea>

        <label for="issue_date">Issue Date:</label>
        <input type="date" id="issue_date" name="issue_date" required>

        <input type="submit" name="submit_request" value="Submit Request">
        <a href="user_dashboard.php">Back to Dashboard</a>
    </form>
    
    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Asset Management System</p>
    </footer>
</body>
</html>