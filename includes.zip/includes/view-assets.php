<?php
include 'header.php';
include 'db.php';
// Check if user is a regular User
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'User') {
    header("Location: login.php"); // Redirect to login if not a user
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>View Assets</title>
    <style>
    :root {
        --primary-color:#ffff
        --secondary-color: #3498db;
        --dark-color: #2c3e50;
        --light-color: #ecf0f1;
        --text-color: #000000; /* All text black */
    }

    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        line-height: 1.6;
        color: var(--text-color);
        background-color: #f9f9f9;
        display: flex;
        flex-direction: column;
    }

    .content-wrapper {
        flex: 1;
        padding: 20px;
    }

    h2 {
        text-align: center;
        color: var(--dark-color);
        margin: 25px 0;
        font-size: 28px;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin: 25px 0;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    }

    th, td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #dddddd;
    }

    th {
        background-color: var(--primary-color);
        color: white;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    tr:nth-child(even) {
        background-color: #f3f3f3;
    }

    tr:hover {
        background-color: #e9e9e9;
    }

    .back-link {
        display: inline-block;
        margin-top: 20px;
        padding: 10px 20px;
        background-color: var(--dark-color);
        color: white;
        text-decoration: none;
        border-radius: 4px;
        transition: all 0.3s ease;
    }

    .back-link:hover {
        background-color: #1a252f;
        transform: translateY(-2px);
    }

    footer {
        text-align: center;
        padding: 20px;
        background-color: var(--dark-color);
        color: white;
        font-size: 14px;
        width: 100%;
    }

    /* Responsive table */
    @media screen and (max-width: 768px) {
        table {
            display: block;
            overflow-x: auto;
            white-space: nowrap;
        }
        
        th, td {
            padding: 8px 10px;
        }
    }
</style>
</head>
<body>
    <div class="content-wrapper">
        <h2>Available Assets</h2>
        <?php
        $sql = "SELECT AssetCode, AssetName, ModelName, Type, Quantity, Status, ExpiryDate FROM asset WHERE Status = 'Active'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Asset Code</th><th>Asset Name</th><th>Model Name</th><th>Type</th><th>Quantity</th><th>Status</th><th>Expiry Date</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row["AssetCode"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["AssetName"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["ModelName"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["Type"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["Quantity"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["Status"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["ExpiryDate"]) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No available assets found.</p>";
        }
        ?>
    
    </div>
    
    <footer>
        &copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.
    </footer>
</body>
</html>