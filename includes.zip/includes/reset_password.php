<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST["token"];
    $new_password = $_POST["new_password"];

    // Validate token
    $stmt = $conn->prepare("SELECT email FROM password_reset WHERE token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $email = $row['email'];

        // Update user password (Consider hashing passwords in a real application)
        $update = $conn->prepare("UPDATE user SET Password = ? WHERE Email = ?");
        $update->bind_param("ss", $new_password, $email);
        $update->execute();

        echo "<p class='success'>Password reset successfully!</p>";

        // Remove token from database
        $delete = $conn->prepare("DELETE FROM password_reset WHERE token = ?");
        $delete->bind_param("s", $token);
        $delete->execute();
    } else {
        echo "<p class='error'>Invalid or expired token.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <style>
        /* General styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: white;
            padding: 20px;
            width: 350px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            color: #4CAF50;
            margin-bottom: 15px;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .success {
            color: green;
            font-size: 14px;
            margin-bottom: 10px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 16px;
            margin-bottom: 5px;
            text-align: left;
            color: #333;
        }

        input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 10px;
            width: 100%;
        }

        .input-group {
            position: relative;
        }

        .input-group i {
            position: absolute;
            right: 10px;
            top: 12px;
            cursor: pointer;
            color: #777;
        }

        .password-hint {
            font-size: 12px;
            color: #666;
            text-align: left;
            margin-bottom: 10px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            padding: 12px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Reset Password</h2>
    
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" onsubmit="return validatePassword()">
        <input type="hidden" name="token" value="<?php echo $_GET['token']; ?>">

        <label for="new_password">New Password:</label>
        <div class="input-group">
            <input type="password" id="new_password" name="new_password" required>
            <i onclick="togglePasswordVisibility()" id="toggleIcon">👁️</i>
        </div>

        <p class="password-hint">Password must be at least 6 characters.</p>

        <input type="submit" value="Reset Password">
    </form>
</div>

<script>
    function validatePassword() {
        var password = document.getElementById("new_password").value;

        if (password.length < 6) {
            alert("Password must be at least 6 characters long.");
            return false;
        }
        return true;
    }

    function togglePasswordVisibility() {
        var passwordField = document.getElementById("new_password");
        var toggleIcon = document.getElementById("toggleIcon");

        if (passwordField.type === "password") {
            passwordField.type = "text";
            toggleIcon.textContent = "🙈"; // Change icon
        } else {
            passwordField.type = "password";
            toggleIcon.textContent = "👁️"; // Change icon back
        }
    }
</script>

</body>
</html>
