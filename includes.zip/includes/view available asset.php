<?php
include 'header.php';
include 'db.php';

// Check if user is an Administrator
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Manager') {
    header("Location: login.php"); // Redirect to login if not an administrator
    exit();
}

$search = "";
if (isset($_POST['search'])) {
    $search = trim($_POST['search']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Assets</title>
    <style>
        /* General Page Styling */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background:white;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Header Styling */
        header {
            background-color:white;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 24px;
            position: relative;
        }

        .search-container {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
        }

        .search-container input[type="text"] {
            padding: 8px 12px;
            border-radius: 4px;
            border: none;
            width: 200px;
        }

        .search-container button {
            padding: 8px 12px;
            background-color: #4ca1af;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 5px;
        }

        /* Container for the content */
        .container {
            flex: 1; /* Push footer to the bottom */
            padding: 20px;
            text-align: center;
        }

        /* Table Styling */
        table {
            width: 100%;
            margin: 30px auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px 18px;
            text-align: left;
            font-size: 16px;
        }

        th { 
            background-color: #f9f9f9;
            color: black;
            position: sticky;
            top: 0;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
            transform: scale(1.01);
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            transition: all 0.2s ease;
        }

        /* Back Button */
        .back-button {
            margin-top: 30px;
            display: inline-block;
            text-align: center;
            background-color: #2c3e50;
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s ease;
        }
        /* Footer Styling */
        footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 30px;
        }

        footer p {
            font-size: 14px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }

            header {
                padding-bottom: 60px;
            }

            .search-container {
                position: static;
                transform: none;
                margin-top: 15px;
                text-align: center;
            }

            table {
                font-size: 14px;
            }

            .back-button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <header>
        <h1>Available Assets</h1>
        <div class="search-container">
            <form method="post" action="">
                <input type="text" name="search" placeholder="Search assets..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
         
        </div>
    </header>

    
        <?php
        $sql = "SELECT AssetCode, AssetName, ModelName, Type, Quantity, Status, ExpiryDate FROM asset WHERE Status = 'Active'";
        
        if (!empty($search)) {
            $sql .= " AND (AssetCode LIKE '%" . $conn->real_escape_string($search) . "%' 
                      OR AssetName LIKE '%" . $conn->real_escape_string($search) . "%' 
                      OR ModelName LIKE '%" . $conn->real_escape_string($search) . "%' 
                      OR Type LIKE '%" . $conn->real_escape_string($search) . "%')";
        }
        
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo "<div style='overflow-x: auto;'>";
            echo "<table>";
            echo "<tr><th>Asset Code</th><th>Asset Name</th><th>Model Name</th><th>Type</th><th>Quantity</th><th>Status</th><th>Expiry Date</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row["AssetCode"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["AssetName"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["ModelName"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["Type"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["Quantity"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["Status"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["ExpiryDate"]) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
            echo "</div>";
        } else {
            echo "<p>No available assets found.</p>";
        }
        ?>
           </form>
        <a href="manager_dashboard.php" class="back-button">Back to Dashboard</a>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.</p>
    </footer>

</body>
</html>