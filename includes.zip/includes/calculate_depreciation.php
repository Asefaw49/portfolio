<?php 
include 'db.php';
include 'header.php';
?>

<!-- Internal CSS Styling -->
<style>
    :root {
        --primary-color:rgb(12, 14, 12);
        --secondary-color: #2c3e50;
        --bg-color: #f0f4f8;
        --text-color: #333;
        --white: #ffffff;
        --success-bg: #e6ffe6;
    }

    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background-color: var(--bg-color);
        color: var(--text-color);
    }

    .container {
        max-width: 600px;
        margin: 60px auto;
        padding: 30px;
        background-color: var(--white);
        border-radius: 16px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
        animation: fadeIn 0.5s ease-in-out;
    }

    h2 {
        text-align: center;
        color: var(--primary-color);
        margin-bottom: 25px;
    }

    .form {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    label {
        font-weight: 600;
    }

    input[type="number"] {
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 16px;
        transition: border-color 0.3s;
    }

    input[type="number"]:focus {
        border-color: var(--primary-color);
        outline: none;
    }

    .submit-btn {
        padding: 12px;
        font-size: 16px;
        background-color: var(--primary-color);
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: background-color 0.3s, transform 0.2s;
    }

    .submit-btn:hover {
        background-color: #45a049;
        transform: scale(1.03);
    }

    .success-msg {
        margin-top: 20px;
        padding: 12px;
        background-color: var(--success-bg);
        border-left: 6px solid var(--primary-color);
        border-radius: 8px;
        font-weight: bold;
        text-align: center;
        color: var(--primary-color);
    }

    .back-link {
        display: block;
        margin-top: 30px;
        text-align: center;
        text-decoration: none;
        color: var(--secondary-color);
        font-weight: 600;
    }

    .back-link:hover {
        text-decoration: underline;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @media (max-width: 600px) {
        .container {
            margin: 30px 15px;
            padding: 20px;
        }

        input[type="number"], .submit-btn {
            font-size: 15px;
        }
    }
</style>

<?php
function calculateDepreciation($cost, $years, $method = 'linear') {
    return $method === 'linear' ? ($cost / $years) : 0;
}
?>

<div class="container">
    <h2>Calculate Depreciation</h2>
    <form method="post" action="" class="form">
        <label for="asset_cost">Asset Cost:</label>
        <input type="number" step="0.01" id="asset_cost" name="asset_cost" required>

        <label for="asset_years">Useful Life (Years):</label>
        <input type="number" id="asset_years" name="asset_years" required>

        <input type="submit" name="calculate" value="Calculate" class="submit-btn">
    </form>

    <?php
    if (isset($_POST['calculate'])) {
        $cost = floatval($_POST['asset_cost']);
        $years = intval($_POST['asset_years']);
        $depreciation = calculateDepreciation($cost, $years);
        echo "<p class='success-msg'>Annual Depreciation: $" . number_format($depreciation, 2) . "</p>";
    }
    ?>


</div>
