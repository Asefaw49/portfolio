<?php
include 'header.php';
include 'db.php';

if ($_SESSION['role'] !== 'Storekeeper') {
    header("Location: login.php");
    exit();
}

$asset = null;
$message = '';

if (isset($_POST['AssetCode'])) {
    $code = $_POST['AssetCode'];
    $stmt = $conn->prepare("SELECT * FROM asset WHERE AssetCode = ?");
    $stmt->bind_param("s", $code);
    $stmt->execute();
    $asset = $stmt->get_result()->fetch_assoc();
}

if (isset($_POST['update'])) {
    $stmt = $conn->prepare("UPDATE asset SET ModelName=?, AssetName=?, Quantity=?, Cost=?, Status=?, ExpiryDate=? WHERE AssetCode=?");
    $stmt->bind_param("ssissss", $_POST['ModelName'], $_POST['AssetName'], $_POST['Quantity'], $_POST['Cost'], $_POST['Status'], $_POST['ExpiryDate'], $_POST['AssetCode']);
    
    if ($stmt->execute()) {
        $message = "Asset updated successfully!";
    } else {
        $message = "Error updating asset: " . $stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Asset</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        input, button {
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            width: 100%;
        }

        input:focus, button:focus {
            outline: none;
            border-color: #4CAF50;
        }

        button {
            background-color: black;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .message {
            text-align: center;
            color: #4CAF50;
            font-weight: bold;
            margin-top: 20px;
        }

        .message.error {
            color: red;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group input {
            margin-bottom: 10px;
        }

        @media (max-width: 600px) {
            .container {
                margin: 20px;
                padding: 15px;
            }

            h2 {
                font-size: 1.5rem;
            }
        }

        footer {
            text-align: center;
            padding: 1rem;
            background: #1a1a1a;
            color: #ccc;
            font-size: 0.9rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Update Asset</h2>
    <form method="POST">
        <input type="text" name="AssetCode" placeholder="Enter Asset Code" required>
        <button type="submit">Fetch Asset</button>
    </form>

    <?php if ($asset): ?>
        <form method="POST">
            <input type="hidden" name="AssetCode" value="<?= htmlspecialchars($asset['AssetCode']) ?>">

            <div class="form-group">
                <input type="text" name="ModelName" value="<?= htmlspecialchars($asset['ModelName']) ?>" required placeholder="Model Name">
                <input type="text" name="AssetName" value="<?= htmlspecialchars($asset['AssetName']) ?>" required placeholder="Asset Name">
                <input type="number" name="Quantity" value="<?= htmlspecialchars($asset['Quantity']) ?>" required placeholder="Quantity">
                <input type="number" step="0.01" name="Cost" value="<?= htmlspecialchars($asset['Cost']) ?>" required placeholder="Cost">
                <input type="text" name="Status" value="<?= htmlspecialchars($asset['Status']) ?>" required placeholder="Status">
                <input type="date" name="ExpiryDate" value="<?= htmlspecialchars($asset['ExpiryDate']) ?>" required placeholder="Expiry Date">
            </div>
            <button type="submit" name="update">Update Asset</button>
        </form>
    <?php endif; ?>

    <?php if ($message): ?>
        <p class="message <?= strpos($message, 'Error') !== false ? 'error' : '' ?>"><?= $message ?></p>
    <?php endif; ?>
    
    <a href="storekeeper_dashboard.php" class="back-link">← Back to Dashboard</a>
</div>

<footer>
    &copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.
</footer>
</body>
</html>