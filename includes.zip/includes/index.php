<?php 
session_start(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Management System</title>

    <!-- Bootstrap + Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Navigation */
        .navbar {
            background-color: rgba(26, 26, 26, 0.9);
            backdrop-filter: blur(10px);
        }
        
        .navbar-brand {
            font-weight: bold;
            color:rgb(241, 247, 252) !important;
        }
        
        .nav-link {
            color: white !important;
            margin: 0 10px;
            transition: all 0.3s;
        }

        /* Hero Section */
        .hero-section {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            background-image: url('aku photo.jpg');
            background-size: cover;
            background-position: center;
            min-height: 80vh;
        }

        .hero-card {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            padding: 3rem;
            max-width: 600px;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .hero-card h1 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: white;
            text-shadow: 2px 2px 4px #000000;
        }

        .hero-card p {
            font-size: 1.1rem;
            margin-bottom: 2rem;
            line-height: 1.6;
            color: white;
            text-shadow: 2px 2px 4px #000000;
        }

        .btn-hero {
            background-color: #ffffff;
            color: #2c3e50;
            font-weight: bold;
            padding: 0.75rem 2rem;
            border-radius: 30px;
            font-size: 1.1rem;
            transition: all 0.3s ease;
        }

        .btn-hero:hover {
            background-color: #f1f1f1;
            transform: scale(1.05);
        }

        /* About and Contact Sections */
        .content-section {
            padding: 5rem 0;
            display: none;
        }
        
        .section-title {
            font-size: 2.5rem;
            margin-bottom: 2rem;
            color: #2c3e50;
            position: relative;
            padding-bottom: 15px;
        }
        
        .section-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: #ffd700;
        }
        
        .contact-info {
            margin-top: 30px;
        }
        
        .contact-item {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .contact-icon {
            font-size: 1.5rem;
            color: #ffd700;
            margin-right: 15px;
            width: 30px;
        }

        footer {
            text-align: center;
            padding: 1rem;
            background: #1a1a1a;
            color: #ccc;
            font-size: 0.9rem;
        }

        .hero-icon {
            font-size: 3rem;
            color: #ffd700;
            margin-bottom: 15px;
        }

        @media (max-width: 576px) {
            .hero-card {
                padding: 2rem 1.5rem;
            }

            .hero-card h1 {
                font-size: 2rem;
            }

            .btn-hero {
                font-size: 1rem;
            }
            
            .section-title {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <h3>Welcome to Web Based Property Management System</h3>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link home-link active" href="#"><i class="fas fa-home me-1"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link about-link" href="#"><i class="fas fa-info-circle me-1"></i> About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link contact-link" href="#"><i class="fas fa-envelope me-1"></i> Contact</a>
                    </li>
                    <li class="nav-item">
                        <a href="login.php" class="btn btn-hero ms-lg-3 mt-2 mt-lg-0">Login
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Home Section (Hero) -->
    <section class="hero-section" id="home-section">
             
       
          
         
        </div>
    </section>

    <!-- About Section -->
    <section class="content-section bg-light" id="about-section">
        <div class="container">
            <h2 class="section-title text-center">About Our System</h2>
            <div class="row">
                <div class="col-lg-6">

                    <p>The mission of this project is to design and implement a comprehensive web based Property Management System (PMS) 
                         for Aksum University that replaces the existing manual 
                         processes with an efficient, secure, and accessible digital solution. 
                         This system will enhance the accuracy, transparency, and accountability
                          in managing university assets and support the university's mission in education, research, 
                        and administration by ensuring optimal resource utilization.</p>
                    
                    
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="content-section" id="contact-section">
        <div class="container">
            <h2 class="section-title text-center">Contact Us</h2>
            <div class="row">
              
                <div class="col-lg-6">
                    <div class="contact-info">
                       
                        
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div>
                                <h5>Address</h5>
                                <p>Web-Based Property Management System in Aksum University</p>
                            </div>
                        </div>
                        
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-phone-alt"></i>
                            </div>
                            <div>
                                <h5>Phone</h5>
                                <p>(+251)979389031</p>
                            </div>
                        </div>
                        
                       
                            <div>
                                <h5>Email</h5>
                                <p>kidanuwelday56@gqmai.com</p>
                            </div>
                        </div>
                        
                 
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        &copy; <?php echo date("Y"); ?> 2025 Property Management System. All Rights Reserved.
    </footer>

    <!-- Optional JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Simple navigation between sections
        document.addEventListener('DOMContentLoaded', function() {
            const homeLink = document.querySelector('.home-link');
            const aboutLink = document.querySelector('.about-link');
            const contactLink = document.querySelector('.contact-link');
            
            const homeSection = document.getElementById('home-section');
            const aboutSection = document.getElementById('about-section');
            const contactSection = document.getElementById('contact-section');
            
            function showSection(sectionToShow) {
                // Hide all sections
                homeSection.style.display = 'none';
                aboutSection.style.display = 'none';
                contactSection.style.display = 'none';
                
                // Remove active class from all links
                homeLink.classList.remove('active');
                aboutLink.classList.remove('active');
                contactLink.classList.remove('active');
                
                // Show selected section
                sectionToShow.style.display = 'flex';
                
                // Add active class to clicked link
                if(sectionToShow === homeSection) {
                    homeLink.classList.add('active');
                } else if(sectionToShow === aboutSection) {
                    aboutLink.classList.add('active');
                } else if(sectionToShow === contactSection) {
                    contactLink.classList.add('active');
                }
            }
            
            // Default show home section
            showSection(homeSection);
            
            // Event listeners
            homeLink.addEventListener('click', function(e) {
                e.preventDefault();
                showSection(homeSection);
            });
            
            aboutLink.addEventListener('click', function(e) {
                e.preventDefault();
                showSection(aboutSection);
            });
            
            contactLink.addEventListener('click', function(e) {
                e.preventDefault();
                showSection(contactSection);
            });
        });
    </script>
</body>
</html>