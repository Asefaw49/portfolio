<?php
include 'db.php';
session_start();

// Only allow access if logged in as Stock Manager
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Stock Manager') {
    header("Location: login.php");
    exit();
}

$stockId = $_GET['id'] ?? null;

if ($stockId) {
    // Fetch existing data
    $stmt = $conn->prepare("SELECT * FROM stock_recorded WHERE StockID = ?");
    $stmt->bind_param("i", $stockId);
    $stmt->execute();
    $result = $stmt->get_result();
    $stock = $result->fetch_assoc();
} else {
    die("Invalid Stock ID");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $model = $_POST['ModelName'];
    $name = $_POST['Name'];
    $qty = $_POST['Quantity'];
    $cost = $_POST['Cost'];
    $safegard = $_POST['SafeGard'];

    $stmt = $conn->prepare("UPDATE stock_recorded SET ModelName=?, Name=?, Quantity=?, Cost=?, SafeGard=?, UpdatedAt=NOW() WHERE StockID=?");
    $stmt->bind_param("ssidsi", $model, $name, $qty, $cost, $safegard, $stockId);

    if ($stmt->execute()) {
        echo "<script>alert('Stock updated successfully.'); window.location='view_stock.php';</script>";
    } else {
        echo "<script>alert('Update failed.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Stock</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f5f7fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background-color: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            max-width: 500px;
            width: 100%;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #2c3e50;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 8px;
            width: 100%;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #388e3c;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #333;
            text-decoration: none;
            font-weight: 500;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 600px) {
            .form-container {
                padding: 20px;
                margin: 10px;
            }

            h2 {
                font-size: 22px;
            }

            input,
            button {
                font-size: 15px;
            }
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Update Stock</h2>
    <form method="POST">
        <label>Model Name:</label>
        <input type="text" name="ModelName" value="<?php echo htmlspecialchars($stock['ModelName']); ?>" required>

        <label>Name:</label>
        <input type="text" name="Name" value="<?php echo htmlspecialchars($stock['Name']); ?>" required>

        <label>Quantity:</label>
        <input type="number" name="Quantity" value="<?php echo htmlspecialchars($stock['Quantity']); ?>" required>

        <label>Cost:</label>
        <input type="number" step="0.01" name="Cost" value="<?php echo htmlspecialchars($stock['Cost']); ?>" required>

        <label>SafeGard:</label>
        <input type="text" name="SafeGard" value="<?php echo htmlspecialchars($stock['SafeGard']); ?>" required>

        <button type="submit">Update Stock</button>
    </form>

    <a href="view_stock.php" class="back-link">← Back to Stock List</a>
</div>

</body>
</html>
