<?php  
include 'db.php';
include 'header.php';

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Stock Manager') {
    header("Location: login.php");
    exit();
}

// Corrected SQL using the real column name
$query = "SELECT * FROM tblstock_in_out ORDER BY STOCKOUTID DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stock In/Out Records</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: white;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background: rgba(0, 0, 0, 0.2);
            padding: 20px;
            height: 100vh;
            position: sticky;
            top: 0;
        }

        .main-content {
            flex: 1;
            padding: 40px;
            overflow-x: auto;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background: #3498db;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .logout {
            display: block;
            margin-top: 30px;
            color: white;
            background-color: gray;
            text-decoration: none;
            font-weight: bold;
            font-size: 16px;
            padding: 10px 15px;
            border-radius: 8px;
            text-align: center;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: relative;
            }

            .main-content {
                padding: 20px;
            }

            table {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
   

    <div class="main-content">
        <h2>Stock In/Out Records</h2>
        <table>
            <tr>
                <th>Stock Out ID</th>
                <th>Transaction No.</th>
                <th>Item ID</th>
                <th>Date</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Supplier/Customer ID</th>
                <th>Remarks</th>
            </tr>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= htmlspecialchars($row['STOCKOUTID']) ?></td>
                <td><?= htmlspecialchars($row['TRANSACTIONNUMBER']) ?></td>
                <td><?= htmlspecialchars($row['ITEMID']) ?></td>
                <td><?= htmlspecialchars($row['TRANSACTIONDATE']) ?></td>
                <td><?= htmlspecialchars($row['QTY']) ?></td>
                <td><?= htmlspecialchars($row['TOTALPRICE']) ?></td>
                <td><?= htmlspecialchars($row['SUPLIERCUSTOMERID']) ?></td>
                <td><?= htmlspecialchars($row['REMARKS']) ?></td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
