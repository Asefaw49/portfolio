<?php  
include 'db.php';
include 'header.php';

// Check if user is Administrator
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Administrator') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Administrator Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap + Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background:white;
            display: flex;
            min-height: 100vh;
        }

        .dashboard-header {
            text-align: center;
            padding: 2rem 1rem;
            color: #fff;
        }

        .dashboard-header i {
            font-size: 2rem;
            color: #ffd700;
        }

        .dashboard-header h2 {
            margin-top: 0.5rem;
            font-size: 1.8rem;
        }

        .dashboard-container {
            display: flex;
            width: 100%;
        }

        .sidebar {
            width: 250px;
            background: rgba(0, 0, 0, 0.2);
            padding: 20px;
            height: 100vh;
            position: sticky;
            top: 0;
        }

        .main-content {
            flex: 1;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .dashboard-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            padding: 2rem;
            max-width: 600px;
            width: 100%;
            color: #fff;
        }

        .dashboard-card h3 {
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .button-group {
            display: grid;
            grid-template-columns: 1fr;
            gap: 12px;
        }

        .button {
            display: flex;
            align-items: center;
            gap: 10px;
            background-color: #ffffff;
            color: #2c3e50;
            padding: 0.75rem 1rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s ease;
            text-align: left;
        }

        .button:hover {
            background-color: #f1f1f1;
            transform: scale(1.03);
        }

        .logout {
            margin-top: 30px;
            display: block;
            text-align: center;
            background-color: #2c3e50;
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s ease;
        }

        .logout:hover {
            background-color: #1a252f;
        }

        footer {
            text-align: center;
            padding: 1rem;
            background: #1a1a1a;
            color: #ccc;
            font-size: 0.9rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="dashboard-header">
            <i class="fas fa-user-shield"></i>
            <h2>Administrator</h2>
        </div>
        <div class="button-group">
            <a href="add and remove.php" class="button"><i class="fas fa-user-cog"></i> Manage Accounts</a>
            <a href="modify-account.php" class="button"><i class="fas fa-edit"></i> Modify Account</a>
            <a href="logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
    </div>

    <footer>
        &copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.
    </footer>

</body>
</html>