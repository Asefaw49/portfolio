<?php
session_start();

// Check if the user is logged in and is an administrator
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "Administrator") {
    header("Location: login.php");
    exit();
}

require_once 'db.php';

$message = "";
$users = []; // Initialize an array to hold user data

// Fetch users from the database
$sql = "SELECT UserID, Username, FirstName, LastName, Department, Campus, Phone, role FROM user";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

// Handle Delete User
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["delete_id"])) {
    $delete_id = $_GET["delete_id"];
    $delete_stmt = $conn->prepare("DELETE FROM user WHERE UserID = ?");
    $delete_stmt->bind_param("i", $delete_id);
    if ($delete_stmt->execute()) {
        $message = "User deleted successfully.";
        // Refresh the user list
        $users = [];
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
        }
    } else {
        $message = "Error deleting user: " . $delete_stmt->error;
    }
    $delete_stmt->close();
}

// Handle Edit User (Display Edit Form)
$edit_user = null; // Initialize for edit form

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["edit_id"])) {
    $edit_id = $_GET["edit_id"];
    $edit_stmt = $conn->prepare("SELECT UserID, Username, FirstName, LastName, Department, Campus, Phone, role FROM user WHERE UserID = ?");
    $edit_stmt->bind_param("i", $edit_id);
    $edit_stmt->execute();
    $edit_result = $edit_stmt->get_result();
    if ($edit_result->num_rows == 1) {
        $edit_user = $edit_result->fetch_assoc();
    }
    $edit_stmt->close();
}

// Handle Update User (Process Edit Form Submission)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_user"])) {
    $update_id = $_POST["update_user"];
    $username = $_POST["username"];
    $firstName = $_POST["firstName"];
    $lastName = $_POST["lastName"];
    $department = $_POST["department"];
    $campus = $_POST["campus"];
    $phone = $_POST["phone"];
    $role = $_POST["role"];

    // Input Validation (Basic)
    if (empty($username) || empty($firstName) || empty($lastName) || empty($department) || empty($campus) || empty($phone) || empty($role)) {
        $message = "All fields are required.";
    } else {
        $update_stmt = $conn->prepare("UPDATE user SET Username = ?, FirstName = ?, LastName = ?, Department = ?, Campus = ?, Phone = ?, role = ? WHERE UserID = ?");
        $update_stmt->bind_param("sssssssi", $username, $firstName, $lastName, $department, $campus, $phone, $role, $update_id);

        if ($update_stmt->execute()) {
            $message = "User updated successfully.";
            // Refresh the user list
            $users = [];
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $users[] = $row;
                }
            }
        } else {
            $message = "Error updating user: " . $update_stmt->error;
        }
        $update_stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Accounts - Administrator</title>
    <style>
        body { font-family: sans-serif; }
        .error { color: red; }
        .success { color: green; }
        table { width: 80%; margin: 20px auto; border-collapse: collapse; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color:rgb(138, 179, 226); }
        .edit-form { width: 400px; margin: 20px auto; padding: 20px; border: 1px solid #ccc; }
        label, input, select { display: block; margin-bottom: 10px; }
        input[type="submit"] { background-color: #4CAF50; color: white; padding: 10px 15px; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <h2>Manage Accounts</h2>

    <?php if ($message): ?>
        <p class="<?php echo (strpos($message, 'Error') !== false) ? 'error' : 'success'; ?>"><?php echo $message; ?></p>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>UserID</th>
                <th>Username</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Department</th>
                <th>Campus</th>
                <th>Phone</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user["UserID"]); ?></td>
                    <td><?php echo htmlspecialchars($user["Username"]); ?></td>
                    <td><?php echo htmlspecialchars($user["FirstName"]); ?></td>
                    <td><?php echo htmlspecialchars($user["LastName"]); ?></td>
                    <td><?php echo htmlspecialchars($user["Department"]); ?></td>
                    <td><?php echo htmlspecialchars($user["Campus"]); ?></td>
                    <td><?php echo htmlspecialchars($user["Phone"]); ?></td>
                    <td><?php echo htmlspecialchars($user["role"]); ?></td>
                    <td>
                        <a href="admin_manage_users.php?edit_id=<?php echo $user["UserID"]; ?>">Edit</a> |
                        <a href="admin_manage_users.php?delete_id=<?php echo $user["UserID"]; ?>" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Edit User Form (Displayed when edit_id is set) -->
    <?php if ($edit_user): ?>
        <div class="edit-form">
            <h3>Edit User</h3>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="update_user" value="<?php echo $edit_user["UserID"]; ?>">

                <label for="username">Username:</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($edit_user["Username"]); ?>" required><br><br>

                <label for="firstName">First Name:</label>
                <input type="text" id="firstName" name="firstName" value="<?php echo htmlspecialchars($edit_user["FirstName"]); ?>" required><br><br>

                <label for="lastName">Last Name:</label>
                <input type="text" id="lastName" name="lastName" value="<?php echo htmlspecialchars($edit_user["LastName"]); ?>" required><br><br>

                <label for="department">Department:</label>
                <input type="text" id="department" name="department" value="<?php echo htmlspecialchars($edit_user["Department"]); ?>" required><br><br>

                <label for="campus">Campus:</label>
                <input type="text" id="campus" name="campus" value="<?php echo htmlspecialchars($edit_user["Campus"]); ?>" required><br><br>

                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($edit_user["Phone"]); ?>" required><br><br>

                <label for="role">Role:</label>
                <select id="role" name="role" required>
                    <option value="">Select Role</option>
                    <option value="Administrator" <?php if ($edit_user["role"] == "Administrator") echo "selected"; ?>>Administrator</option>
                    <option value="Storekeeper" <?php if ($edit_user["role"] == "Storekeeper") echo "selected"; ?>>Storekeeper</option>
                    <option value="Stock Manager" <?php if ($edit_user["role"] == "Stock Manager") echo "selected"; ?>>Stock Manager</option>
                    <option value="User" <?php if ($edit_user["role"] == "User") echo "selected"; ?>>User</option>
                </select><br><br>

                <input type="submit" value="Update User">
            </form>
        </div>
    <?php endif; ?>
    <p><a href="admin_dashboard.php">Back to Dashboard</a></p>
</body>
</html>