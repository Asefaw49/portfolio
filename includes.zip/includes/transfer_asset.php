<?php  
include 'header.php';
include 'db.php';

// Check if user is a Manager
function checkUserRole($role) {
    return isset($_SESSION['UserID']) && $_SESSION['role'] === $role;
}

if (!checkUserRole('Manager')) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['submit_transfer'])) {
    // Fetch manager's first and last names
    $manager_user_id = $_SESSION['UserID'];
    $manager_sql = "SELECT FirstName, LastName FROM user WHERE UserID = ?";
    $manager_stmt = $conn->prepare($manager_sql);
    $manager_stmt->bind_param("i", $manager_user_id);
    $manager_stmt->execute();
    $manager_result = $manager_stmt->get_result();
    $manager_row = $manager_result->fetch_assoc();
    $manager_first_name = $manager_row['FirstName'];
    $manager_last_name = $manager_row['LastName'];
    $manager_stmt->close();

    // Retrieve form data
    $asset_code = intval($_POST['AssetCode']);
    $recipient_user_id = intval($_POST['UserID']);
    $sender_user_id = intval($_POST['SenderID']); // New sender field
    $transfer_quantity = intval($_POST['Quantity']);
    $transfer_reason = htmlspecialchars(trim($_POST['Reason']));
    $issue_date = date('Y-m-d');

    // Get asset name
    $asset_sql = "SELECT AssetName FROM asset WHERE AssetCode = ?";
    $asset_stmt = $conn->prepare($asset_sql);
    $asset_stmt->bind_param("i", $asset_code);
    $asset_stmt->execute();
    $asset_result = $asset_stmt->get_result();
    $asset_row = $asset_result->fetch_assoc();
    $asset_name = $asset_row['AssetName'] ?? null;
    $asset_stmt->close();

    if (!$asset_name) {
        echo "<p style='color: red;'>Asset not found.</p>";
        exit();
    }

    // Get recipient's name
    $recipient_sql = "SELECT FirstName, LastName FROM user WHERE UserID = ?";
    $recipient_stmt = $conn->prepare($recipient_sql);
    $recipient_stmt->bind_param("i", $recipient_user_id);
    $recipient_stmt->execute();
    $recipient_result = $recipient_stmt->get_result();
    $recipient_row = $recipient_result->fetch_assoc();
    $recipient_first_name = $recipient_row['FirstName'];
    $recipient_last_name = $recipient_row['LastName'];
    $recipient_stmt->close();

    // Get sender's name (if different from manager)
    $sender_sql = "SELECT FirstName, LastName FROM user WHERE UserID = ?";
    $sender_stmt = $conn->prepare($sender_sql);
    $sender_stmt->bind_param("i", $sender_user_id);
    $sender_stmt->execute();
    $sender_result = $sender_stmt->get_result();
    $sender_row = $sender_result->fetch_assoc();
    $sender_first_name = $sender_row['FirstName'];
    $sender_last_name = $sender_row['LastName'];
    $sender_stmt->close();

    // Insert transfer record
    $transfer_sql = "INSERT INTO transfer (ToOwnerFirstName, ToOwnerLastName, FromOwnerFirstName, FromOwnerLastName, Quantity, AssetCode, UserID, Reason, IssueDate, Observer)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $transfer_stmt = $conn->prepare($transfer_sql);

    // Prepare the observer string
    $observer = $manager_first_name . " " . $manager_last_name;

    // Bind parameters
    $transfer_stmt->bind_param("ssssiiisss", 
        $recipient_first_name,
        $recipient_last_name,
        $sender_first_name, // Using selected sender instead of manager
        $sender_last_name,  // Using selected sender instead of manager
        $transfer_quantity,
        $asset_code,
        $recipient_user_id,
        $transfer_reason,
        $issue_date,
        $observer
    );

    if ($transfer_stmt->execute()) {
        // Update asset quantity
        $asset_update_sql = "UPDATE asset SET Quantity = Quantity - ? WHERE AssetCode = ? AND Quantity >= ?";
        $asset_update_stmt = $conn->prepare($asset_update_sql);
        $asset_update_stmt->bind_param("iii", $transfer_quantity, $asset_code, $transfer_quantity);
        if ($asset_update_stmt->execute() && $asset_update_stmt->affected_rows > 0) {
            echo '<div class="success-message">Asset transferred successfully!</div>';
        } else {
            echo "<p style='color: red;'>Error updating asset quantity or insufficient stock. Affected rows: " . $asset_update_stmt->affected_rows . "</p>";
        }
        $asset_update_stmt->close();
    } else {
        echo "<p style='color: red;'>Error creating transfer record: " . $conn->error . "</p>";
    }
    $transfer_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asset Transfer</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: #f9f9f9;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .container {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }

        .form-card {
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            padding: 40px;
            border-radius: 16px;
            max-width: 600px;
            width: 100%;
        }

        h1 {
            text-align: center;
            color: #343a40;
            margin-bottom: 30px;
        }

        form {
            text-align: center;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        label {
            text-align: center;
            font-size: 15px;
            color: #555;
            margin-bottom: 5px;
        }

        select, input[type="number"], textarea {
            text-align: center;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        input[type="submit"] {
            background:black;
            color: white;
            font-weight: bold;
            padding: 0.75rem 2rem;
            border-radius: 30px;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            border: none;
        }
        .success-message {
            margin-top: 25px;
            padding: 15px;
            border-radius: 8px;
            background-color: #d1e7dd;
            color: #0f5132;
            text-align: center;
            font-weight: 500;
            box-shadow: 0 4px 8px rgba(0, 128, 0, 0.1);
        }

        .back-link {
            display: inline-block;
            margin: 20px auto;
            background-color: white;
            padding: 12px 20px;
            border-radius: 8px;
            text-decoration: none;
            color: #0f5132;
            font-weight: 500;
            text-align: center;
            transition: 0.3s;
        }

        footer {
            text-align: center;
            padding: 1rem;
            background: #1a1a1a;
            color: #ccc;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="form-card">
        <h1>Asset Transfer</h1>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="transfer-form">
            <label for="asset_code">Select Asset:</label>
            <select id="asset_code" name="AssetCode" class="form-control" required>
                <?php
                // Query to fetch assets
                $assets_sql = "SELECT AssetCode, AssetName FROM asset";
                $assets_result = $conn->query($assets_sql);
                while ($asset = $assets_result->fetch_assoc()) {
                    echo '<option value="' . $asset['AssetCode'] . '">' . htmlspecialchars($asset['AssetName']) . '</option>';
                }
                ?>
            </select>

            <label for="sender_user">Select Sender:</label>
            <select id="sender_user" name="SenderID" class="form-control" required>
                <?php
                // Query to fetch users for sender
                $users_sql = "SELECT UserID, FirstName, LastName FROM user";
                $users_result = $conn->query($users_sql);
                while ($user = $users_result->fetch_assoc()) {
                    $selected = ($user['UserID'] == $_SESSION['UserID']) ? 'selected' : '';
                    echo '<option value="' . $user['UserID'] . '" ' . $selected . '>' . 
                         htmlspecialchars($user['FirstName'] . ' ' . $user['LastName']) . '</option>';
                }
                ?>
            </select>

            <label for="recipient_user">Select Recipient:</label>
            <select id="recipient_user" name="UserID" class="form-control" required>
                <?php
                // Re-query users for recipient (reset pointer first)
                $users_result->data_seek(0);
                while ($user = $users_result->fetch_assoc()) {
                    echo '<option value="' . $user['UserID'] . '">' . 
                         htmlspecialchars($user['FirstName'] . ' ' . $user['LastName']) . '</option>';
                }
                ?>
            </select>

            <label for="transfer_quantity">Quantity to Transfer:</label>
            <input type="number" id="transfer_quantity" name="Quantity" min="1" required>

            <label for="transfer_reason">Reason for Transfer:</label>
            <textarea id="transfer_reason" name="Reason" required></textarea>

            <input type="submit" name="submit_transfer" value="Transfer Asset">
        </form>
    </div>
</div>

<div style="text-align:center;">
    <a href="manager_dashboard.php" class="back-link">← Back to Dashboard</a>
</div>

<footer>
    &copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.
</footer>
</body>
</html>