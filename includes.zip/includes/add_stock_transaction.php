<?php
include 'db.php';    // Database connection
include 'header.php';  // Starts session

// Check if user is Stock Manager
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Stock Manager') {
    header("Location: login.php");
    exit();
}

$message = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ensure $conn is available from db.php
    if (!$conn) {
        $error = "Database connection error. Please check db.php.";
    } else {
        $transaction_number = mysqli_real_escape_string($conn, $_POST['transaction_number']);
        $item_id = mysqli_real_escape_string($conn, $_POST['item_id']);
        $transaction_date = mysqli_real_escape_string($conn, $_POST['transaction_date']);
        $quantity = mysqli_real_escape_string($conn, $_POST['quantity']);
        $total_price = mysqli_real_escape_string($conn, $_POST['total_price']);
        $supplier_customer_id = mysqli_real_escape_string($conn, $_POST['supplier_customer_id']);
        $remarks_input = mysqli_real_escape_string($conn, $_POST['remarks']);
        
        $transaction_type = "";
        if (isset($_POST['stock_in'])) {
            $transaction_type = "IN";
        } elseif (isset($_POST['stock_out'])) {
            $transaction_type = "OUT";
        }

        // Validate inputs (basic validation)
        if (empty($transaction_number) || empty($item_id) || empty($transaction_date) || !is_numeric($quantity) || $quantity <= 0 || !is_numeric($total_price) || $total_price < 0) {
            $error = "Please fill in all required fields with valid data. Quantity must be positive.";
        } elseif (empty($transaction_type)) {
            $error = "Invalid transaction type.";
        } else {
            // Prepend transaction type to remarks as there's no dedicated column
            $remarks_final = "[" . $transaction_type . "] " . $remarks_input;

            $query = "INSERT INTO tblstock_in_out (TRANSACTIONNUMBER, ITEMID, TRANSACTIONDATE, QTY, TOTALPRICE, SUPLIERCUSTOMERID, REMARKS) 
                      VALUES ('$transaction_number', '$item_id', '$transaction_date', '$quantity', '$total_price', '$supplier_customer_id', '$remarks_final')";

            if (mysqli_query($conn, $query)) {
                $message = "Stock transaction recorded successfully!";
            } else {
                $error = "Error recording transaction: " . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Stock Transaction</title>
    <style>
        body {
            margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; background: #f4f7f6; display: flex;
        }
        .sidebar {
            width: 260px; background: #2c3e50; color: white; padding: 20px; height: 100vh; position: sticky; top: 0; box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .sidebar h2 { color: white; text-align: center; margin-bottom: 30px; font-size: 24px; }
        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        .form-container {
            background: white; padding: 30px; border-radius: 15px; box-shadow: 0 8px 25px rgba(0,0,0,0.1); max-width: 700px; margin: 20px auto;
        }
        .form-container h2 { text-align: center; color: #333; margin-bottom: 25px; font-size: 26px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; color: #555; font-weight: 500; }
        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group input[type="number"],
        .form-group textarea {
            width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; font-size: 16px;
        }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .button-group-form { display: flex; gap: 15px; justify-content: center; margin-top: 25px; }
        .button-group-form button {
            background-color: #3498db; color: white; border: none; padding: 12px 25px; border-radius: 8px; font-size: 16px; font-weight: 500; cursor: pointer; transition: background-color 0.3s ease;
        }
        .button-group-form button.stock-in { background-color: #2ecc71; }
        .button-group-form button.stock-in:hover { background-color: #27ae60; }
        .button-group-form button.stock-out { background-color: #e74c3c; }
        .button-group-form button.stock-out:hover { background-color: #c0392b; }
        
        .message, .error {
            text-align: center; padding: 12px; margin-bottom: 20px; border-radius: 8px; font-size: 16px;
        }
        .message { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }

        .sidebar .button-group { display: flex; flex-direction: column; gap: 12px; margin-top: 20px; }
        .sidebar .button { background-color: #3498db; color: white; border: none; padding: 12px 18px; border-radius: 8px; font-size: 16px; font-weight: 500; text-align: left; transition: background-color 0.3s ease, transform 0.2s ease; text-decoration: none; display: flex; align-items: center; gap: 12px; }
        .sidebar .button:hover { background-color: #2980b9; transform: translateY(-2px); }
        .sidebar .logout { display: block; margin-top: 30px; color: #2c3e50; background-color: #ecf0f1; text-decoration: none; font-weight: bold; font-size: 16px; padding: 10px 15px; border-radius: 8px; text-align: center; transition: background-color 0.3s ease, color 0.3s ease; }
        .sidebar .logout:hover { background-color: #bdc3c7; color: #2c3e50; }

        /* Style for the "Back to Dashboard" button */
        .back-to-dashboard-link {
            display: block;
            text-align: center;
            margin-top: 30px; /* Space above the link */
            background-color: #2c3e50; /* Dark background */
            color: #fff; /* White text */
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            transition: background-color 0.3s ease, color 0.3s ease;
            width: fit-content; /* Adjust width to content */
            margin-left: auto; /* Center block element */
            margin-right: auto; /* Center block element */
        }
        .back-to-dashboard-link:hover {
            background-color: #34495e; /* Slightly lighter dark on hover */
            color: #fff;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            body { flex-direction: column; }
            .sidebar { width: 100%; height: auto; position: relative; box-shadow: none; }
            .main-content { padding: 20px; }
            .form-container { padding: 20px; margin: 10px auto; }
            .form-group input[type="text"],
            .form-group input[type="date"],
            .form-group input[type="number"],
            .form-group textarea { padding: 10px; font-size: 15px; }
            .button-group-form { flex-direction: column; }
            .button-group-form button { width: 100%; }
            .back-to-dashboard-link { width: auto; /* Allow full width on mobile if desired, or keep fit-content */ }
        }
    </style>
</head>
<body>

    <div class="main-content">
        <div class="form-container">
            <h2>Add New Stock Transaction</h2>

            <?php if ($message): ?>
                <div class="message"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form action="add_stock_transaction.php" method="POST">
                <div class="form-group">
                    <label for="transaction_number">Transaction No.:</label>
                    <input type="text" id="transaction_number" name="transaction_number" required>
                </div>
                <div class="form-group">
                    <label for="item_id">Item ID:</label>
                    <input type="text" id="item_id" name="item_id" required>
                </div>
                <div class="form-group">
                    <label for="transaction_date">Date:</label>
                    <input type="date" id="transaction_date" name="transaction_date" required value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label for="quantity">Quantity:</label>
                    <input type="number" id="quantity" name="quantity" min="1" required>
                </div>
                <div class="form-group">
                    <label for="total_price">Total Price:</label>
                    <input type="number" id="total_price" name="total_price" min="0" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="supplier_customer_id">Supplier/Customer ID:</label>
                    <input type="text" id="supplier_customer_id" name="supplier_customer_id">
                </div>
                <div class="form-group">
                    <label for="remarks">Remarks:</label>
                    <textarea id="remarks" name="remarks"></textarea>
                </div>
                <div class="button-group-form">
                    <button type="submit" name="stock_in" class="stock-in">Record Stock In</button>
                    <button type="submit" name="stock_out" class="stock-out">Record Stock Out</button>
                </div>
            </form>
            <a href="stockmanager_dashboard.php" class="back-to-dashboard-link">Back to Dashboard</a>
        </div>
    </div>
</body>
</html>