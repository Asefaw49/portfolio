<?php
// Initialize session and check authentication
session_start();

// Database connection
require_once 'db.php'; // Ensure this file correctly establishes $conn

// Check if user is logged in
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}

// Check if user is a Manager
if ($_SESSION['role'] !== 'Manager') {
    header("Location: unauthorized.php"); // Ensure this page exists
    exit();
}

// Initialize variables
$search = isset($_POST['search']) ? trim($_POST['search']) : "";
$message = "";

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve_request'], $_POST['transfer_id'])) {
        $transfer_id = intval($_POST['transfer_id']);
        $result = approveTransfer($conn, $transfer_id, $_SESSION['UserID']); // Pass manager's UserID
        if ($result === true) {
            $message = "success:Request approved successfully and moved to processed transfers!";
        } else {
            $message = "error:" . htmlspecialchars($result); // Display specific error message
        }
    } elseif (isset($_POST['reject_request'], $_POST['transfer_id'])) {
        $transfer_id = intval($_POST['transfer_id']);
        $result = rejectTransfer($conn, $transfer_id, $_SESSION['UserID']); // Pass manager's UserID
        if ($result === true) {
            $message = "success:Request rejected successfully!";
        } else {
            $message = "error:" . htmlspecialchars($result);
        }
    }
}

// Function to approve transfer
function approveTransfer($conn, $transfer_id, $manager_id) {
    $conn->begin_transaction();
    
    try {
        // Get transfer details (including quantity and owner/location names)
        // MODIFIED: Select FromOwnerFirstName, FromOwnerLastName, etc. instead of FromOwnerID, ToOwnerID
        $stmt = $conn->prepare("SELECT AssetCode, Quantity, UserID, 
                                       FromOwnerFirstName, FromOwnerLastName, 
                                       ToOwnerFirstName, ToOwnerLastName 
                                FROM transfer WHERE TransferID = ? AND ReturnDate IS NULL");
        $stmt->bind_param("i", $transfer_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows !== 1) {
            $stmt->close();
            throw new Exception("Transfer not found or already processed.");
        }
        
        $data = $result->fetch_assoc();
        $asset_code = $data['AssetCode']; // Assuming AssetCode is string based on later usage
        $quantity_requested = intval($data['Quantity']);
        $requesting_user_id = intval($data['UserID']);

        // MODIFIED: Construct from_location and to_location strings
        $from_location_str = trim(($data['FromOwnerFirstName'] ?? '') . ' ' . ($data['FromOwnerLastName'] ?? ''));
        $to_location_str = trim(($data['ToOwnerFirstName'] ?? '') . ' ' . ($data['ToOwnerLastName'] ?? ''));
        if (empty($from_location_str)) $from_location_str = "N/A"; // Default if empty
        if (empty($to_location_str)) $to_location_str = "N/A";   // Default if empty
        
        $stmt->close();

        if ($quantity_requested <= 0) {
            throw new Exception("Requested quantity must be positive.");
        }
        
        // Check available quantity in asset table
        $stockStmt = $conn->prepare("SELECT Quantity FROM asset WHERE AssetCode = ?");
        $stockStmt->bind_param("s", $asset_code); 
        $stockStmt->execute();
        $stockResult = $stockStmt->get_result();
        
        if ($stockResult->num_rows !== 1) {
            $stockStmt->close();
            throw new Exception("Asset with code '$asset_code' not found.");
        }
        
        $stockData = $stockResult->fetch_assoc();
        $availableQty = intval($stockData['Quantity']);
        $stockStmt->close();
        
        if ($availableQty < $quantity_requested) {
            throw new Exception("Insufficient stock for AssetCode $asset_code. Available: $availableQty, Requested: $quantity_requested");
        }
        
        // Update asset quantity (decrement stock)
        $updateAsset = $conn->prepare("UPDATE asset SET Quantity = Quantity - ? WHERE AssetCode = ? AND Quantity >= ?");
        $updateAsset->bind_param("isi", $quantity_requested, $asset_code, $quantity_requested);
        $updateAsset->execute();
        
        if ($updateAsset->affected_rows === 0) {
            $updateAsset->close();
            $stockStmtRetry = $conn->prepare("SELECT Quantity FROM asset WHERE AssetCode = ?");
            $stockStmtRetry->bind_param("s", $asset_code);
            $stockStmtRetry->execute();
            $currentStockAfterAttempt = $stockStmtRetry->get_result()->fetch_assoc()['Quantity'] ?? 0;
            $stockStmtRetry->close();
            throw new Exception("Failed to update asset quantity for $asset_code. Stock may have changed. Available: $currentStockAfterAttempt, Requested: $quantity_requested");
        }
        $updateAsset->close();
        
        // Insert into transferred_assets table
        // MODIFIED: Insert $from_location_str and $to_location_str directly.
        // Ensure 'transferred_assets' table has 'approved_by_user_id' column.
        // Ensure 'from_location' and 'to_location' columns in 'transferred_assets' are VARCHAR.
        $insertTransfer = $conn->prepare("
            INSERT INTO transferred_assets (transfer_id, asset_id, user_id, quantity, transfer_date, 
                                           from_location, to_location, status, notes, approved_by_user_id)
            VALUES (?, ?, ?, ?, NOW(), 
                    ?,  /* from_location_str */
                    ?,  /* to_location_str */
                    'completed', 'Approved by manager', ?)
        ");
        // MODIFIED: Bind parameters, note type string 's' for asset_code, from_location, to_location
        // Parameters: transfer_id (i), asset_code (s), requesting_user_id (i), quantity_requested (i), 
        //             from_location_str (s), to_location_str (s), manager_id (i)
        $insertTransfer->bind_param("isiissi", $transfer_id, $asset_code, $requesting_user_id, $quantity_requested, 
                                             $from_location_str, $to_location_str, $manager_id);
        $insertTransfer->execute();

        if ($insertTransfer->affected_rows === 0) {
            $insertTransfer->close();
            throw new Exception("Failed to log the approved transfer into transferred_assets. DB error: " . $conn->error);
        }
        $insertTransfer->close();

        // After successful insertion into transferred_assets, delete from original transfer table
        $deleteOriginal = $conn->prepare("DELETE FROM transfer WHERE TransferID = ?");
        $deleteOriginal->bind_param("i", $transfer_id);
        $deleteOriginal->execute();
        if($deleteOriginal->affected_rows === 0){
            error_log("Warning: Original transfer ID $transfer_id not found for deletion after approval or already deleted.");
        }
        $deleteOriginal->close();
        
        $conn->commit();
        return true;
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Transfer approval failed for ID $transfer_id: " . $e->getMessage());
        return $e->getMessage(); 
    }
}

// Function to reject transfer
function rejectTransfer($conn, $transfer_id, $manager_id) {
    $conn->begin_transaction();
    try {
        // MODIFIED: Select FromOwnerFirstName, etc. for location strings
        $transferDetailsStmt = $conn->prepare("SELECT AssetCode, Quantity, UserID, 
                                                      FromOwnerFirstName, FromOwnerLastName, 
                                                      ToOwnerFirstName, ToOwnerLastName 
                                               FROM transfer WHERE TransferID = ? AND ReturnDate IS NULL");
        $transferDetailsStmt->bind_param("i", $transfer_id);
        $transferDetailsStmt->execute();
        $transferDetailsResult = $transferDetailsStmt->get_result();

        if ($transferDetailsResult->num_rows === 1) {
            $data = $transferDetailsResult->fetch_assoc();
            $asset_code = $data['AssetCode']; // Assuming AssetCode is string
            $quantity_requested = intval($data['Quantity']);
            $requesting_user_id = intval($data['UserID']);

            // MODIFIED: Construct from_location and to_location strings
            $from_location_str = trim(($data['FromOwnerFirstName'] ?? '') . ' ' . ($data['FromOwnerLastName'] ?? ''));
            $to_location_str = trim(($data['ToOwnerFirstName'] ?? '') . ' ' . ($data['ToOwnerLastName'] ?? ''));
            if (empty($from_location_str)) $from_location_str = "N/A";
            if (empty($to_location_str)) $to_location_str = "N/A";

            // MODIFIED: Insert $from_location_str and $to_location_str directly.
            // Ensure 'transferred_assets' table has 'approved_by_user_id' column.
            // Ensure 'from_location' and 'to_location' columns in 'transferred_assets' are VARCHAR.
            $insertRejection = $conn->prepare("
                INSERT INTO transferred_assets (transfer_id, asset_id, user_id, quantity, transfer_date, 
                                               from_location, to_location, status, notes, approved_by_user_id)
                VALUES (?, ?, ?, ?, NOW(), 
                        ?, /* from_location_str */
                        ?, /* to_location_str */
                        'rejected', 'Rejected by manager', ?)
            ");
            // MODIFIED: Bind parameters (i=int, s=string)
            $insertRejection->bind_param("isiissi", $transfer_id, $asset_code, $requesting_user_id, $quantity_requested,
                                                 $from_location_str, $to_location_str, $manager_id);
            $insertRejection->execute();
            if ($insertRejection->affected_rows === 0) {
                 $insertRejection->close();
                 throw new Exception("Failed to log the rejected transfer into transferred_assets. DB error: " . $conn->error);
            }
            $insertRejection->close();
        } else {
            // If transfer not found, it might have been processed already.
            // We still want to ensure it's deleted if it exists, or handle gracefully.
            // For now, if not found, it will lead to "Request not found or already processed" later.
        }
        $transferDetailsStmt->close();

        // Then delete from transfer table
        $stmtDelete = $conn->prepare("DELETE FROM transfer WHERE TransferID = ?");
        $stmtDelete->bind_param("i", $transfer_id);
        $stmtDelete->execute();
        
        if ($stmtDelete->affected_rows > 0 || $transferDetailsResult->num_rows === 0) {
            // If rows were deleted OR if the transfer wasn't found initially (meaning it's already gone)
            $conn->commit();
            $stmtDelete->close();
            return true;
        } else {
            $stmtDelete->close();
            throw new Exception("Request not found or already processed, and no original transfer record deleted.");
        }

    } catch (Exception $e) {
        $conn->rollback();
        error_log("Transfer rejection failed for ID $transfer_id: " . $e->getMessage());
        return $e->getMessage();
    }
}

// Get pending transfer requests
function getTransferRequests($conn, $search = "") {
    $sql = "SELECT t.TransferID, t.AssetCode, a.AssetName, t.Quantity, t.Reason, 
                   DATE_FORMAT(t.IssueDate, '%Y-%m-%d %H:%i') as IssueDate,
                   CONCAT(t.FromOwnerFirstName, ' ', t.FromOwnerLastName) as FromOwner,
                   CONCAT(t.ToOwnerFirstName, ' ', t.ToOwnerLastName) as ToOwner,
                   u.Username,
                   a.Quantity as AvailableQuantity 
            FROM transfer t
            JOIN asset a ON t.AssetCode = a.AssetCode
            JOIN user u ON t.UserID = u.UserID
            WHERE t.ReturnDate IS NULL"; 
    
    $params = [];
    $types = "";
    if (!empty($search)) {
        $searchTerm = "%" . $conn->real_escape_string($search) . "%";
        $sql .= " AND (t.AssetCode LIKE ? 
                  OR a.AssetName LIKE ? 
                  OR t.Reason LIKE ? 
                  OR CONCAT(t.FromOwnerFirstName, ' ', t.FromOwnerLastName) LIKE ? 
                  OR CONCAT(t.ToOwnerFirstName, ' ', t.ToOwnerLastName) LIKE ? 
                  OR u.Username LIKE ?
                  OR t.TransferID LIKE ?)"; 
        for($i=0; $i<7; $i++) {
            $params[] = $searchTerm;
            $types .= "s";
        }
    }
    $sql .= " ORDER BY t.IssueDate DESC";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log("Error preparing getTransferRequests: " . $conn->error);
        return false;
    }
    if (!empty($search)) {
        $stmt->bind_param($types, ...$params);
    }
    
    if(!$stmt->execute()){
        error_log("Error executing getTransferRequests: " . $stmt->error);
        return false;
    }
    return $stmt->get_result();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Asset Transfers (Pending)</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: black;
            --secondary-color: #38a169; /* Green for success/approve */
            --danger-color: #e53e3e;   /* Red for danger/reject */
            --light-color: #f8f9fa;    /* Lighter background for even rows */
            --dark-color: #2d3748;     /* Main text color */
            --gray-color: #ced4da;     /* Borders */
            --white-color: white;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --radius: 8px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #e9ecef; 
            color: var(--dark-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            background: var(--white-color);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }

        h1 {
            color: var(--primary-color);
            font-size: 1.8rem;
            margin-bottom: 1rem; 
        }

        .search-form {
            display: flex;
            gap: 0.5rem;
        }

        .search-input {
            padding: 0.6rem 1rem;
            border: 1px solid var(--gray-color);
            border-radius: var(--radius);
            min-width: 250px;
        }
        .search-input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(0,0,0,0.1);
            outline: none;
        }

        .btn {
            padding: 0.6rem 1.2rem;
            border: none;
            border-radius: var(--radius);
            cursor: pointer;
            font-weight: 600;
            transition: all 0.2s ease-in-out;
            text-transform: uppercase;
            font-size: 0.85rem;
        }
        .btn i { margin-right: 0.5em; }
        .btn-primary { background-color: var(--primary-color); color: var(--white-color); }
        .btn-primary:hover { background-color: #333; }
        .btn-success { background-color: var(--secondary-color); color: var(--white-color); }
        .btn-success:hover { background-color: #2f855a; }
        .btn-danger { background-color: var(--danger-color); color: var(--white-color); }
        .btn-danger:hover { background-color: #c53030; }
        .btn:disabled { background-color: #ccc; cursor: not-allowed; opacity: 0.7;}
        .btn:hover { opacity: 0.9; transform: translateY(-1px); }
        .btn:active { transform: translateY(0px); }


        .table-container {
            overflow-x: auto;
            margin-bottom: 2rem;
            border: 1px solid var(--gray-color);
            border-radius: var(--radius);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 0.8rem 1rem;
            text-align: left;
            border-bottom: 1px solid var(--gray-color);
            font-size: 0.9rem;
        }

        th {
            background-color: var(--primary-color);
            color: var(--white-color);
            position: sticky;
            top: 0;
            z-index: 10;
            text-transform: uppercase;
            font-size: 0.85rem;
        }
        
        td .action-form { display: flex; gap: 0.5rem; }
        td .action-form .btn { padding: 0.4rem 0.8rem; font-size: 0.8rem; }

        tr:nth-child(even) { background-color: var(--light-color); }
        tr:hover { background-color: #dee2e6; }

        .no-data { text-align: center; padding: 3rem 1rem; color: #6c757d; font-size: 1.1rem; }
        .no-data i { font-size: 2rem; margin-bottom: 0.5rem; display: block; }

        .back-link {
            display: inline-block; margin-top: 1rem; padding: 0.6rem 1.2rem;
            text-decoration: none; color: var(--primary-color); font-weight: 600;
            border: 1px solid var(--primary-color); border-radius: var(--radius);
            transition: all 0.2s ease-in-out;
        }
        .back-link i { margin-right: 0.5em; }
        .back-link:hover { background-color: var(--primary-color); color: var(--white-color); text-decoration: none; }

        .toast {
            position: fixed; bottom: 20px; right: 20px; padding: 1rem 1.5rem;
            border-radius: var(--radius); color: var(--white-color); font-weight: 600;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2); opacity: 0;
            transform: translateY(20px); transition: opacity 0.3s ease, transform 0.3s ease;
            z-index: 10000; min-width: 250px; display: flex; align-items: center;
        }
        .toast i { margin-right: 0.75rem; font-size: 1.2rem; }
        .toast.show { opacity: 1; transform: translateY(0); }
        .toast-success { background-color: var(--secondary-color); }
        .toast-error   { background-color: var(--danger-color); }
        
        .stock-warning { color: var(--danger-color); font-weight: bold; font-size: 0.8em; margin-left: 5px;}


        @media (max-width: 768px) {
            .container { padding: 1rem; margin: 1rem; }
            .header { flex-direction: column; align-items: stretch; }
            .header h1 { text-align: center; }
            .search-form { width: 100%; flex-direction: column; }
            .search-form .btn { width: 100%; }
            .search-input { min-width: 0; width: 100%; }
            th, td { padding: 0.75rem 0.5rem; font-size: 0.85rem; }
            td .action-form { flex-direction: column; align-items: flex-start; }
            td .action-form .btn { width: 100%; margin-bottom: 0.25rem; }
            td .action-form .btn:last-child { margin-bottom: 0; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-exchange-alt"></i> Manage Asset Transfers (Pending)</h1>
            <form class="search-form" method="post" action="">
                <input type="text" name="search" class="search-input" placeholder="Search transfers..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
            </form>
        </div>
        
        <div class="table-container">
            <?php
            if ($conn) {
                $transfers = getTransferRequests($conn, $search);
            } else {
                $transfers = false;
                $message = "error:Database connection failed.";
            }
            
            if ($transfers && $transfers->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Asset Code</th>
                            <th>Asset Name</th>
                            <th>Qty Req.</th>
                            <th>Qty Avail.</th>
                            <th>Reason</th>
                            <th>Date</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Requested By</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $transfers->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['TransferID']) ?></td>
                                <td><?= htmlspecialchars($row['AssetCode']) ?></td>
                                <td><?= htmlspecialchars($row['AssetName']) ?></td>
                                <td><?= htmlspecialchars($row['Quantity']) ?></td>
                                <td>
                                    <?= htmlspecialchars($row['AvailableQuantity']) ?>
                                    <?php if (intval($row['AvailableQuantity']) < intval($row['Quantity'])): ?>
                                        <span class="stock-warning">(Low Stock!)</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($row['Reason']) ?></td>
                                <td><?= htmlspecialchars($row['IssueDate']) ?></td>
                                <td><?= htmlspecialchars($row['FromOwner']) ?></td>
                                <td><?= htmlspecialchars($row['ToOwner']) ?></td>
                                <td><?= htmlspecialchars($row['Username']) ?></td>
                                <td>
                                    <form class="action-form" method="post" action="">
                                        <input type="hidden" name="transfer_id" value="<?= $row['TransferID'] ?>">
                                        <button type="submit" name="approve_request" class="btn btn-success" 
                                            title="Approve this transfer"
                                            <?php if (intval($row['AvailableQuantity']) < intval($row['Quantity'])): ?>disabled<?php endif; ?>>
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                        <button type="submit" name="reject_request" class="btn btn-danger" title="Reject this transfer">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php elseif ($transfers === false && $conn): ?>
                <div class="no-data">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Could not retrieve transfer requests. Query error.</p>
                </div>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-folder-open"></i>
                    <p>No pending transfer requests found<?= !empty($search) ? " matching your search criteria" : "" ?>.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <a href="manager_dashboard.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>

    <?php if (!empty($message)): 
        $message_parts = explode(':', $message, 2);
        $type = (count($message_parts) === 2 && in_array($message_parts[0], ['success', 'error'])) ? $message_parts[0] : 'info';
        $text = (count($message_parts) === 2) ? $message_parts[1] : $message;
    ?>
        <div class="toast toast-<?= htmlspecialchars($type) ?>" id="toast-message">
            <i class="fas <?= ($type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle') ?>"></i>
            <?= htmlspecialchars($text) ?>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                const toast = document.getElementById('toast-message');
                if (toast) {
                    setTimeout(() => toast.classList.add('show'), 100);
                    setTimeout(() => {
                        toast.classList.remove('show');
                        setTimeout(() => { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 300);
                    }, 5000); 
                }
            });
        </script>
    <?php endif; ?>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const approveButtons = document.querySelectorAll('button[name="approve_request"]');
            const rejectButtons = document.querySelectorAll('button[name="reject_request"]');
            
            approveButtons.forEach(btn => {
                btn.addEventListener('click', function(e) {
                    if (!confirm('Are you sure you want to APPROVE this transfer? Stock will be deducted.')) {
                        e.preventDefault();
                    }
                });
            });
            
            rejectButtons.forEach(btn => {
                btn.addEventListener('click', function(e) {
                    if (!confirm('Are you sure you want to REJECT this transfer?')) {
                        e.preventDefault();
                    }
                });
            });
        });
    </script>
</body>
</html>