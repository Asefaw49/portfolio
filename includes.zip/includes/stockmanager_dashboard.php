<?php
include 'db.php'; // Include your database connection
include 'header.php'; // Should include session_start()

// Check if user is Stock Manager
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Stock Manager') {
    header("Location: login.php"); // Redirect to login if not a stock manager
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Manager Dashboard</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: #f4f7f6; /* Light background for the body */
            min-height: 100vh;
            display: flex;
        }

        .sidebar {
            width: 260px; /* Slightly wider sidebar */
            background:rgb(216, 223, 231); /* Darker sidebar */
            color: white;
            padding: 20px;
            height: 100vh;
            position: sticky;
            top: 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }

        .sidebar h2 {
            color: black;
            text-align: center;
            margin-bottom: 30px; /* More space below title */
            font-size: 24px;
        }
        
        .main-content {
            flex: 1;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .dashboard-container { /* Renamed for clarity */
            background: white; /* White background for content */
            border-radius: 15px; /* Softer corners */
            padding: 30px 40px; /* Adjust padding */
            width: 100%;
            max-width: 700px;
            box-shadow: 0 8px 25px rgba(207, 195, 195, 0.1); /* Softer shadow */
            text-align: center;
        }

        .dashboard-container h3 { /* Changed from h2 for content title */
            color: #333; /* Darker text for content title */
            margin-bottom: 15px;
            font-size: 28px;
            font-weight: 600;
        }

        .dashboard-container p {
            color: #555; /* Text color for paragraphs */
            font-size: 18px;
            margin-bottom: 30px;
        }

        .button-group {
            display: flex;
            flex-direction: column;
            gap: 12px; /* Slightly reduced gap */
            margin-top: 20px;
        }

        .button {
            background-color:rgb(224, 232, 236); /* Primary button color */
            color: black;
            border: none;
            padding: 12px 18px; /* Adjust padding */
            border-radius: 8px; /* Softer corners */
            font-size: 16px;
            font-weight: 500;
            text-align: left;
            transition: background-color 0.3s ease, transform 0.2s ease;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px; /* Icon-text gap */
        }

        

        .logout {
            display: block;
            margin-top: 30px;
            color: #2c3e50; /* Dark text for contrast */
            background-color: #ecf0f1; /* Light background */
            text-decoration: none;
            font-weight: bold;
            font-size: 16px;
            padding: 10px 15px;
            border-radius: 8px;
            text-align: center;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        
        
        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                box-shadow: none;
            }
            
            .main-content {
                padding: 20px;
            }
            
            .dashboard-container {
                padding: 20px;
            }

            .button {
                padding: 12px 15px;
                font-size: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Stock Manager</h2>
        <div class="button-group">
            <a href="manage_stock.php" class="button">📦 Manage Stock</a>
            <a href="view_stock.php" class="button">👀 View Stock</a>
          <!--  <a href="add_stock_transaction.php" class="button">➕ Add Stock Transaction</a>
            <a href="view_stock_transactions.php" class="button">📊 View Stock Transactions</a>
            <a href="search_stock.php" class="button">🔍 Search Stock</a>
            <a href="update_stock.php" class="button">🔄 Update Stock</a> -->
            <a href="view_approved_requests.php" class="button">✅ Approved Requests</a>
            <a href="modify-account.php" class="button">👤 Modify Account</a>
            <a href="logout.php" class="logout">🚪 Logout</a>
        </div>
    </div>

    
    </div>
</body>
</html>