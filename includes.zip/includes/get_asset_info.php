<?php
include 'db.php';

$code = $_GET['code'] ?? '';
$response = ['success' => false];

if ($code) {
    $stmt = $conn->prepare("SELECT AssetName, Category, Quantity FROM asset WHERE AssetCode = ?");
    $stmt->bind_param("s", $code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $response['success'] = true;
        $response['asset'] = $row;
    }

    $stmt->close();
}

header('Content-Type: application/json');
echo json_encode($response);
?>
