<?php  
include 'db.php';
include 'header.php';

// Ensure user is logged in and has the 'Stock Manager' role
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Stock Manager') {
    header("Location: login.php");
    exit();
}

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_stock'])) {
    $delete_id = intval($_POST['delete_id']);
    $delete_sql = "DELETE FROM stock_recorded WHERE StockID = $delete_id";

    if ($conn->query($delete_sql) === TRUE) {
        echo "<p style='color: green; text-align:center;'>Stock ID $delete_id deleted successfully.</p>";
    } else {
        echo "<p style='color: red; text-align:center;'>Error deleting record: " . $conn->error . "</p>";
    }
}
?>

<!-- Internal CSS Styling -->
<style>
    :root {
        --primary-color: black;
        --secondary-color: white;
        --bg-color: #f9fafc;
        --text-color: #333;
        --white: #ffffff;
        --table-bg: #f1f1f1;
        --table-border: #ddd;
        --hover-color: #e5f5e5;
        --button-color: #4CAF50;
    }

    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background-color: white;
        color: var(--text-color);
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    .container {
        flex: 1;
        background: white;
        max-width: 900px;
        margin: 30px auto;
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
    }

    h2 {
        text-align: center;
        color: var(--primary-color);
        margin-bottom: 30px;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .table th,
    .table td {
        padding: 12px;
        text-align: left;
        border: 1px solid var(--table-border);
        color: black;
    }

    .table th {
        background-color: black;
        color: white;
    }

    .table tr:hover {
        background-color: var(--hover-color);
    }

    .search-form {
        margin-bottom: 20px;
        text-align: center;
    }

    .search-form input[type="text"] {
        padding: 10px;
        width: 60%;
        border-radius: 8px;
        border: 1px solid #ccc;
    }

    .search-form button {
        padding: 10px 15px;
        border: none;
        background-color: black;
        color: white;
        border-radius: 8px;
        cursor: pointer;
    }

    .search-form button:hover {
        background-color: #333;
    }

    .footer {
        background-color: #2c3e50;
        color: white;
        text-align: center;
        padding: 15px 0;
        font-size: 14px;
        width: 100%;
        margin-top: auto;
    }

    .footer a {
        color: #f39c12;
        text-decoration: none;
        font-weight: bold;
    }

    .footer a:hover {
        color: #e67e22;
    }

    .update-btn {
        padding: 6px 10px;
        background-color: #4CAF50;
        color: white;
        border-radius: 5px;
        text-decoration: none;
        font-size: 14px;
    }

    .delete-btn {
        padding: 6px 10px;
        background-color: red;
        color: white;
        border-radius: 5px;
        border: none;
        cursor: pointer;
        font-size: 14px;
    }

    .action-buttons {
        display: flex;
        gap: 8px;
        align-items: center;
    }

    .action-buttons form {
        margin: 0;
    }

    .back-link {
        display: inline-block;
        margin-top: 20px;
        font-weight: bold;
        color: black;
        text-decoration: none;
    }

    .back-link:hover {
        text-decoration: underline;
    }
</style>

<div class="container">
    <h2>View Stock</h2>

    <form method="GET" class="search-form">
        <input type="text" name="search" placeholder="Search by Name" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        <button type="submit">Search</button>
    </form>

    <?php
    $search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
    $sql = !empty($search) 
        ? "SELECT * FROM stock_recorded WHERE Name LIKE '%$search%'"
        : "SELECT * FROM stock_recorded";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table class='table'>";
        echo "<tr>
                <th>Stock ID</th>
                <th>Model</th>
                <th>Name</th>
                <th>Quantity</th>
                <th>Cost (Single)</th>
                <th>Total Cost</th>
                <th>SafeGard</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>Action</th>
              </tr>";
        while ($row = $result->fetch_assoc()) {
            $quantity = (int)$row["Quantity"];
            $cost = (float)$row["Cost"];
            $total_cost = number_format($quantity * $cost, 2);

            echo "<tr>";
            echo "<td>" . htmlspecialchars($row["StockID"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["ModelName"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["Name"]) . "</td>";
            echo "<td>" . htmlspecialchars($quantity) . "</td>";
            echo "<td>" . htmlspecialchars(number_format($cost, 2)) . "</td>";
            echo "<td>$total_cost</td>";
            echo "<td>" . htmlspecialchars($row["SafeGard"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["CreatedAt"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["UpdatedAt"]) . "</td>";
            echo "<td>
                    <div class='action-buttons'>
                        <a class='update-btn' href='update_stock.php?id=" . $row["StockID"] . "'>Update</a>
                        <form method='POST' action='' onsubmit=\"return confirm('Are you sure you want to delete this stock item?');\">
                            <input type='hidden' name='delete_id' value='" . $row["StockID"] . "'>
                            <button type='submit' name='delete_stock' class='delete-btn'>Delete</button>
                        </form>
                    </div>
                  </td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No stock found.</p>";
    }
    ?>

    <div style="text-align: center; margin-top: 20px;">
        <a href="<?php echo ($_SESSION['role'] === 'Storekeeper' ? 'storekeeper_dashboard.php' : 'stockmanager_dashboard.php'); ?>" class="back-link">← Back to Dashboard</a>
    </div>
</div>

<footer class="footer">
    &copy; <?php echo date('Y'); ?> Asset Management System | All Rights Reserved.
</footer>
</body>
</html>
