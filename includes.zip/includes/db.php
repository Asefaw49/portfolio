<?php
$servername = "localhost"; // Update as needed
$username = "root";        // Update as needed
$password = "";            // Update as needed
$dbname = "it_property";   // Remove the leading space
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// No need for the following check, as connect_error will handle it
// if (!$conn) {
//     die("Database connection error.");
// }
?>