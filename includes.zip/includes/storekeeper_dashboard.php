<?php
include 'db.php'; // Include your database connection
include 'header.php'; // Include your header
// Check if user is Storekeeper
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Storekeeper') {
    header("Location: login.php"); // Redirect to login if not a storekeeper
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Storekeeper Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --sidebar-width: 280px;
            --primary-color: #2c3e50;
            --secondary-color: #4ca1af;
            --accent-color: #3498db;
            --text-light:black;
            --text-dark: #333333;
            --card-bg: rgba(255, 255, 255, 0.1);
            --transition-speed: 0.3s;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: white;
            min-height: 100vh;
            display: flex;
            color: var(--text-light);
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: rgba(0, 0, 0, 0.25);
            backdrop-filter: blur(10px);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            transition: width var(--transition-speed);
            z-index: 100;
        }

        .sidebar-header {
            text-align: center;
            padding: 20px 0;
            margin-bottom: 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header h2 {
            font-size: 1.5rem;
            color: var(--text-light);
            margin-top: 10px;
        }

        .sidebar-header i {
            font-size: 2rem;
            color: var(--accent-color);
        }

        .nav-menu {
            flex: 1;
            overflow-y: auto;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            color: var(--text-light);
            text-decoration: none;
            transition: all var(--transition-speed);
            position: relative;
            overflow: hidden;
        }

        .nav-link i {
            margin-right: 12px;
            font-size: 1.1rem;
            width: 24px;
            text-align: center;
        }

        .nav-link:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateX(5px);
        }

        .nav-link.active {
            background: var(--accent-color);
            box-shadow: 0 4px 12px rgba(52, 152, 219, 0.3);
        }

        .nav-link::after {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: var(--accent-color);
            transform: scaleY(0);
            transition: transform var(--transition-speed);
        }

        .nav-link:hover::after,
        .nav-link.active::after {
            transform: scaleY(1);
        }

        .logout-container {
            margin-top: auto;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logout-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 12px;
            border-radius: 8px;
            background: rgba(231, 76, 60, 0.2);
            color: var(--text-light);
            text-decoration: none;
            transition: all var(--transition-speed);
        }

        .logout-btn:hover {
            background: rgba(231, 76, 60, 0.3);
            transform: translateX(5px);
        }

        .logout-btn i {
            margin-right: 10px;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 40px;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .dashboard-header {
            margin-bottom: 30px;
            text-align: center;
        }

        .dashboard-header h1 {
            font-size: 2.2rem;
            margin-bottom: 10px;
            color: var(--text-light);
        }

        .dashboard-header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--card-bg);
            backdrop-filter: blur(5px);
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform var(--transition-speed);
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card h3 {
            font-size: 1rem;
            margin-bottom: 10px;
            color: var(--accent-color);
        }

        .stat-card .value {
            font-size: 2rem;
            font-weight: bold;
        }

        .recent-activity {
            background: var(--card-bg);
            backdrop-filter: blur(5px);
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .recent-activity h2 {
            font-size: 1.5rem;
            margin-bottom: 20px;
            color: var(--accent-color);
        }

        .activity-item {
            display: flex;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(52, 152, 219, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }

        .activity-details {
            flex: 1;
        }

        .activity-details p {
            margin-bottom: 5px;
        }

        .activity-time {
            font-size: 0.8rem;
            opacity: 0.7;
        }

        /* Footer Styles */
        footer {
            text-align: center;
            padding: 15px;
            margin-top: auto;
            font-size: 0.9rem;
            color: var(--text-light);
            opacity: 0.8;
        }

        /* Ripple Effect */
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.6);
            transform: scale(0);
            animation: ripple-animation 0.6s linear;
            pointer-events: none;
        }

        @keyframes ripple-animation {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }

            .sidebar-header h2, 
            .nav-link span {
                display: none;
            }

            .nav-link {
                justify-content: center;
                padding: 15px;
            }

            .nav-link i {
                margin-right: 0;
                font-size: 1.3rem;
            }

            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 20px;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: fixed;
                bottom: 0;
                top: auto;
                flex-direction: row;
                padding: 10px;
                justify-content: space-around;
                border-top: 1px solid rgba(255, 255, 255, 0.1);
                border-right: none;
            }

            .sidebar-header,
            .logout-container {
                display: none;
            }

            .nav-menu {
                display: flex;
                flex: 1;
                justify-content: space-around;
            }

            .nav-item {
                margin-bottom: 0;
            }

            .nav-link {
                flex-direction: column;
                padding: 10px 5px;
                font-size: 0.7rem;
            }

            .nav-link i {
                margin-right: 0;
                margin-bottom: 5px;
                font-size: 1.2rem;
            }

            .main-content {
                margin-left: 0;
                margin-bottom: 70px;
            }
        }
        footer {
            text-align: center;
            padding: 1rem;
            background: #1a1a1a;
            color: #ccc;
            font-size: 0.9rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-warehouse"></i>
            <h2>Storekeeper</h2>
        </div>
        
       <!-- <nav class="nav-menu">
            <div class="nav-item">
                <a href="calculate_depreciation.php" class="nav-link">
                    <i class="fas fa-calculator"></i>
                    <span>Calculate Depreciation</span>
                </a>
            </div>-->
            <div class="nav-item">
                <a href="register_asset.php" class="nav-link">
                    <i class="fas fa-plus-circle"></i>
                    <span>Register Asset</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="search_asset.php" class="nav-link">
                    <i class="fas fa-search"></i>
                    <span>Search Asset</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="update_asset.php" class="nav-link">
                    <i class="fas fa-edit"></i>
                    <span>Update Asset</span> 
                </a>
            </div>
            <div class="nav-item">
                <a href="view_approved_requests.php" class="nav-link">
                    <i class="fas fa-clipboard-check"></i>
                    <span>View Approved Requests</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="register_return_asset.php" class="nav-link">
                    <i class="fas fa-undo"></i>
                    <span>Return Asset</span>
                </a>
                
            </div>
            <div class="nav-item">
                <a href="view_asset_returns.php" class="nav-link">
                    <i class="fas fa-clipboard-check"></i>
                    <span>view_asset_returns</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="modify-account.php" class="nav-link">
                    <i class="fas fa-user-cog"></i>
                    <span>Account Settings</span>
                </a>
            </div>
        </nav>
        
        <div class="logout-container">
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>
    <script>
        // Add ripple effect to all navigation links
        document.querySelectorAll('.nav-link, .logout-btn').forEach(link => {
            link.addEventListener('click', function (e) {
                const ripple = document.createElement('span');
                ripple.className = 'ripple';
                this.appendChild(ripple);
                
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                
                ripple.style.width = ripple.style.height = size + 'px';
                ripple.style.left = e.clientX - rect.left - size / 2 + 'px';
                ripple.style.top = e.clientY - rect.top - size / 2 + 'px';
                
                setTimeout(() => ripple.remove(), 600);
            });
        });

        // Set active nav item based on current page
        const currentPage = window.location.pathname.split('/').pop();
        document.querySelectorAll('.nav-link').forEach(link => {
            if (link.getAttribute('href') === currentPage) {
                link.classList.add('active');
            }
        });
    </script>
</body>
<footer>
        &copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.
    </footer>

</html>