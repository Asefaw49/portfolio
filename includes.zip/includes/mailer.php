composer require phpmailer/phpmailer
```2.  **Create `mailer.php`:** Include the `sendWelcomeEmail` function (and potentially others like `sendPasswordChangeNotification`, `sendEmailChangeNotification`) as shown in previous answers. **Configure your SMTP settings securely** (use environment variables or a config file).
```php
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Adjust path if needed

function sendWelcomeEmail($recipientEmail, $username, $firstName) {
    $mail = new PHPMailer(true);
    try {
        // --- SMTP CONFIGURATION (Use env vars/config file!) ---
        $mail->isSMTP();
        $mail->Host = 'smtp.example.com'; // Your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'your_email@example.com'; // Your SMTP username
        $mail->Password = 'your_smtp_password'; // Your SMTP password/app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // or ::ENCRYPTION_SMTPS
        $mail->Port = 587; // or 465 for SMTPS
        // --- END CONFIGURATION ---

        $mail->setFrom('no-reply@yourdomain.com', 'Asset Management System');
        $mail->addAddress($recipientEmail, $firstName);
        $mail->isHTML(true);
        $mail->Subject = 'Welcome to the Asset Management System!';
        $mail->Body    = "Hello " . htmlspecialchars($firstName) . ",<br><br>An account has been created for you.<br>Your username is: <b>" . htmlspecialchars($username) . "</b><br><br>Please log in to access the system.";
        $mail->AltBody = "Hello " . htmlspecialchars($firstName) . ",\n\nAn account has been created for you.\nYour username is: " . htmlspecialchars($username) . "\n\nPlease log in to access the system.";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Mailer Error (Welcome Email to {$recipientEmail}): {$mail->ErrorInfo}");
        return false;
    }
}

// Add other functions like sendPasswordChangeNotification($email, $username) here...
?>