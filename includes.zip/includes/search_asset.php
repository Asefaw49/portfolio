<?php
include 'header.php';
include 'db.php';

if ($_SESSION['role'] !== 'Storekeeper') {
    header("Location: login.php");
    exit();
}

$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $search = $_POST['search'];
    $query = "SELECT * FROM asset WHERE AssetCode LIKE ? OR AssetName LIKE ?";
    $stmt = $conn->prepare($query);
    $searchTerm = "%$search%";
    $stmt->bind_param("ss", $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
}
?>

<div class="container">
    <h2>Search Asset</h2>
    <form method="POST" class="search-form">
        <input type="text" name="search" placeholder="Search by code or name" required>
        <button type="submit">Search</button>
    </form>
    
    <?php if ($result && $result->num_rows > 0): ?>
        <table class="asset-table">
            <tr>
                <th>Asset Code</th>
                <th>Model</th>
                <th>Name</th>
                <th>Qty</th>
                <th>Cost</th>
                <th>Status</th>
                <th>Expiry</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['AssetCode']) ?></td>
                    <td><?= htmlspecialchars($row['ModelName']) ?></td>
                    <td><?= htmlspecialchars($row['AssetName']) ?></td>
                    <td><?= htmlspecialchars($row['Quantity']) ?></td>
                    <td><?= htmlspecialchars($row['Cost']) ?></td>
                    <td><?= htmlspecialchars($row['Status']) ?></td>
                    <td><?= htmlspecialchars($row['ExpiryDate']) ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php elseif ($result): ?>
        <p>No assets found.</p>
    <?php endif; 
    echo '<a href="storekeeper_dashboard.php" class="back-link">← Back to Dashboard</a>';
echo '</div>';?>
</div>
<footer>
        &copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.
    </footer>
<!-- Internal CSS Styling -->
<style>
    :root {
        --primary-color:rgb(14, 17, 14);
        --secondary-color: #2c3e50;
        --bg-color: #f9fafc;
        --text-color: #333;
        --white: #ffffff;
        --table-border: #ddd;
        --hover-color: #e5f5e5;
    }

    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background-color: var(--bg-color);
        color: var(--text-color);
    }

    .container {
        max-width: 900px;
        margin: 60px auto;
        padding: 30px;
        background-color: var(--white);
        border-radius: 16px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
    }

    h2 {
        text-align: center;
        color: var(--primary-color);
        margin-bottom: 30px;
        font-size: 24px;
    }

    .search-form {
        display: flex;
        justify-content: center;
        margin-bottom: 20px;
    }

    .search-form input[type="text"] {
        padding: 10px;
        border: 1px solid var(--table-border);
        border-radius: 5px;
        width: 70%;
        margin-right: 10px;
    }

    .search-form button {
        padding: 10px 15px;
        border: none;
        background-color: var(--primary-color);
        color: white;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .search-form button:hover {
        background-color: darkgreen;
    }

    .asset-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .asset-table th,
    .asset-table td {
        padding: 12px;
        text-align: left;
        border: 1px solid var(--table-border);
    }

    .asset-table th {
        background-color: var(--primary-color);
        color: white;
    }

    .asset-table tr:hover {
        background-color: var(--hover-color);
    }

    @media (max-width: 600px) {
        .container {
            margin: 30px 15px;
            padding: 20px;
        }

        .search-form input[type="text"], 
        .search-form button {
            width: 100%;
            margin: 5px 0;
        }

        .search-form {
            flex-direction: column;
        }
    }
    footer {
            text-align: center;
            padding: 1rem;
            background: #1a1a1a;
            color: #ccc;
            font-size: 0.9rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
</style>