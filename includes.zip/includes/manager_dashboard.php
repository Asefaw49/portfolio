<?php  
include 'db.php'; // Include your database connection
include 'header.php'; // Include your header

// Check if user is Stock Manager
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Manager') {
    header("Location: login.php"); // Redirect to login if not a stock manager
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manager Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --sidebar-width: 280px;
            --primary-color: #ffffff;
            --secondary-color: #ffffff;
            --accent-color: #2c3e50;
            --text-light: #000000;
            --text-dark: #000000;
            --card-bg: rgba(255, 255, 255, 0.9);
            --transition-speed: 0.3s;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: white;
            min-height: 100vh;
            display: flex;
            color: var(--text-dark);
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: #f8f9fa;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            border-right: 1px solid #e0e0e0;
            z-index: 100;
        }

        .sidebar-header {
            text-align: center;
            padding: 20px 0;
            margin-bottom: 30px;
            border-bottom: 1px solid #e0e0e0;
        }

        .sidebar-header i {
            font-size: 2rem;
            color: var(--accent-color);
        }

        .sidebar-header h2 {
            font-size: 1.5rem;
            color: var(--text-dark);
            margin-top: 10px;
        }

        .nav-menu {
            flex: 1;
            overflow-y: auto;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            color: var(--text-dark);
            text-decoration: none;
            transition: all var(--transition-speed);
            position: relative;
        }

        .nav-link i {
            margin-right: 12px;
            font-size: 1.1rem;
            width: 24px;
            text-align: center;
            color: var(--accent-color);
        }

        .nav-link:hover {
            background: rgba(44, 62, 80, 0.1);
            transform: translateX(5px);
        }

        .nav-link.active {
            background: rgba(44, 62, 80, 0.2);
        }

        .nav-link::after {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: var(--accent-color);
            transform: scaleY(0);
            transition: transform var(--transition-speed);
        }

        .nav-link:hover::after,
        .nav-link.active::after {
            transform: scaleY(1);
        }

        .logout-container {
            margin-top: auto;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
        }

        .logout-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 12px;
            border-radius: 8px;
            background: rgba(44, 62, 80, 0.1);
            color: var(--text-dark);
            text-decoration: none;
            transition: all var(--transition-speed);
        }

        .logout-btn:hover {
            background: rgba(44, 62, 80, 0.2);
            transform: translateX(5px);
        }

        .logout-btn i {
            margin-right: 10px;
            color: var(--accent-color);
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 40px;
            display: flex;
            flex-direction: column;
            background: white;
        }

        .dashboard-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .dashboard-header h1 {
            font-size: 2.2rem;
            margin-bottom: 10px;
            color: var(--text-dark);
        }

        .dashboard-header p {
            font-size: 1.1rem;
            color: var(--text-dark);
            opacity: 0.9;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: transform var(--transition-speed);
            border: 1px solid #e0e0e0;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card h3 {
            font-size: 1rem;
            margin-bottom: 10px;
            color: var(--accent-color);
        }

        .stat-card .value {
            font-size: 2rem;
            font-weight: bold;
            color: var(--text-dark);
        }

        .quick-actions {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid #e0e0e0;
        }

        .quick-actions h2 {
            font-size: 1.5rem;
            margin-bottom: 20px;
            color: var(--accent-color);
        }

        .action-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .action-card {
            background: rgba(44, 62, 80, 0.1);
            color: var(--text-dark);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            transition: all 0.3s ease;
            text-decoration: none;
            border: 1px solid rgba(44, 62, 80, 0.2);
        }

        .action-card:hover {
            background: rgba(44, 62, 80, 0.2);
            transform: translateY(-5px);
        }

        .action-card i {
            font-size: 2rem;
            margin-bottom: 10px;
            color: var(--accent-color);
        }

        /* Footer Styles */
        footer {
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            color: var(--text-dark);
            font-size: 0.9rem;
            margin-top: auto;
            border-top: 1px solid #e0e0e0;
        }

        /* Ripple Effect */
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(44, 62, 80, 0.2);
            transform: scale(0);
            animation: ripple-animation 0.6s linear;
            pointer-events: none;
        }

        @keyframes ripple-animation {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }

            .sidebar-header h2, 
            .nav-link span {
                display: none;
            }

            .nav-link {
                justify-content: center;
                padding: 15px;
            }

            .nav-link i {
                margin-right: 0;
                font-size: 1.3rem;
            }

            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 20px;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: fixed;
                bottom: 0;
                top: auto;
                flex-direction: row;
                padding: 10px;
                justify-content: space-around;
                border-top: 1px solid #e0e0e0;
                border-right: none;
            }

            .sidebar-header,
            .logout-container {
                display: none;
            }

            .nav-menu {
                display: flex;
                flex: 1;
                justify-content: space-around;
            }

            .nav-item {
                margin-bottom: 0;
            }

            .nav-link {
                flex-direction: column;
                padding: 10px 5px;
                font-size: 0.7rem;
            }

            .nav-link i {
                margin-right: 0;
                margin-bottom: 5px;
                font-size: 1.2rem;
            }

            .main-content {
                margin-left: 0;
                margin-bottom: 70px;
            }
        }
          footer {
            text-align: center;
            padding: 1rem;
            background: #1a1a1a;
            color: #ccc;
            font-size: 0.9rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-user-shield"></i>
            <h2>Manager Dashboard</h2>
        </div>
        
        <nav class="nav-menu">
            <div class="nav-item">
                <a href="view available asset.php" class="nav-link">
                    <i class="fas fa-boxes"></i>
                    <span>View Assets</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="manage requests.php" class="nav-link">
                    <i class="fas fa-tasks"></i>
                    <span>Manage Requests</span>
                </a>
            </div>
          <!--<div class="nav-item">
                <a href="generate report.php" class="nav-link">
                    <i class="fas fa-chart-line"></i>
                    <span>Generate Reports</span>
                </a>
            </div>-->
            <div class="nav-item">
                <a href="transfer_asset.php" class="nav-link">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transfer Assets</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="modify-account.php" class="nav-link">
                    <i class="fas fa-user-cog"></i>
                    <span>Account Settings</span>
                </a>
            </div>
            <div class="logout-container">
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </nav>
    </aside>
    <footer>
        &copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.
    </footer>

    <script>
        // Add ripple effect to all navigation links
        document.querySelectorAll('.nav-link, .logout-btn, .action-card').forEach(link => {
            link.addEventListener('click', function (e) {
                const ripple = document.createElement('span');
                ripple.className = 'ripple';
                this.appendChild(ripple);
                
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                
                ripple.style.width = ripple.style.height = size + 'px';
                ripple.style.left = e.clientX - rect.left - size / 2 + 'px';
                ripple.style.top = e.clientY - rect.top - size / 2 + 'px';
                
                setTimeout(() => ripple.remove(), 600);
            });
        });

        // Set active nav item based on current page
        const currentPage = window.location.pathname.split('/').pop();
        document.querySelectorAll('.nav-link').forEach(link => {
            if (link.getAttribute('href') === currentPage) {
                link.classList.add('active');
            }
        });
    </script>
</body>
</html>