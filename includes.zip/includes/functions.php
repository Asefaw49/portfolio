function sendEmailNotification($to, $subject, $body, $userID) {
    global $conn;

    // Check if email notifications are enabled
    $settings_sql = "SELECT EnableEmailNotifications FROM user_settings WHERE UserID = ?";
    $settings_stmt = $conn->prepare($settings_sql);
    $settings_stmt->bind_param("i", $userID);
    $settings_stmt->execute();
    $settings_result = $settings_stmt->get_result();

    if ($settings_result && $settings_result->num_rows == 1) {
        $settings_data = $settings_result->fetch_assoc();
        if ($settings_data['EnableEmailNotifications'] == 1) {
            // Existing PHPMailer email sending logic here
            // (Assumes PHPMailer is already configured properly)
        }
    }
    $settings_stmt->close();
}

function sendSMS($to, $message, $userID) {
    global $conn;

    // Check if SMS notifications are enabled
    $settings_sql = "SELECT EnableSMSNotifications FROM user_settings WHERE UserID = ?";
    $settings_stmt = $conn->prepare($settings_sql);
    $settings_stmt->bind_param("i", $userID);
    $settings_stmt->execute();
    $settings_result = $settings_stmt->get_result();

    if ($settings_result && $settings_result->num_rows == 1) {
        $settings_data = $settings_result->fetch_assoc();
        if ($settings_data['EnableSMSNotifications'] == 1) {
            // Add your actual SMS sending logic here (e.g., using Twilio API)
        }
    }
    $settings_stmt->close();
}
