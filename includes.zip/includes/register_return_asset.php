


<?php
include 'db.php';
include 'header.php';

echo '<div class="container">';
echo "<h2>Register Returned Asset</h2>";
?>

<!-- Asset Return Form -->
<form method="post" action="" class="form" id="returnForm">
    <label for="asset_code">Asset Code:</label>
    <input type="number" id="asset_code" name="AssetCode" required>

    <!-- Auto-filled asset info -->
    <div id="assetDetails" style="display:none;" class="asset-details">
        <p><strong>Asset Name:</strong> <span id="assetName"></span></p>
        <p><strong>Model Name:</strong> <span id="modelName"></span></p>
        <p><strong>Type:</strong> <span id="type"></span></p>
        <p><strong>Available Quantity:</strong> <span id="assetQty"></span></p>
    </div>

    <label for="taker_fname">Taker First Name:</label>
    <input type="text" id="taker_fname" name="TakerFname" required>

    <label for="taker_lname">Taker Last Name:</label>
    <input type="text" id="taker_lname" name="TakerLname" required>

    <label for="quantity">Quantity Returned:</label>
    <input type="number" id="quantity" name="QuantityReturned" min="1" required>

    <label for="return_date">Return Date:</label>
    <input type="date" id="return_date" name="ReturnDate" value="<?php echo date('Y-m-d'); ?>" required>

    <label for="remarks">Remarks:</label>
    <textarea id="remarks" name="Remarks" rows="3"></textarea>

    <input type="submit" name="return_asset" value="Register Return" class="submit-btn">
</form>

<!-- Spinner -->
<div id="loadingSpinner" class="loading-spinner" style="display:none;">Processing...</div>

<?php
if (isset($_POST['return_asset'])) {
    // Sanitize inputs
    $asset_code     = intval($_POST['AssetCode']);
    $fname          = trim($_POST['TakerFname']);
    $lname          = trim($_POST['TakerLname']);
    $quantity       = intval($_POST['QuantityReturned']);
    $return_date    = $_POST['ReturnDate'];
    $remarks        = trim($_POST['Remarks']);

    // Update asset quantity
    $update_sql = "UPDATE asset SET Quantity = Quantity + ? WHERE AssetCode = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ii", $quantity, $asset_code);

    if ($stmt->execute()) {
        // Insert into asset_returns
        $insert_sql = "INSERT INTO asset_returns (AssetCode, TakerFname, TakerLname, QuantityReturned, ReturnDate, Remarks) VALUES (?, ?, ?, ?, ?, ?)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("ississ", $asset_code, $fname, $lname, $quantity, $return_date, $remarks);
        
        if ($insert_stmt->execute()) {
            echo "<p class='success-msg'>Asset return registered successfully.</p>";
        } else {
            echo "<p class='error-msg'>Error saving return info: " . $insert_stmt->error . "</p>";
        }

        $insert_stmt->close();
    } else {
        echo "<p class='error-msg'>Error updating asset: " . $stmt->error . "</p>";
    }

    $stmt->close();
}

echo '<a href="storekeeper_dashboard.php" class="back-btn">Back to Dashboard</a>';
echo '</div>';
?>



<!-- CSS (optional or keep yours) -->
<style>
    body {
        font-family: Arial, sans-serif;
        background: #f4f7f9;
        margin: 0;
        padding: 40px;
    }

    .container {
        max-width: 600px;
        margin: auto;
        background: #fff;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }

    .form label {
        font-weight: bold;
    }

    .form input, .form textarea {
        width: 100%;
        padding: 10px;
        margin-top: 6px;
        margin-bottom: 15px;
        border-radius: 8px;
        border: 1px solid #ccc;
    }

    .submit-btn {
        background-color: #2c3e50;
        color: white;
        padding: 12px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
    }

    .success-msg { color: green; font-weight: bold; }
    .error-msg { color: red; font-weight: bold; }
    .back-btn {
        display: block;
        margin-top: 20px;
        text-align: center;
        text-decoration: none;
        color: #2c3e50;
        border: 2px solid #2c3e50;
        padding: 10px;
        border-radius: 8px;
    }

    .loading-spinner {
        margin-top: 10px;
        font-weight: bold;
        color: #333;
    }
</style>
