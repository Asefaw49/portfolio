<?php
session_start();
include 'db.php'; // Include your database connection
// require_once 'mailer.php'; // Include mailer functions for notifications (See Step 3)

// --- Security Check ---
if (!isset($_SESSION['UserID']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'Administrator') {
    header("Location: login.php"); // Redirect to login if not an admin
    exit();
}

// --- Helper Variables ---
$action_message = ""; // To display success/error messages
$errors = []; // To collect validation errors
$form_data = $_POST; // Keep submitted data for potential repopulation (basic)

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator Actions</title>
    <style>
        body { font-family: sans-serif; margin: 20px; background-color: #f4f4f4; }
        .container { max-width: 800px; margin: 20px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h1, h2 { color: #333; border-bottom: 1px solid #ccc; padding-bottom: 10px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="password"], input[type="email"], input[type="tel"], select {
            width: calc(100% - 22px); /* Adjust for padding/border */
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button, input[type="submit"] {
            background-color: #007bff; color: white; padding: 10px 15px; border: none;
            border-radius: 4px; cursor: pointer; margin-right: 10px; margin-bottom: 10px;
            font-size: 1em;
        }
        button:hover, input[type="submit"]:hover { background-color: #0056b3; }
        .action-buttons form { display: inline-block; margin-right: 5px;}
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; }
        .success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; }
        .error { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; }
        .error ul { margin-top: 10px; margin-left: 20px; }
        .back-link { display: inline-block; margin-top: 20px; }
    </style>
</head>
<body>
<div class="container">
    <h1>Administrator Actions</h1>
    <p>Welcome, <?php echo htmlspecialchars($_SESSION['Username'] ?? 'Admin'); ?>!</p>

    <div class="action-buttons">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <button type="submit" name="view_available_assets">View Available Assets</button>
            <button type="submit" name="manage_account">Manage Accounts</button>
            <button type="submit" name="manage_request">Manage Requests</button>
            <button type="submit" name="generate_report">Generate Report</button>
            <button type="submit" name="transfer_asset">Transfer Asset</button>
        </form>
         <a href="admin_dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
    <hr>

<?php

// --- Handle Form Submissions ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // --- View Available Assets ---
    if (isset($_POST['view_available_assets'])) {
        echo "<h2>View Available Assets</h2>";
        // Assuming 'Available' or 'Active' means available. Adjust status as needed.
        $sql = "SELECT AssetCode, AssetName, ModelName, Type, Quantity, Status, ExpiryDate
                FROM asset
                WHERE Status = 'Active' OR Status = 'Available'
                ORDER BY AssetName";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            echo "<table>";
            echo "<thead><tr><th>Code</th><th>Name</th><th>Model</th><th>Type</th><th>Quantity</th><th>Status</th><th>Expiry</th></tr></thead>";
            echo "<tbody>";
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row["AssetCode"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["AssetName"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["ModelName"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["Type"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["Quantity"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["Status"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["ExpiryDate"] ?: 'N/A') . "</td>"; // Handle null expiry
                echo "</tr>";
            }
            echo "</tbody></table>";
        } else {
             if(!$result) { echo "<p class='error'>Error fetching assets: " . $conn->error . "</p>"; }
             else { echo "<p>No available assets found matching the criteria.</p>"; }
        }
    }

    // --- Manage Account (Show Sub-options) ---
    elseif (isset($_POST['manage_account'])) {
        echo "<h2>Manage Accounts</h2>";
        echo '<div class="action-buttons">';
        echo '<form method="post" action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '"><button type="submit" name="add_account_form">Add New Account</button></form>';
        echo '<form method="post" action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '"><button type="submit" name="remove_account_form">Remove Account</button></form>';
        echo '<form method="post" action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '"><button type="submit" name="modify_account_select_form">Modify Account</button></form>';
        echo '</div>';
    }

    // --- Show Add Account Form ---
    elseif (isset($_POST['add_account_form'])) {
        echo "<h2>Add New Account</h2>";
        // Display validation errors if any from previous attempt
        if (!empty($errors)) {
            echo "<div class='message error'><ul>";
            foreach ($errors as $err) { echo "<li>" . htmlspecialchars($err) . "</li>"; }
            echo "</ul></div>";
        }
        // Form to add a new account (includes Email)
        echo '<form method="post" action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '" novalidate>';
        echo '<label for="username">Username:</label>';
        echo '<input type="text" id="username" name="username" required value="' . htmlspecialchars($form_data['username'] ?? '') .'"><br><br>';

        echo '<label for="email">Email:</label>'; // EMAIL FIELD
        echo '<input type="email" id="email" name="email" required value="' . htmlspecialchars($form_data['email'] ?? '') .'"><br><br>'; // EMAIL FIELD

        echo '<label for="password">Password:</label>';
        echo '<input type="password" id="password" name="password" required><br><br>';
        echo '<label for="first_name">First Name:</label>';
        echo '<input type="text" id="first_name" name="first_name" required value="' . htmlspecialchars($form_data['first_name'] ?? '') .'"><br><br>';
        echo '<label for="last_name">Last Name:</label>';
        echo '<input type="text" id="last_name" name="last_name" required value="' . htmlspecialchars($form_data['last_name'] ?? '') .'"><br><br>';
        echo '<label for="department">Department:</label>';
        echo '<input type="text" id="department" name="department" required value="' . htmlspecialchars($form_data['department'] ?? '') .'"><br><br>';
        echo '<label for="campus">Campus:</label>';
        echo '<input type="text" id="campus" name="campus" required value="' . htmlspecialchars($form_data['campus'] ?? '') .'"><br><br>';
        echo '<label for="phone">Phone:</label>';
        echo '<input type="tel" id="phone" name="phone" required pattern="[0-9]{10,15}" title="10-15 digits" value="' . htmlspecialchars($form_data['phone'] ?? '') .'"><br><br>';
        echo '<label for="role">Role:</label>';
        echo '<select id="role" name="role" required>';
        echo '<option value="">-- Select Role --</option>';
        $roles = ['User', 'Storekeeper', 'Stock Manager', 'Administrator', 'Manager']; // Include Manager
        foreach ($roles as $r) {
            $selected = (isset($form_data['role']) && $form_data['role'] == $r) ? 'selected' : '';
            echo '<option value="' . $r . '" ' . $selected . '>' . $r . '</option>';
        }
        echo '</select><br><br>';
        echo '<input type="submit" name="submit_add_account" value="Submit New Account">';
        echo '</form>';
    }

    // --- Process Add Account Submission ---
    elseif (isset($_POST['submit_add_account'])) {
        // Retrieve and sanitize
        $username = trim(htmlspecialchars($_POST['username']));
        $password = $_POST['password']; // Raw password
        $firstName = trim(htmlspecialchars($_POST['first_name']));
        $lastName = trim(htmlspecialchars($_POST['last_name']));
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL); // Sanitize Email
        $department = trim(htmlspecialchars($_POST['department']));
        $campus = trim(htmlspecialchars($_POST['campus']));
        $phone = trim(htmlspecialchars($_POST['phone']));
        $role = htmlspecialchars($_POST['role']);

        // Validation
        if (empty($username)) $errors[] = "Username is required.";
        if (empty($password)) $errors[] = "Password is required.";
        elseif (strlen($password) < 8) $errors[] = "Password must be at least 8 characters long.";
        if (empty($firstName)) $errors[] = "First name is required.";
        if (empty($lastName)) $errors[] = "Last name is required.";
        if (empty($email)) $errors[] = "Email is required.";
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";
        if (empty($department)) $errors[] = "Department is required.";
        if (empty($campus)) $errors[] = "Campus is required.";
        if (empty($phone)) $errors[] = "Phone is required.";
        elseif (!preg_match("/^[0-9]{10,15}$/", $phone)) $errors[] = "Invalid phone format (10-15 digits).";
        if (empty($role)) $errors[] = "Role is required.";
        elseif (!in_array($role, ['User', 'Storekeeper', 'Stock Manager', 'Administrator', 'Manager'])) $errors[] = "Invalid role selected.";

        // Check duplicates if no validation errors
        if (empty($errors)) {
            $check_stmt = $conn->prepare("SELECT UserID FROM user WHERE Username = ? OR Email = ?");
            $check_stmt->bind_param("ss", $username, $email);
            $check_stmt->execute();
            if ($check_stmt->get_result()->num_rows > 0) {
                $errors[] = "Username or Email already exists.";
            }
            $check_stmt->close();
        }

        if (empty($errors)) {
            // *** HASH THE PASSWORD ***
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Prepare and execute (with Email)
            $sql = "INSERT INTO user (Username, Password, FirstName, LastName, Email, Department, Campus, Phone, role)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"; // 9 placeholders
            $stmt = $conn->prepare($sql);
            // Bind parameters (sssssssss)
            $stmt->bind_param("sssssssss", $username, $hashed_password, $firstName, $lastName, $email, $department, $campus, $phone, $role);

            if ($stmt->execute()) {
                $action_message = "<p class='message success'>Account for '" . htmlspecialchars($username) . "' added successfully!</p>";

                // --- Send Welcome Email ---
                // if (function_exists('sendWelcomeEmail')) {
                //     if (!sendWelcomeEmail($email, $username, $firstName)) {
                //          error_log("Failed to send welcome email to " . $email);
                //          $action_message .= "<p class='message error'>Welcome email failed to send.</p>";
                //     }
                // } else { error_log("sendWelcomeEmail function missing."); }
                // -------------------------

                $form_data = []; // Clear form data on success
            } else {
                $action_message = "<p class='message error'>Error adding account: " . $stmt->error . "</p>";
                error_log("Admin Add User Error: " . $stmt->error);
            }
            $stmt->close();
        } else {
             // If validation errors occurred, redisplay the add form by setting a flag or redirecting
             // For simplicity here, we'll just show the errors. A better UX would redisplay the form.
             $action_message = "<div class='message error'><strong>Error adding account:</strong><ul>";
             foreach ($errors as $err) { $action_message .= "<li>" . htmlspecialchars($err) . "</li>"; }
             $action_message .= "</ul></div>";
             // To redisplay form: echo the form HTML again here or use JS/redirects
        }
         echo $action_message; // Display result message
    }


    // --- Show Remove Account Form ---
    elseif (isset($_POST['remove_account_form'])) {
        echo "<h2>Remove Account</h2>";
        echo '<form method="post" action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '" onsubmit="return confirm(\'Are you SURE you want to permanently remove this user? This cannot be undone.\');">';
        echo '<label for="user_to_remove">Select User to Remove:</label>';
        echo '<select id="user_to_remove" name="user_to_remove" required>';
        echo '<option value="">-- Select User --</option>';
        // Populate the dropdown with users (excluding self if desired)
        $sql = "SELECT UserID, Username, FirstName, LastName FROM user WHERE UserID != ? ORDER BY Username"; // Exclude logged-in admin
        $stmt_users = $conn->prepare($sql);
        $loggedInUserId = $_SESSION['UserID'];
        $stmt_users->bind_param("i", $loggedInUserId);
        $stmt_users->execute();
        $result = $stmt_users->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<option value="' . htmlspecialchars($row["UserID"]) . '">'
                   . htmlspecialchars($row["Username"]) . ' (' . htmlspecialchars($row["FirstName"]) . ' ' . htmlspecialchars($row["LastName"]) . ')'
                   . '</option>';
            }
        }
        $stmt_users->close();
        echo '</select><br><br>';
        echo '<input type="submit" name="submit_remove_account" value="Remove Selected Account" style="background-color: #dc3545;">'; // Red button
        echo '</form>';
    }

     // --- Process Remove Account Submission ---
    elseif (isset($_POST['submit_remove_account'])) {
        $user_id_to_remove = filter_input(INPUT_POST, 'user_to_remove', FILTER_VALIDATE_INT);

        if (!$user_id_to_remove) {
             $action_message = "<p class='message error'>Invalid user selected for removal.</p>";
        } elseif ($user_id_to_remove == $_SESSION['UserID']) {
             $action_message = "<p class='message error'>You cannot remove your own account.</p>";
        } else {
            $sql = "DELETE FROM user WHERE UserID = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $user_id_to_remove);

            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $action_message = "<p class='message success'>Account removed successfully!</p>";
                } else {
                     $action_message = "<p class='message error'>User not found or already removed.</p>";
                }
            } else {
                $action_message = "<p class='message error'>Error removing account: " . $stmt->error . "</p>";
                 error_log("Admin Remove User Error (UserID: {$user_id_to_remove}): " . $stmt->error);
            }
            $stmt->close();
        }
         echo $action_message; // Display result message
    }


    // --- Show Modify Account - Select Account Form ---
    elseif (isset($_POST['modify_account_select_form'])) {
        echo "<h2>Modify Account - Select User</h2>";
        echo '<form method="post" action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '">';
        echo '<label for="user_to_modify">Select User to Modify:</label>';
        echo '<select id="user_to_modify" name="user_to_modify" required>';
         echo '<option value="">-- Select User --</option>';
        // Populate the dropdown with users
        $sql = "SELECT UserID, Username, FirstName, LastName FROM user ORDER BY Username";
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                 echo '<option value="' . htmlspecialchars($row["UserID"]) . '">'
                   . htmlspecialchars($row["Username"]) . ' (' . htmlspecialchars($row["FirstName"]) . ' ' . htmlspecialchars($row["LastName"]) . ')'
                   . '</option>';
            }
        }
        echo '</select><br><br>';
        echo '<input type="submit" name="submit_select_account_for_modify" value="Load User Data for Modification">';
        echo '</form>';
    }

    // --- Show Modify Account - Display Modify Form ---
    elseif (isset($_POST['submit_select_account_for_modify'])) {
        $user_id_to_modify = filter_input(INPUT_POST, 'user_to_modify', FILTER_VALIDATE_INT);

        if (!$user_id_to_modify) {
             echo "<p class='message error'>Invalid user selected.</p>";
        } else {
            // Fetch user details for modification (including Email)
            $sql = "SELECT UserID, Username, FirstName, LastName, Email, Department, Campus, Phone, role FROM user WHERE UserID = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $user_id_to_modify);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows == 1) {
                $user_data = $result->fetch_assoc();

                echo "<h2>Modify Account: " . htmlspecialchars($user_data['Username']) . "</h2>";
                 // Display validation errors if any from previous attempt
                if (!empty($errors)) {
                    echo "<div class='message error'><ul>";
                    foreach ($errors as $err) { echo "<li>" . htmlspecialchars($err) . "</li>"; }
                    echo "</ul></div>";
                }
                echo '<form method="post" action="' . htmlspecialchars($_SERVER["PHP_SELF"]) . '" novalidate>';
                echo '<input type="hidden" name="user_id_to_update" value="' . htmlspecialchars($user_data['UserID']) . '">'; // Hidden field for UserID

                echo '<label for="username">Username:</label>';
                echo '<input type="text" id="username" name="username" value="' . htmlspecialchars($user_data['Username']) . '" required><br><br>';

                echo '<label for="email">Email:</label>'; // EMAIL FIELD
                echo '<input type="email" id="email" name="email" value="' . htmlspecialchars($user_data['Email']) . '" required><br><br>'; // EMAIL FIELD

                echo '<label for="password">Password (Leave blank to keep current):</label>';
                echo '<input type="password" id="password" name="password"><br><br>'; // Password field is optional for update

                echo '<label for="first_name">First Name:</label>';
                echo '<input type="text" id="first_name" name="first_name" value="' . htmlspecialchars($user_data['FirstName']) . '" required><br><br>';
                echo '<label for="last_name">Last Name:</label>';
                echo '<input type="text" id="last_name" name="last_name" value="' . htmlspecialchars($user_data['LastName']) . '" required><br><br>';
                echo '<label for="department">Department:</label>';
                echo '<input type="text" id="department" name="department" value="' . htmlspecialchars($user_data['Department']) . '" required><br><br>';
                echo '<label for="campus">Campus:</label>';
                echo '<input type="text" id="campus" name="campus" value="' . htmlspecialchars($user_data['Campus']) . '" required><br><br>';
                echo '<label for="phone">Phone:</label>';
                echo '<input type="tel" id="phone" name="phone" value="' . htmlspecialchars($user_data['Phone']) . '" required pattern="[0-9]{10,15}" title="10-15 digits"><br><br>';
                echo '<label for="role">Role:</label>';
                echo '<select id="role" name="role" required>';
                 echo '<option value="">-- Select Role --</option>';
                $roles = ['User', 'Storekeeper', 'Stock Manager', 'Administrator', 'Manager'];
                foreach ($roles as $r) {
                    $selected = ($user_data['role'] == $r) ? 'selected' : '';
                    echo '<option value="' . $r . '" ' . $selected . '>' . $r . '</option>';
                }
                echo '</select><br><br>';
                echo '<input type="submit" name="submit_update_account" value="Update Account">';
                echo '</form>';
            } else {
                echo "<p class='message error'>User not found.</p>";
            }
             $stmt->close();
        }
    }

    // --- Process Modify Account - Update Account ---
    elseif (isset($_POST['submit_update_account'])) {
        $user_id_to_update = filter_input(INPUT_POST, 'user_id_to_update', FILTER_VALIDATE_INT);

        // Retrieve and sanitize
        $username = trim(htmlspecialchars($_POST['username']));
        $password = $_POST['password']; // Raw password, handle if empty
        $firstName = trim(htmlspecialchars($_POST['first_name']));
        $lastName = trim(htmlspecialchars($_POST['last_name']));
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL); // Sanitize Email
        $department = trim(htmlspecialchars($_POST['department']));
        $campus = trim(htmlspecialchars($_POST['campus']));
        $phone = trim(htmlspecialchars($_POST['phone']));
        $role = htmlspecialchars($_POST['role']);

        // Validation
        if (!$user_id_to_update) $errors[] = "Invalid user ID for update.";
        if (empty($username)) $errors[] = "Username is required.";
        if (empty($firstName)) $errors[] = "First name is required.";
        if (empty($lastName)) $errors[] = "Last name is required.";
        if (empty($email)) $errors[] = "Email is required.";
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";
        if (empty($department)) $errors[] = "Department is required.";
        if (empty($campus)) $errors[] = "Campus is required.";
        if (empty($phone)) $errors[] = "Phone is required.";
        elseif (!preg_match("/^[0-9]{10,15}$/", $phone)) $errors[] = "Invalid phone format (10-15 digits).";
        if (empty($role)) $errors[] = "Role is required.";
        elseif (!in_array($role, ['User', 'Storekeeper', 'Stock Manager', 'Administrator', 'Manager'])) $errors[] = "Invalid role selected.";
        // Password validation only if entered
        if (!empty($password) && strlen($password) < 8) $errors[] = "New password must be at least 8 characters long.";

        // Check duplicates (excluding self) if no validation errors
        if (empty($errors)) {
            $check_stmt = $conn->prepare("SELECT UserID FROM user WHERE (Username = ? OR Email = ?) AND UserID != ?");
            $check_stmt->bind_param("ssi", $username, $email, $user_id_to_update);
            $check_stmt->execute();
            if ($check_stmt->get_result()->num_rows > 0) {
                $errors[] = "Username or Email already exists for another user.";
            }
            $check_stmt->close();
        }

        if (empty($errors)) {
            // Build dynamic update query
            $update_sql = "UPDATE user SET Username = ?, FirstName = ?, LastName = ?, Email = ?, Department = ?, Campus = ?, Phone = ?, role = ?"; // Email added
            $update_params = "ssssssss"; // 8 strings now
            $update_values = [$username, $firstName, $lastName, $email, $department, $campus, $phone, $role];

            $password_changed = false;
            if (!empty($password)) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash if provided
                $update_sql .= ", Password = ?";
                $update_params .= "s";
                $update_values[] = $hashed_password;
                $password_changed = true;
            }

            $update_sql .= " WHERE UserID = ?";
            $update_params .= "i";
            $update_values[] = $user_id_to_update;

            $stmt = $conn->prepare($update_sql);

            if ($stmt) {
                $stmt->bind_param($update_params, ...$update_values);

                if ($stmt->execute()) {
                    $action_message = "<p class='message success'>Account for '" . htmlspecialchars($username) . "' updated successfully!</p>";

                    // --- Send Notification Email on change (Optional) ---
                    // You might want to fetch the *old* email before the update to notify the previous address if it changed.
                    // if ($password_changed && function_exists('sendPasswordChangeNotification')) {
                    //     sendPasswordChangeNotification($email, $username); // Send to current email
                    // }
                    // Check if email was actually changed before sending notification
                    // if ($email_changed_flag && function_exists('sendEmailChangeNotification')) { ... }
                    // -----------------------------------------------------

                } else {
                    $action_message = "<p class='message error'>Error updating account: " . $stmt->error . "</p>";
                    error_log("Admin Update User Error (UserID: {$user_id_to_update}): " . $stmt->error);
                }
                $stmt->close();
            } else {
                 $action_message = "<p class='message error'>Error preparing update statement: " . $conn->error . "</p>";
                 error_log("Admin Update User Prepare Error (UserID: {$user_id_to_update}): " . $conn->error);
            }
        } else {
            // If validation errors occurred, redisplay the modify form with errors
            // This requires fetching the user data again and showing the form HTML
             $action_message = "<div class='message error'><strong>Error updating account:</strong><ul>";
             foreach ($errors as $err) { $action_message .= "<li>" . htmlspecialchars($err) . "</li>"; }
             $action_message .= "</ul></div>";
             // Ideally, refetch user data and echo the modify form HTML again here.
        }
         echo $action_message; // Display result message
    }


    // --- Manage Request (Placeholder) ---
    elseif (isset($_POST['manage_request'])) {
        echo "<h2>Manage Requests</h2>";
        echo "<p><i>Request management functionality not yet implemented. Requires 'transfer' or request table structure.</i></p>";
        // Example: Fetch pending requests if a 'transfer' table exists with a 'status' column
        /*
        $sql_req = "SELECT t.TransferID, t.Reason, t.IssueDate, t.Quantity, u.Username as Requester, a.AssetName
                    FROM transfer t
                    JOIN user u ON t.UserID = u.UserID
                    JOIN asset a ON t.AssetCode = a.AssetCode
                    WHERE t.status = 'Pending' -- Assuming a status column
                    ORDER BY t.IssueDate";
        $result_req = $conn->query($sql_req);
        if ($result_req && $result_req->num_rows > 0) {
            echo "<table><thead><tr><th>ID</th><th>Asset</th><th>Qty</th><th>Requester</th><th>Reason</th><th>Date</th><th>Actions</th></tr></thead><tbody>";
            while($req = $result_req->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $req['TransferID'] . "</td>";
                echo "<td>" . htmlspecialchars($req['AssetName']) . "</td>";
                echo "<td>" . $req['Quantity'] . "</td>";
                echo "<td>" . htmlspecialchars($req['Requester']) . "</td>";
                echo "<td>" . htmlspecialchars($req['Reason']) . "</td>";
                echo "<td>" . $req['IssueDate'] . "</td>";
                echo '<td>';
                // Add Approve/Reject forms/buttons here, passing TransferID
                echo '<form style="display:inline;" method="post"><input type="hidden" name="approve_request_id" value="'.$req['TransferID'].'"><button type="submit">Approve</button></form> ';
                echo '<form style="display:inline;" method="post"><input type="hidden" name="reject_request_id" value="'.$req['TransferID'].'"><button type="submit" style="background-color:#dc3545;">Reject</button></form>';
                echo '</td>';
                echo "</tr>";
            }
            echo "</tbody></table>";
        } else {
            echo "<p>No pending requests found.</p>";
        }
        */
    }

     // --- Process Approve Request (Example Placeholder) ---
    elseif (isset($_POST['approve_request_id'])) {
        $req_id = filter_input(INPUT_POST, 'approve_request_id', FILTER_VALIDATE_INT);
        if ($req_id) {
            // 1. Update request status in 'transfer' table to 'Approved'
            // 2. Update asset quantity or assign asset (complex logic depending on system)
            // 3. Notify requester
            echo "<p class='message success'>Request ID {$req_id} approved (Implementation Pending).</p>";
        }
    }

    // --- Process Reject Request (Example Placeholder) ---
     elseif (isset($_POST['reject_request_id'])) {
        $req_id = filter_input(INPUT_POST, 'reject_request_id', FILTER_VALIDATE_INT);
         if ($req_id) {
            // 1. Update request status in 'transfer' table to 'Rejected'
            // 2. Add reason for rejection?
            // 3. Notify requester
            echo "<p class='message success'>Request ID {$req_id} rejected (Implementation Pending).</p>";
         }
    }


    // --- Generate Report (Placeholder) ---
    elseif (isset($_POST['generate_report'])) {
        echo "<h2>Generate Report</h2>";
        echo "<p><i>Report generation functionality not yet implemented.</i></p>";
        // Add options for different reports (e.g., All Assets, Assets by Department, User List)
        // Fetch data using SQL and format as HTML table or CSV export.
    }

    // --- Transfer Asset (Placeholder) ---
    elseif (isset($_POST['transfer_asset'])) {
        echo "<h2>Transfer Asset</h2>";
        echo "<p><i>Asset transfer functionality not yet implemented. Requires forms to select asset, source, destination, reason, etc.</i></p>";
    }

} // End POST handling

$conn->close(); // Close the database connection
?>
</div> <!-- /container -->
</body>
</html>