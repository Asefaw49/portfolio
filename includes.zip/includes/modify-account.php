<?php
include 'header.php';
include 'db.php';

// Check if user is logged in (any role allowed)
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

// Allowed roles
$allowed_roles = ['Administrator', 'User', 'Storekeeper', 'Stock Manager', 'Manager'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: login.php"); // Redirect if role is not allowed
    exit();
}

$user_id = $_SESSION['UserID'];

// Function to fetch user data
function fetchUserData($conn, $user_id) {
    $sql = "SELECT UserID, Username, FirstName, LastName, Department, Campus, Phone, role FROM user WHERE UserID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        return $result->fetch_assoc();
    } else {
        return null;
    }
}

// Fetch user details
$user_data = fetchUserData($conn, $user_id);

if (!$user_data) {
    header("Location: index.php"); // Redirect if user data not found
    exit();
}

// Fetch user settings
$settings_sql = "SELECT EnableEmailNotifications, EnableSMSNotifications FROM user_settings WHERE UserID = ?";
$settings_stmt = $conn->prepare($settings_sql);
$settings_stmt->bind_param("i", $user_id);
$settings_stmt->execute();
$settings_result = $settings_stmt->get_result();
if ($settings_result->num_rows == 1) {
    $settings_data = $settings_result->fetch_assoc();
    $enable_email = $settings_data['EnableEmailNotifications'];
    $enable_sms = $settings_data['EnableSMSNotifications'];
} else {
    // Default settings if not found
    $enable_email = 1;
    $enable_sms = 0;
}
$settings_stmt->close();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $first_name = htmlspecialchars($_POST['first_name']);
    $last_name = htmlspecialchars($_POST['last_name']);
    $department = htmlspecialchars($_POST['department']);
    $campus = htmlspecialchars($_POST['campus']);
    $phone = htmlspecialchars($_POST['phone']);
    $enable_email = isset($_POST['enable_email']) ? 1 : 0;
    $enable_sms = isset($_POST['enable_sms']) ? 1 : 0;

    // Password validation
    $password_error = "";
    if (!empty($password) || !empty($confirm_password)) {
        if (strlen($password) < 8 || !preg_match('/[a-zA-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
            $password_error = "Password must be at least 8 characters long and contain at least one letter and one number.";
        } elseif ($password !== $confirm_password) {
            $password_error = "Passwords do not match.";
        }
    }

    if (empty($password_error)) {
        // Determine which fields can be updated based on the user's role
        $updatable_fields = ['FirstName' => $first_name, 'LastName' => $last_name, 'Department' => $department, 'Campus' => $campus, 'Phone' => $phone];
        if ($_SESSION['role'] === 'Administrator') {
            $updatable_fields['Username'] = $username;
        }

        // Build the SQL query dynamically
        $update_sql = "UPDATE user SET ";
        $updates = [];
        $update_params = "";
        $update_values = [];

        foreach ($updatable_fields as $field => $value) {
            $updates[] = "$field = ?";
            $update_params .= "s"; // All fields are treated as strings for simplicity and security
            $update_values[] = $value;
        }

        $update_sql .= implode(", ", $updates);

        // Hash the password if provided and valid
        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $update_sql .= ", Password = ?";
            $update_params .= "s";
            $update_values[] = $hashed_password;
        }

        $update_sql .= " WHERE UserID = ?";
        $update_params .= "i";
        $update_values[] = $user_id;

        $stmt = $conn->prepare($update_sql);

        // Dynamically bind parameters
        if ($stmt) {
            $stmt->bind_param($update_params, ...$update_values);

            if ($stmt->execute()) {
                // Update user settings
                $settings_update_sql = "INSERT INTO user_settings (UserID, EnableEmailNotifications, EnableSMSNotifications) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE EnableEmailNotifications = ?, EnableSMSNotifications = ?";
                $settings_update_stmt = $conn->prepare($settings_update_sql);
                $settings_update_stmt->bind_param("iiiii", $user_id, $enable_email, $enable_sms, $enable_email, $enable_sms);
                $settings_update_stmt->execute();
                $settings_update_stmt->close();

                $success_message = "Account updated successfully!";

                // Refresh user data
                $user_data = fetchUserData($conn, $user_id);

            } else {
                $error_message = "Error updating account: " . $stmt->error;
                error_log("Update account error: " . $stmt->error); // Log the error
            }
            $stmt->close();
        } else {
            $error_message = "Error preparing statement: " . $conn->error;
            error_log("Prepare statement error: " . $conn->error); // Log the error
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modify Account - Property Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* General Styling */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: white;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .container {
            padding: 2rem 1rem;
        }

        .form-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            padding: 2rem;
            max-width: 600px;
            width: 100%;
            color: #fff;
        }

        .form-container:hover {
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
        }

        h3 {
            color: #2c7a7b;
            font-size: 1.75rem;
            font-weight: 600;
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .success, .error {
            padding: 0.75rem 1rem;
            font-size: 0.95rem;
            border-radius: 8px;
            margin-bottom: 1.25rem;
            text-align: center;
        }

        .success {
            background-color: #e6fffa;
            color: #2f855a;
        }

        .error {
            background-color: #ffe6e6;
            color: #c53030;
        }

        .form-label {
            font-weight: 500;
            color: #2d3748;
        }

        .form-control {
            border-radius: 0.5rem;
            padding: 0.6rem 0.75rem;
            border: 1px solid #cbd5e0;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            border-color: #319795;
            box-shadow: 0 0 0 0.2rem rgba(50, 151, 149, 0.25);
        }

        .btn-custom {
            background-color: #2c7a7b;
            border: none;
            color: #fff;
            padding: 0.75rem;
            font-size: 1.125rem;
            border-radius: 0.5rem;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .btn-custom:hover {
            background-color: #285e61;
            transform: scale(1.03);
        }

        .back-link {
            margin-top: 30px;
            display: block;
            text-align: center;
            background-color: #2c3e50;
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s ease;
        }

        .back-link:hover {
            color: #fff;
            text-decoration: underline;
        }

        footer {
            background: #2d3748;
            color: #e2e8f0;
            text-align: center;
            padding: 1rem;
            font-size: 0.875rem;
            margin-top: auto;
            width: 100%;
        }

        footer a {
            color: #81e6d9;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 576px) {
            .form-container {
                padding: 1.5rem;
            }

            h3 {
                font-size: 1.5rem;
            }

            .btn-custom {
                font-size: 1rem;
            }

            .back-link {
                font-size: 0.875rem;
            }
        }
    </style>
</head>
<body>

    <div class="content-wrapper">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6 col-lg-5">
                    <div class="form-container">
                        <h3><i class="fas fa-cogs"></i>Modify Account</h3>
                        <?php if (isset($success_message)): ?>
                            <p class="success"><?php echo $success_message; ?></p>
                        <?php endif; ?>
                        <?php if (isset($error_message)): ?>
                            <p class="error"><?php echo $error_message; ?></p>
                        <?php endif; ?>
                        <?php if (isset($password_error)): ?>
                            <p class="error"><?php echo $password_error; ?></p>
                        <?php endif; ?>

                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

                            <?php if ($_SESSION['role'] === 'Administrator'): ?>
                                <div class="mb-3">
                                    <label for="username" class="form-label"><i class="fas fa-user"></i>Username:</label>
                                    <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user_data['Username']); ?>" required>
                                </div>
                            <?php endif; ?>

                            <div class="mb-3">
                                <label for="password" class="form-label"><i class="fas fa-key"></i>Password:</label>
                                <input type="password" class="form-control" id="password" name="password">
                            </div>

                            <div class="mb-3">
                                <label for="confirm_password" class="form-label"><i class="fas fa-key"></i>Confirm Password:</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                            </div>

                            <div class="mb-3">
                                <label for="first_name" class="form-label">First Name:</label>
                                <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo htmlspecialchars($user_data['FirstName']); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="last_name" class="form-label">Last Name:</label>
                                <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo htmlspecialchars($user_data['LastName']); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="department" class="form-label">Department:</label>
                                <input type="text" class="form-control" id="department" name="department" value="<?php echo htmlspecialchars($user_data['Department']); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="campus" class="form-label">Campus:</label>
                                <input type="text" class="form-control" id="campus" name="campus" value="<?php echo htmlspecialchars($user_data['Campus']); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="phone" class="form-label"><i class="fas fa-phone"></i>Phone:</label>
                                <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($user_data['Phone']); ?>" required>
                            </div>

                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="enable_email" name="enable_email" <?php echo $enable_email ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="enable_email"><i class="fas fa-envelope"></i>Enable Email Notifications</label>
                            </div>

                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="enable_sms" name="enable_sms" <?php echo $enable_sms ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="enable_sms"><i class="fas fa-sms"></i>Enable SMS Notifications</label>
                            </div>

                            <button type="submit" name="submit_update_account" class="btn btn-custom text-white w-100"><i class="fas fa-save"></i>Update Account</button>
                        </form>

                        <a href="<?php echo $_SESSION['role'] === 'Administrator' ? 'admin_dashboard.php' : ($_SESSION['role'] === 'Storekeeper' ? 'storekeeper_dashboard.php' : ($_SESSION['role'] === 'Stock Manager' ? 'stockmanager_dashboard.php' : ($_SESSION['role'] === 'Manager' ? 'manager_dashboard.php' : 'user_dashboard.php'))); ?>" class="back-link d-block mt-3"><i class="fas fa-sign-out-alt"></i>Back to Dashboard</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer>
        © <?php echo date('Y'); ?> Property Management System | All Rights Reserved
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>