<?php
include 'header.php';
include 'db.php';

if ($_SESSION['role'] !== 'Stock Manager') {
    header("Location: login.php");
    exit();
}

$results = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $search = $_POST['search'];
    $sql = "SELECT * FROM stock_recorded WHERE Name LIKE ?";
    $stmt = $conn->prepare($sql);
    $like = "%$search%";
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $results = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Stock</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f7fc;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        input {
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 8px;
            width: 70%;
        }

        button {
            padding: 12px 20px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        .no-results {
            text-align: center;
            color: #666;
            font-style: italic;
        }

        @media (max-width: 600px) {
            .container {
                margin: 20px;
                padding: 15px;
            }

            h2 {
                font-size: 1.5rem;
            }

            input {
                width: 60%;
            }

            button {
                font-size: 14px;
                padding: 10px;
            }

            table {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Search Stock</h2>
    <form method="POST">
        <input type="text" name="search" placeholder="Search stock by name" required>
        <button type="submit">Search</button>
    </form>

    <?php if (!empty($results)) : ?>
        <table>
            <tr>
                <th>Stock ID</th>
                <th>Model Name</th>
                <th>Name</th>
                <th>Quantity</th>
                <th>Cost</th>
                <th>SafeGard</th>
            </tr>
            <?php while ($row = $results->fetch_assoc()) : ?>
                <tr>
                    <td><?= htmlspecialchars($row['StockID']) ?></td>
                    <td><?= htmlspecialchars($row['ModelName']) ?></td>
                    <td><?= htmlspecialchars($row['Name']) ?></td>
                    <td><?= htmlspecialchars($row['Quantity']) ?></td>
                    <td><?= htmlspecialchars($row['Cost']) ?></td>
                    <td><?= htmlspecialchars($row['SafeGard']) ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST') : ?>
        <p class="no-results">No stock found matching your search.</p>
    <?php endif; ?>

    <a href="<?php echo ($_SESSION['role'] === 'Storekeeper' ? 'storekeeper_dashboard.php' : 'stockmanager_dashboard.php'); ?>" class="back-link d-block mt-3"><i class="fas fa-sign-out-alt"></i> Back to Dashboard</a>
</div>

</body>
</html>
