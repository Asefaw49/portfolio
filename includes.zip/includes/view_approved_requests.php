<?php
// Ensure session is started at the very beginning
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include 'db.php'; // Should establish $conn. CRITICAL: Check this file for syntax errors.

// Check if user is logged in
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

// Allowed roles for this page
$allowed_roles = ['Storekeeper', 'Stock Manager', 'Manager']; 
if (!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: login.php"); // Redirect if role not allowed
    exit();
}

// Determine the correct dashboard link based on role


// SQL query to fetch processed asset transfers
// IMPORTANT: This query assumes the 'transferred_assets' table HAS a column 
// named 'approved_by_user_id'. If missing, the query will fail (but not with a parse error).
$sql = "SELECT
            ta.transfer_id AS OriginalRequestID,
            ta.asset_id AS AssetCode,
            a.AssetName,
            ta.quantity AS Quantity,
            ta.status AS Status,
            DATE_FORMAT(ta.transfer_date, '%Y-%m-%d %H:%i') as ProcessedDate,
            ta.from_location AS FromLocation,
            ta.to_location AS ToLocation,
            u_req.Username AS RequestedBy,
            u_appr.Username AS ProcessedBy
        FROM transferred_assets ta
        JOIN asset a ON ta.asset_id = a.AssetCode
        LEFT JOIN user u_req ON ta.user_id = u_req.UserID
        LEFT JOIN user u_appr ON ta.approved_by_user_id = u_appr.UserID
        WHERE ta.status IN ('completed', 'rejected') 
        ORDER BY ta.transfer_date DESC";

$query_result = null; // Changed variable name to avoid conflict if $result was used before
$error_message_db = ''; // For database query errors

if ($conn) {
    $query_result = $conn->query($sql);
    if ($query_result === false) {
        // Log the detailed error for the admin, prepare a generic message for the user.
        $error_message_db = "Database query failed. Please contact an administrator.";
        error_log("SQL Error in view_approved_requests.php: " . $conn->error . " (Query: " . $sql . ")");
    }
} else {
    $error_message_db = "Database connection failed. Please contact an administrator.";
    error_log("Database connection failed in view_approved_requests.php.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Processed Asset Transfers</title>
    <style>
        :root {
            --primary-color:rgb(31, 33, 36); 
            --success-color:rgba(18, 235, 83, 0.92); 
            --danger-color: #dc3545;   
            --secondary-color: #6c757d; 
            --bg-color: #f8f9fa;
            --white: #ffffff;
            --table-header-bg: var(--primary-color);
            --table-border: #dee2e6;
            --hover-color: #e9ecef;
            --shadow-color: rgba(0, 0, 0, 0.1);
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-color);
            color: var(--secondary-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1100px; 
            margin: 40px auto;
            padding: 30px;
            background-color: var(--white);
            border-radius: 12px;
            box-shadow: 0 6px 18px var(--shadow-color);
            animation: fadeIn 0.5s ease-in-out;
        }

        h2 {
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 30px;
            font-size: 26px;
            font-weight: 600;
        }

        .table-container { /* Added for potential overflow handling */
            overflow-x: auto;
            margin-bottom: 1.5rem;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            border-radius: 8px;
            overflow: hidden; 
        }

        .table th,
        .table td {
            padding: 12px 15px; 
            text-align: left;
            border-bottom: 1px solid var(--table-border);
        }

        .table th {
            background-color: var(--table-header-bg);
            color: white;
            font-size: 13px; 
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table tbody tr:hover {
            background-color: var(--hover-color);
        }

        .table tbody tr:last-child td {
            border-bottom: none; 
        }

        .status-completed {
            color: var(--success-color);
            font-weight: bold;
        }
        .status-rejected {
            color: var(--danger-color);
            font-weight: bold;
        }

        .back-btn {
            display: inline-block;
            margin-top: 30px;
            text-align: center;
            text-decoration: none;
            color:black;
            font-weight: 600;
            padding: 10px 20px;
            border: 2px solid var(--primary-color);
            border-radius: 8px;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.2s ease;
        }

      
        
        .message-area { /* For general messages like no data or errors */
            text-align: center;
            padding: 1rem;
            margin-top: 20px;
            border-radius: 8px;
        }
        .message-area.error {
            color: var(--danger-color);
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
        }
        .message-area.info {
            color: #0c5460;
            background-color: #d1ecf1;
            border: 1px solid #bee5eb;
        }


        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 992px) { 
            .container { margin: 20px 15px; padding: 20px; }
            h2 { font-size: 22px; }
            .table th, .table td { padding: 10px 8px; font-size: 13px; } 
        }
        @media (max-width: 768px) {
            /* .table { display: block; overflow-x: auto; } */ /* Handled by .table-container */
            .table th, .table td { font-size: 12px; white-space: nowrap; }
            .back-btn { width: 100%; box-sizing: border-box; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>View Request Asset </h2>

        <?php
        // This is line 25 in the user's original code block (echo '<div class="container">';)
        // This is line 26 in the user's original code block (echo "<h2>Processed Asset Transfers</h2>";)
        // The actual output of these is now handled by the surrounding HTML structure.
        // We will now display the table or messages based on the query.

        if (!empty($error_message_db)): ?>
            <div class="message-area error">
                <p><?php echo htmlspecialchars($error_message_db); ?></p>
            </div>
        <?php elseif ($query_result && $query_result->num_rows > 0): ?>
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Orig. ID</th>
                            <th>Asset Name</th>
                            <th>Asset Code</th>
                            <th>Quantity</th>
                            <th>Status</th>
                            <th>Processed Date</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Requested By</th>
                            <th>Processed By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $query_result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row["OriginalRequestID"]) ?></td>
                                <td><?= htmlspecialchars($row["AssetName"]) ?></td>
                                <td><?= htmlspecialchars($row["AssetCode"]) ?></td>
                                <td><?= htmlspecialchars($row["Quantity"]) ?></td>
                                <?php
                                    $statusClass = '';
                                    $statusText = '';
                                    if ($row["Status"] === 'completed') {
                                        $statusClass = 'status-completed';
                                        $statusText = 'Approved';
                                    } elseif ($row["Status"] === 'rejected') {
                                        $statusClass = 'status-rejected';
                                        $statusText = 'Rejected';
                                    } else {
                                        $statusText = htmlspecialchars($row["Status"]); // Fallback
                                    }
                                ?>
                                <td class="<?= htmlspecialchars($statusClass) ?>"><?= htmlspecialchars($statusText) ?></td>
                                <td><?= htmlspecialchars($row["ProcessedDate"]) ?></td>
                                <td><?= htmlspecialchars($row["FromLocation"]) ?></td>
                                <td><?= htmlspecialchars($row["ToLocation"]) ?></td>
                                <td><?= htmlspecialchars($row["RequestedBy"] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($row["ProcessedBy"] ?? 'N/A') ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="message-area info">
                <p>No processed (approved or rejected) asset transfers found.</p>
            </div>
        <?php endif; ?>

        <a href="<?php echo ($_SESSION['role'] === 'Storekeeper' ? 'storekeeper_dashboard.php' : ($_SESSION['role'] === 'Stock Manager' ? 'stockmanager_dashboard.php' : 'default_dashboard.php')); ?>" class="back-link d-block mt-3"><i class="fas fa-sign-out-alt"></i>Back to Dashboard</a>

    </div>
</body>
</html>