<?php
// It's good practice to start sessions if your header.php or overall admin area relies on them.
// session_start(); 

include 'db.php'; // Ensure this file correctly establishes $conn
include 'header.php'; // Your common header file

$add_message = "";
$remove_message = "";
$errors = []; // For validation errors

// Define available roles from your ENUM for the dropdown
$available_roles = ['User', 'Storekeeper', 'Stock Manager', 'Manager', 'Administrator'];


// --- Add Account Logic ---
if (isset($_POST['submit_add_account'])) {
    $username = trim($_POST['username'] ?? '');
    $password_raw = $_POST['password'] ?? ''; // Raw password
    $firstName = trim($_POST['first_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $campus = trim($_POST['campus'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = trim($_POST['role'] ?? '');

    // --- Validation ---
    if (empty($username)) { $errors[] = "Username is required."; }
    if (empty($password_raw)) { $errors[] = "Password is required."; }
    elseif (strlen($password_raw) < 6) { $errors[] = "Password must be at least 6 characters long."; }
    if (empty($firstName)) { $errors[] = "First Name is required."; }
    // LastName can be empty based on your sample data, so no 'empty' check unless you want to enforce it.
    if (empty($department)) { $errors[] = "Department is required."; }
    if (empty($campus)) { $errors[] = "Campus is required."; }
    if (empty($phone)) { $errors[] = "Phone number is required."; }
    if (empty($email)) { 
        $errors[] = "Email is required."; 
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }
    if (empty($role) || !in_array($role, $available_roles)) { $errors[] = "A valid role must be selected."; }

    // Check for uniqueness if no basic validation errors
    if (empty($errors)) {
        // Check Username uniqueness
        $stmt_check = $conn->prepare("SELECT UserID FROM user WHERE Username = ?");
        $stmt_check->bind_param("s", $username);
        $stmt_check->execute();
        if ($stmt_check->get_result()->num_rows > 0) {
            $errors[] = "Username already exists.";
        }
        $stmt_check->close();

        // Check Phone uniqueness
        $stmt_check = $conn->prepare("SELECT UserID FROM user WHERE Phone = ?");
        $stmt_check->bind_param("s", $phone);
        $stmt_check->execute();
        if ($stmt_check->get_result()->num_rows > 0) {
            $errors[] = "Phone number already registered.";
        }
        $stmt_check->close();

        // Check Email uniqueness (if not empty, though we made it required above)
        if (!empty($email)) {
            $stmt_check = $conn->prepare("SELECT UserID FROM user WHERE Email = ?");
            $stmt_check->bind_param("s", $email);
            $stmt_check->execute();
            if ($stmt_check->get_result()->num_rows > 0) {
                $errors[] = "Email address already registered.";
            }
            $stmt_check->close();
        }
    }


    if (empty($errors)) {
        // Hash the password securely
        $hashed_password_for_db = password_hash($password_raw, PASSWORD_DEFAULT);

        $sql = "INSERT INTO user (Username, Password, FirstName, LastName, Department, Campus, Phone, Email, role)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        // Note: 'role' is lowercase in your DB schema.
        $stmt->bind_param("sssssssss", $username, $hashed_password_for_db, $firstName, $lastName, $department, $campus, $phone, $email, $role);

        if ($stmt->execute()) {
            $add_message = "<p class='msg success'><i class='fas fa-check-circle'></i> Account added successfully!</p>";
        } else {
            // Log detailed error for admin, show generic error to user
            error_log("Error adding account: " . $stmt->error);
            $add_message = "<p class='msg error'><i class='fas fa-times-circle'></i> Error adding account. Please check server logs or try again.</p>";
        }
        $stmt->close();
    } else {
        // Prepare error messages for display
        $add_message = "<div class='msg error'><i class='fas fa-exclamation-triangle'></i> Please correct the following errors:<ul>";
        foreach ($errors as $error) {
            $add_message .= "<li>" . htmlspecialchars($error) . "</li>";
        }
        $add_message .= "</ul></div>";
    }
}

// --- Remove Account Logic ---
if (isset($_POST['submit_remove_account'])) {
    $user_id_to_remove = intval($_POST['user_to_remove']);

    // Optional: Add a check to prevent deleting a super admin or the currently logged-in admin.
    // For example: if ($user_id_to_remove == $_SESSION['UserID']) { /* don't allow */ }

    if ($user_id_to_remove > 0) {
        $sql = "DELETE FROM user WHERE UserID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id_to_remove);

        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $remove_message = "<p class='msg success'><i class='fas fa-check-circle'></i> Account removed successfully!</p>";
            } else {
                $remove_message = "<p class='msg warning'><i class='fas fa-exclamation-triangle'></i> No account found with that ID or no changes made.</p>";
            }
        } else {
            error_log("Error removing account: " . $stmt->error);
            $remove_message = "<p class='msg error'><i class='fas fa-times-circle'></i> Error removing account. Please check server logs or try again.</p>";
        }
        $stmt->close();
    } else {
        $remove_message = "<p class='msg error'><i class='fas fa-times-circle'></i> Invalid user selected for removal.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Accounts - Property Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Icons & Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f7f6; /* Light background for better contrast */
            color: #333;
            line-height: 1.6;
        }

        /* Assuming header.php might have its own styles, or you might put common styles there */
        /* Styles from your original code, slightly adjusted for clarity */

        .page-header { /* This class was in your HTML but not styled, assuming it's for a title bar */
            background-color: #2c3e50; /* Dark blue header */
            color: white;
            padding: 1.5rem 1rem;
            text-align: center;
            margin-bottom: 2rem; /* Space below header */
        }
        .page-header h1 {
            margin: 0;
            font-size: 1.8rem;
        }

        .container {
            display: flex;
            justify-content: center; /* Center sections if space allows */
            gap: 30px;
            flex-wrap: wrap; /* Allow sections to wrap on smaller screens */
            padding: 0 2rem 2rem 2rem; /* Padding around the content area */
            max-width: 1200px; /* Max width for the container */
            margin: 0 auto; /* Center the container */
        }

        .section {
            background: #ffffff; /* White background for sections */
            padding: 2rem;
            border-radius: 15px; /* Softer corners */
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1); /* Softer shadow */
            flex: 1; /* Allow sections to grow */
            min-width: 320px; /* Minimum width before wrapping */
            max-width: 500px; /* Maximum width for a section */
            margin-bottom: 20px; /* Space between stacked sections on mobile */
        }

        .section h2 {
            color: #2c3e50; /* Dark blue for section titles */
            margin-top: 0; /* Remove default top margin */
            margin-bottom: 1.5rem; /* Space below title */
            font-size: 1.5rem; /* Slightly larger section titles */
            border-bottom: 2px solid #e0e0e0; /* Separator line */
            padding-bottom: 0.5rem;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px; /* Increased gap for better spacing */
        }

        label {
            color: #333; /* Dark gray for labels */
            font-weight: 600; /* Slightly bolder labels */
            font-size: 0.9rem;
            margin-bottom: -5px; /* Pull label closer to input */
        }

        input[type="text"],
        input[type="password"],
        input[type="tel"],
        input[type="email"],
        select {
            padding: 12px; /* More padding */
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 1rem; /* Standard font size */
            width: 100%; /* Full width */
            box-sizing: border-box; /* Include padding and border in element's total width and height */
        }
        input:focus, select:focus {
            border-color: #2c3e50;
            outline: none;
            box-shadow: 0 0 0 2px rgba(44, 62, 80, 0.2);
        }


        input[type="submit"] {
            background-color: #3498db; /* Primary button color (e.g., blue) */
            color: white;
            font-weight: bold;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            padding: 12px 20px;
            font-size: 1rem;
            border-radius: 8px;
        }
        input[type="submit"]:hover {
            background-color: #2980b9; /* Darker shade on hover */
            transform: translateY(-1px);
        }
        /* Specific style for remove button if desired */
        input[name="submit_remove_account"] {
            background-color: #e74c3c; /* Red for remove/delete actions */
        }
        input[name="submit_remove_account"]:hover {
            background-color: #c0392b; /* Darker red on hover */
        }


        .back-button {
            display: inline-block;
            margin-top: 20px;
            background-color: #7f8c8d; /* Neutral/secondary color */
            padding: 10px 20px;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s ease;
            text-align: center;
        }
        .back-button:hover {
            background-color: #6c7a7b; /* Darker shade for hover */
        }

        .msg {
            margin-top: 15px;
            font-weight: 500; /* Normal weight for messages */
            padding: 12px 15px;
            border-radius: 8px;
            font-size: 0.95rem;
            border-left-width: 5px;
            border-left-style: solid;
        }
        .msg ul {
            margin-bottom: 0;
            padding-left: 20px;
        }

        .success {
            background-color: #d4edda; /* Light green */
            color: #155724; /* Dark green text */
            border-left-color: #28a745; /* Green border */
        }
        .error {
            background-color: #f8d7da; /* Light red */
            color: #721c24; /* Dark red text */
            border-left-color: #dc3545; /* Red border */
        }
        .warning { /* For messages like 'user not found' */
            background-color: #fff3cd; /* Light yellow */
            color: #856404; /* Dark yellow text */
            border-left-color: #ffc107; /* Yellow border */
        }


        footer {
            text-align: center;
            padding: 1.5rem 1rem;
            background-color: #1a1a1a; /* Dark footer */
            color: #ccc; /* Light text for footer */
            margin-top: 2rem; /* Space above footer */
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                align-items: stretch; /* Stretch sections to full width */
                padding: 0 1rem 1rem 1rem;
            }
            .section {
                max-width: 100%; /* Allow sections to take full width */
            }
        }
    </style>
</head>
<body>

    <!-- This page-header div was in your HTML, assuming it's for the main page title -->
    <div class="page-header">
        <h1><i class="fas fa-user-cog"></i> Manage Accounts</h1>
    </div>

    <div class="container">
        <!-- Add Account Form -->
        <div class="section">
            <h2><i class="fas fa-user-plus"></i> Add New Account</h2>
            <?php if(isset($_POST['submit_add_account'])) { echo $add_message; } // Display message only after form submission attempt ?>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required>
                
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                
                <label for="first_name">First Name:</label>
                <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($_POST['first_name'] ?? ''); ?>" required>
                
                <label for="last_name">Last Name:</label>
                <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($_POST['last_name'] ?? ''); ?>">
                
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>

                <label for="department">Department:</label>
                <input type="text" id="department" name="department" value="<?php echo htmlspecialchars($_POST['department'] ?? ''); ?>" required>
                
                <label for="campus">Campus:</label>
                <input type="text" id="campus" name="campus" value="<?php echo htmlspecialchars($_POST['campus'] ?? ''); ?>" required>
                
                <label for="phone">Phone:</label>
                <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>" required>
                
                <label for="role">Role:</label>
                <select id="role" name="role" required>
                    <option value="">-- Select Role --</option>
                    <?php foreach ($available_roles as $role_option): ?>
                        <option value="<?php echo htmlspecialchars($role_option); ?>" <?php echo (isset($_POST['role']) && $_POST['role'] == $role_option) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($role_option); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <input type="submit" name="submit_add_account" value="Add Account">
            </form>
            <a href="admin_dashboard.php" class="back-button"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>

        <!-- Remove Account Form -->
        <div class="section">
            <h2><i class="fas fa-user-minus"></i> Remove Account</h2>
            <?php if(isset($_POST['submit_remove_account'])) { echo $remove_message; } // Display message only after form submission attempt ?>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" onsubmit="return confirm('Are you sure you want to remove this account? This action cannot be undone.');">
                <label for="user_to_remove">Select User to Remove:</label>
                <select id="user_to_remove" name="user_to_remove" required>
                    <option value="">-- Select User --</option>
                    <?php
                    // Fetch users for the dropdown
                    $result = $conn->query("SELECT UserID, Username, FirstName, LastName FROM user ORDER BY Username ASC");
                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $display_name = htmlspecialchars($row['Username']) . " (" . htmlspecialchars($row['FirstName']) . " " . htmlspecialchars($row['LastName']) . ")";
                            echo "<option value='" . htmlspecialchars($row['UserID']) . "'>" . $display_name . "</option>";
                        }
                    } else {
                        echo "<option value=''>No users found</option>";
                    }
                    ?>
                </select>
                <input type="submit" name="submit_remove_account" value="Remove Account">
            </form>
        </div>
    </div>

    <footer>
        &copy; <?php echo date('Y'); ?> Property Management System. All Rights Reserved.
        <!-- Changed from Asset Management to Property Management to match other pages -->
    </footer>
</body>
</html>