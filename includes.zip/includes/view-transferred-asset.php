<?php
include 'header.php';
include 'db.php';

// Authentication check
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'User') {
    header("Location: login.php");
    exit();
}

// Fetch transferred assets for logged in user
$userID = $_SESSION['UserID'];
$query = "SELECT TransferID, AssetCode, ToOwnerFirstName, ToOwnerLastName, 
                 FromOwnerFirstName, FromOwnerLastName, Quantity, Reason, 
                 IssueDate, ReturnDate, Observer
          FROM transfer
          WHERE UserID = ?
          ORDER BY IssueDate DESC";

$stmt = $conn->prepare($query);
if ($stmt) {
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $error = $conn->error;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Transferred Assets</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
    :root {
        --primary-color: #f8f9fa;
        --secondary-color: #e9ecef;
        --accent-color: #6c757d;
        --dark-color: #343a40;
        --text-dark: #212529;
        --text-light: #495057;
        --card-bg: #ffffff;
        --success-color: #28a745;
        --warning-color: #ffc107;
        --danger-color: #dc3545;
        --info-color: #17a2b8;
        --transition-speed: 0.3s;
        --sidebar-width: 250px;
        --border-radius: 8px;
        --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body {
        background-color: var(--primary-color);
        color: var(--text-dark);
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }

    .main-content {
        flex: 1;
        margin-left: var(--sidebar-width);
        padding: 30px;
        min-height: calc(100vh - 60px);
    }

    .content-header {
        margin-bottom: 30px;
    }

    .content-header h1 {
        font-size: 2rem;
        color: var(--text-dark);
        margin-bottom: 10px;
    }

    .asset-table-container {
        background-color: var(--card-bg);
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
        padding: 20px;
        overflow-x: auto;
        margin-bottom: 20px;
    }

    .asset-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.9rem;
    }

    .asset-table th {
        background-color: var(--accent-color);
        color: white;
        padding: 12px 15px;
        text-align: left;
    }

    .asset-table td {
        padding: 12px 15px;
        border-bottom: 1px solid #dee2e6;
        color: var(--text-light);
    }

    .asset-table tr:nth-child(even) {
        background-color: rgba(0, 0, 0, 0.02);
    }

    .asset-table tr:hover {
        background-color: rgba(0, 0, 0, 0.05);
    }

    .back-btn {
        display: inline-flex;
        align-items: center;
        padding: 10px 20px;
        background-color: var(--accent-color);
        color: white;
        text-decoration: none;
        border-radius: var(--border-radius);
        transition: all var(--transition-speed);
        border: none;
        cursor: pointer;
        font-size: 0.9rem;
    }

    .back-btn:hover {
        background-color: #5a6268;
        transform: translateY(-2px);
    }

    .back-btn i {
        margin-right: 8px;
    }

    .no-transfers {
        text-align: center;
        padding: 30px;
        color: var(--text-light);
        background-color: var(--card-bg);
        border-radius: var(--border-radius);
        box-shadow: var(--box-shadow);
    }

    .error-message {
        background-color: #f8d7da;
        color: var(--danger-color);
        padding: 15px;
        border-radius: var(--border-radius);
        margin-bottom: 20px;
        border-left: 4px solid var(--danger-color);
    }

    footer {
        text-align: center;
        padding: 20px;
        background-color: var(--dark-color);
        color: white;
        font-size: 14px;
        margin-left: var(--sidebar-width);
    }
    </style>
</head>
<body>
    <!-- Main Content -->
    <main class="main-content">
        <div class="content-header">
            <h1>Transferred Assets</h1>
        </div>
        
        <div class="asset-table-container">
            <?php if (isset($error)): ?>
                <div class="error-message">
                    <p><strong>Database Error:</strong> <?php echo htmlspecialchars($error); ?></p>
                    <p>The system cannot display transferred assets at this time.</p>
                </div>
            <?php elseif (isset($result) && $result->num_rows > 0): ?>
                <table class="asset-table">
                    <thead>
                        <tr>
                            <th>Asset Code</th>
                            <th>Quantity</th>
                            <th>To Owner</th>
                            <th>From Owner</th>
                            <th>Issue Date</th>
                            <th>Return Date</th>
                            <th>Reason</th>
                            <th>Observer</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['AssetCode']); ?></td>
                                <td><?php echo htmlspecialchars($row['Quantity']); ?></td>
                                <td><?php echo htmlspecialchars($row['ToOwnerFirstName'] . ' ' . $row['ToOwnerLastName']); ?></td>
                                <td><?php echo htmlspecialchars($row['FromOwnerFirstName'] . ' ' . $row['FromOwnerLastName']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($row['IssueDate'])); ?></td>
                                <td>
                                    <?php 
                                    echo $row['ReturnDate'] ? date('M d, Y', strtotime($row['ReturnDate'])) : '<span style="color:var(--warning-color);font-weight:bold;">Not Returned</span>'; 
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($row['Reason']); ?></td>
                                <td><?php echo htmlspecialchars($row['Observer']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-transfers">
                    <p>No asset transfers found for your account.</p>
                </div>
            <?php endif; ?>
        </div>
        
       
    </main>

    <footer>
        &copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.
    </footer>
</body>
</html>
<?php
if (isset($stmt)) {
    $stmt->close();
}
$conn->close();
?>
