<footer>
    <p>&copy; 2025 Asset Management System. All Rights Reserved.</p>
</footer>