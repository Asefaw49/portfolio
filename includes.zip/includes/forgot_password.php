<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["Email"];

    // Check if email exists in the database
    $stmt = $conn->prepare("SELECT UserID FROM user WHERE Email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($userID); // Bind the result variable
        $stmt->fetch(); // Fetch the result

        $stmt->close(); // Close the first statement

        // Delete old reset tokens
        $delete_old_tokens = $conn->prepare("DELETE FROM password_reset WHERE Email = ?");
        $delete_old_tokens->bind_param("s", $email);
        $delete_old_tokens->execute();

        // Generate a unique reset token
        $token = bin2hex(random_bytes(50));

        // Get the next available ID (VERY IMPORTANT)
        $result = $conn->query("SELECT MAX(id) FROM password_reset"); // Assuming 'id' is your primary key column
        $row = $result->fetch_row();
        $next_id = $row[0] + 1;

        // Insert new reset token, including the ID
        $insert = $conn->prepare("INSERT INTO password_reset (id, Email, token) VALUES (?, ?, ?)"); // Include 'id' in the INSERT
        $insert->bind_param("iss", $next_id, $email, $token); // 'i' for integer (id), 'ss' for strings (Email, token)


        if ($insert->execute()) {
            // Send reset link to email
            $reset_link = "http://yourwebsite.com/reset_password.php?token=" . $token;
            // Always escape the email address when including it in the mail header
            $escaped_email = filter_var($email, FILTER_SANITIZE_EMAIL);

            $subject = "Password Reset Request";
            $message = "Click here to reset your password: $reset_link";
            $headers = "From: noreply@yourwebsite.com\r\n";  // Replace with your actual 'from' address
            $headers .= "Reply-To: noreply@yourwebsite.com\r\n";
            $headers .= "Content-type: text/html\r\n"; // or text/plain if you are not sending HTML mail

            if (mail($escaped_email, $subject, $message, $headers)) {
                echo "<p class='success'>Password reset link has been sent to your email.</p>";
            } else {
                echo "<p class='error'>Failed to send password reset email.  Please try again later.</p>";
                error_log("Failed to send email to: " . $escaped_email);  // Log the error
            }

        } else {
            echo "<p class='error'>Failed to insert reset token.</p>";
            error_log("MySQL error: " . $insert->error); // Log the MySQL error
        }

        $insert->close();

    } else {
        echo "<p class='error'>Email not found.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh; /* Use min-height to ensure full height even with less content */
            margin: 0; /* Reset default body margin */
        }
        .container {
            background: white;
            padding: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            text-align: center;
            width: 350px;
            max-width: 90%; /* Ensure it doesn't overflow on smaller screens */
        }
        h2 {
            color: #333;
        }
        .error {
            color: red;
            font-size: 14px;
        }
        .success {
            color: green;
            font-size: 14px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box; /*  Important: Include padding and border in the element's total width and height */
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        a {
            display: block;
            margin-top: 15px;
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
    <script>
        function validateForm() {
            var email = document.getElementById("email").value.trim();
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                alert("Please enter a valid email address.");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Forgot Password</h2>
        <form method="post" onsubmit="return validateForm()">
            <label for="email">Enter your email:</label>
            <input type="email" id="email" name="Email" required>
            <input type="submit" value="Send Reset Link">
        </form>
        <a href="login.php">Back to Login</a>
    </div>
</body>
</html>