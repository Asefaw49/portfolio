<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

require_once 'db.php';

$report_data = [];
$message = "";

// Example: Generate a report of all assets
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["generate_report"])) {
    $report_type = $_POST["report_type"];

    if ($report_type == "all_assets") {
        $sql = "SELECT AssetCode, AssetName, ModelName, Type, Cost, Quantity, Status, ExpiryDate FROM asset";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $report_data[] = $row;
            }
            $message = "Report generated successfully.";
        } else {
            $message = "No assets found.";
        }
    }
    // Add more report types here (e.g., assets by type, assets nearing expiry)
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Generate Report</title>
    <style>
        body { font-family: sans-serif; }
        .container { width: 80%; margin: 20px auto; }
        h2 { margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #f0f0f0; }
        .error { color: red; }
        .success { color: green; }
        form { margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Generate Report</h2>

        <?php if ($message): ?>
            <p class="<?php echo (strpos($message, 'Error') !== false) ? 'error' : 'success'; ?>"><?php echo $message; ?></p>
        <?php endif; ?>

        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="report_type">Select Report Type:</label>
            <select id="report_type" name="report_type">
                <option value="all_assets">All Assets</option>
                <!-- Add more report options here -->
            </select>
            <input type="submit" name="generate_report" value="Generate Report">
        </form>

        <?php if (!empty($report_data)): ?>
            <h3>Report Results</h3>
            <table>
                <thead>
                    <tr>
                        <th>Asset Code</th>
                        <th>Asset Name</th>
                        <th>Model Name</th>
                        <th>Type</th>
                        <th>Cost</th>
                        <th>Quantity</th>
                        <th>Status</th>
                        <th>Expiry Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($report_data as $asset): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($asset["AssetCode"]); ?></td>