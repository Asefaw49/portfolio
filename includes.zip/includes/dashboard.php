<?php
include 'header.php';
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['UserID'])) {
    header("Location: login.php");
    exit();
}

// Fetch all transfers for the current user
$userid = $_SESSION['UserID'];

// Updated SQL query with JOIN to get AssetName from the asset table
$sql = "SELECT t.*, a.AssetName FROM transfer t
        JOIN asset a ON t.AssetCode = a.AssetCode
        WHERE t.UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userid);
$stmt->execute();
$result = $stmt->get_result();

// Display the transferred assets
if ($result->num_rows > 0) {
    echo '<h2>Transferred Assets</h2>';
    echo '<table border="1" cellpadding="5" cellspacing="0">';
    echo '<tr><th>Asset Code</th><th>Asset Name</th><th>Quantity</th><th>Transfer Date</th><th>Reason</th><th>From</th><th>To</th></tr>';

    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['AssetCode'] . '</td>';
        echo '<td>' . $row['AssetName'] . '</td>';  // Now displaying the asset name
        echo '<td>' . $row['Quantity'] . '</td>';
        echo '<td>' . $row['IssueDate'] . '</td>';
        echo '<td>' . $row['Reason'] . '</td>';
        echo '<td>' . $row['FromOwnerFirstName'] . ' ' . $row['FromOwnerLastName'] . '</td>';
        echo '<td>' . $row['ToOwnerFirstName'] . ' ' . $row['ToOwnerLastName'] . '</td>';
        echo '</tr>';
    }

    echo '</table>';
} else {
    echo '<p>No assets have been transferred to you.</p>';
}

$stmt->close();
$conn->close();
?>

<a href="user_dashboard.php">Back to Dashboard</a>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transferred Assets</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        a {
            margin-top: 20px;
            display: inline-block;
            text-decoration: none;
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
        }

        a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Dashboard content -->
    </div>
    <p>&copy; <?php echo date("Y"); ?> Asset Management System. All Rights Reserved.</p>
</body>
</html>
