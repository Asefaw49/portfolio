<?php  
include 'db.php'; // Include your database connection
include 'header.php'; // Include your header

// Check if user is Stock Manager
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Stock Manager') {
    header("Location: login.php");
    exit();
}

// Handle add stock
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_stock'])) {
    $model_name = htmlspecialchars($_POST['model_name']);
    $name = htmlspecialchars($_POST['name']);
    $quantity = intval($_POST['quantity']);
    $cost = floatval($_POST['cost']);
    $safe_gard = htmlspecialchars($_POST['safe_gard']);

    $sql = "INSERT INTO stock_recorded (ModelName, Name, Quantity, Cost, SafeGard)
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdds", $model_name, $name, $quantity, $cost, $safe_gard);

    if ($stmt->execute()) {
        echo "<div class='alert success'>Stock added successfully!</div>";
    } else {
        echo "<div class='alert error'>Error adding stock: " . $conn->error . "</div>";
    }
    $stmt->close();
}

// Handle delete stock
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    $sql = "DELETE FROM stock_recorded WHERE StockID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        echo "<div class='alert success'>Stock item deleted successfully!</div>";
    } else {
        echo "<div class='alert error'>Error deleting stock: " . $conn->error . "</div>";
    }
    $stmt->close();
}

// Fetch all stock items
$sql = "SELECT * FROM stock_recorded ORDER BY StockID DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Stock</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .main-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 20px;
        }

        .form-container, .table-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-container {
            flex: 1;
            min-width: 300px;
            max-width: 400px;
        }

        .table-container {
            flex: 2;
            min-width: 600px;
            overflow-x: auto;
        }

        h2 {
            font-size: 22px;
            color: #333;
            margin-bottom: 15px;
            font-weight: 600;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        label {
            font-size: 12px;
            color: #555;
            text-align: left;
            font-weight: bold;
        }

        input[type="text"], input[type="number"], input[type="submit"] {
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            outline: none;
        }

        input[type="submit"] {
            background-color: rgb(15, 15, 15);
            color: white;
            cursor: pointer;
            font-weight: bold;
            border: none;
            transition: background-color 0.3s;
            margin-top: 10px;
        }

        .alert {
            margin: 10px 20px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
        }

        .success {
            background-color: #dff0d8;
            color: #3c763d;
        }

        .error {
            background-color: #f2dede;
            color: #a94442;
        }

        footer {
            text-align: center;
            padding: 0.5rem;
            background: #1a1a1a;
            color: #ccc;
            font-size: 0.8rem;
            margin-top: auto;
        }

        .stock-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        .stock-table th, .stock-table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .stock-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .stock-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .stock-table tr:hover {
            background-color: #f1f1f1;
        }

        .delete-btn {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
            font-size: 12px;
        }

        .back-link {
            display: block;
            margin: 30px auto;
            color: #333;
            text-decoration: none;
            font-weight: bold;
            text-align: center;
            font-size: 14px;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 1000px) {
            .main-container {
                flex-direction: column;
            }

            .form-container, .table-container {
                max-width: 100%;
            }
        }


    </style>
</head>
<body>
    <div class="main-container">
        <div class="form-container">
            <h2>Add New Stock</h2>
            <form method="post" action="">
                <label for="model_name">Model number:</label>
                <input type="text" id="model_name" name="model_name" required>

                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>

                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" required>

                <label for="cost">Cost:</label>
                <input type="number" step="0.01" id="cost" name="cost" required>

                <label for="safe_gard">Safe Gard:</label>
                <input type="text" id="safe_gard" name="safe_gard" required>

                <input type="submit" name="add_stock" value="Add Stock">
            </form>
            
    <!-- Back to Dashboard at bottom -->
    <div style="text-align: center; margin: 20px 0;">
        <a href="<?= ($_SESSION['role'] === 'Storekeeper' ? 'storekeeper_dashboard.php' : 'stockmanager_dashboard.php') ?>" class="back-link">← Back to Dashboard</a>
    </div>
        </div>
        <footer style="
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background: #1a1a1a;
    color: #ccc;
    font-size: 0.8rem;
    text-align: center;
    padding: 0.5rem 0;
    z-index: 1000;
">
    <p>&copy; <?= date('Y') ?> Asset Management System</p>
</footer>
>

</body>
</html>
