document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.querySelector('form');
    const usernameField = document.getElementById('username');
    const passwordField = document.getElementById('password');
    
    loginForm.addEventListener('submit', function (event) {
        // Check if both fields are filled out
        if (usernameField.value.trim() === '' || passwordField.value.trim() === '') {
            event.preventDefault(); // Prevent form submission
            alert('Both username and password are required.');
        }
    });
});
