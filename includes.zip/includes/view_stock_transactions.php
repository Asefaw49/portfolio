<?php  
include 'db.php';
include 'header.php'; // Should include session_start()

if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Stock Manager') {
    header("Location: login.php");
    exit();
}

$result = null; // Initialize $result
if ($conn) { // Check if $conn is valid
    $query = "SELECT * FROM tblstock_in_out ORDER BY STOCKOUTID DESC";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        // It's better to log this error or display a user-friendly message
        // For debugging, you can use: die("Database query failed: " . mysqli_error($conn));
        // For production, a more generic message:
        $db_error_message = "Error retrieving stock records. Please try again later.";
    }
} else {
    $db_error_message = "Database connection error. Please contact support.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock In/Out Records</title>
    <style>
        body {
            margin: 0; padding: 0; font-family: 'Segoe UI', sans-serif; background: #f4f7f6; display: flex;
        }
        .sidebar {
            width: 260px; background: #2c3e50; color: white; padding: 20px; height: 100vh; position: sticky; top: 0; box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .sidebar h2 { color: white; text-align: center; margin-bottom: 30px; font-size: 24px; }
        .main-content {
            flex: 1; padding: 30px; overflow-x: auto; 
        }
        .table-container { 
            background: white; padding: 25px; border-radius: 15px; box-shadow: 0 8px 25px rgba(0,0,0,0.1); margin: 20px auto; max-width: 1200px; /* Max width for larger tables */
        }
        .table-container h2 {
            text-align: center; margin-bottom: 25px; color: #333; font-size: 26px;
        }
        table {
            width: 100%; border-collapse: collapse; background: white;
            border-radius: 10px; overflow: hidden; 
        }
        th, td {
            padding: 14px 18px; text-align: left; border-bottom: 1px solid #e0e0e0; font-size: 15px; 
        }
        th {
            background:rgb(16, 20, 22); color: white; font-weight: 600; text-transform: uppercase; font-size: 14px;
        }
        tr:nth-child(even) { background-color: #f8f9fa; }
        tr:hover { background-color: #e9ecef; }
        
        .sidebar .button-group { display: flex; flex-direction: column; gap: 12px; margin-top: 20px; }
        .sidebar .button { background-color: #3498db; color: white; border: none; padding: 12px 18px; border-radius: 8px; font-size: 16px; font-weight: 500; text-align: left; transition: background-color 0.3s ease, transform 0.2s ease; text-decoration: none; display: flex; align-items: center; gap: 12px; }
        .sidebar .button:hover { background-color: #2980b9; transform: translateY(-2px); }
        .sidebar .logout { display: block; margin-top: 30px; color: #2c3e50; background-color: #ecf0f1; text-decoration: none; font-weight: bold; font-size: 16px; padding: 10px 15px; border-radius: 8px; text-align: center; transition: background-color 0.3s ease, color 0.3s ease; }
        .sidebar .logout:hover { background-color: #bdc3c7; color: #2c3e50; }

        /* Style for the "Back to Dashboard" button */
        .back-to-dashboard-link {
            display: block;
            text-align: center;
            margin-top: 30px; /* Space above the link */
            background-color: #2c3e50; /* Dark background */
            color: #fff; /* White text */
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            transition: background-color 0.3s ease, color 0.3s ease;
            width: fit-content; /* Adjust width to content */
            margin-left: auto; /* Center block element */
            margin-right: auto; /* Center block element */
        }
        .back-to-dashboard-link:hover {
            background-color: #34495e; /* Slightly lighter dark on hover */
            color: #fff;
            text-decoration: underline;
        }
        .error-message { /* For displaying database errors */
            text-align: center; padding: 15px; margin: 20px auto; border-radius: 8px;
            background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb;
            max-width: 700px;
        }

        @media (max-width: 768px) {
            body { flex-direction: column; }
            .sidebar { width: 100%; height: auto; position: relative; box-shadow: none; }
            .main-content { padding: 15px; } 
            .table-container { padding: 15px; }
            th, td { padding: 10px 12px; font-size: 13px; } 
            .table-container h2 { font-size: 22px; }
            .back-to-dashboard-link { width: auto; }
        }
        @media (max-width: 480px) { 
             th, td { padding: 8px; font-size: 12px; }
             .sidebar .button { font-size: 14px; padding: 10px 15px; gap: 8px;}
        }
    </style>
</head>
<body>

    <div class="main-content">
        <div class="table-container">
            <h2>Stock In/Out Records</h2>
            <?php if (isset($db_error_message)): ?>
                <p class="error-message"><?php echo htmlspecialchars($db_error_message); ?></p>
            <?php elseif ($result && mysqli_num_rows($result) > 0): ?>
                <table>
                    <tr>
                        <th>Stock ID</th>
                        <th>Transaction No.</th>
                        <th>Item ID</th>
                        <th>Date</th>
                        <th>Quantity</th>
                        <th>Total Price</th>
                        <th>Supplier/Customer ID</th>
                        <th>Remarks (Type)</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= htmlspecialchars($row['STOCKOUTID']) ?></td>
                        <td><?= htmlspecialchars($row['TRANSACTIONNUMBER']) ?></td>
                        <td><?= htmlspecialchars($row['ITEMID']) ?></td>
                        <td><?= htmlspecialchars(date("M d, Y", strtotime($row['TRANSACTIONDATE']))) ?></td>
                        <td><?= htmlspecialchars($row['QTY']) ?></td>
                        <td><?= htmlspecialchars(number_format((float)$row['TOTALPRICE'], 2)) ?></td>
                        <td><?= htmlspecialchars($row['SUPLIERCUSTOMERID']) ?></td>
                        <td><?= htmlspecialchars($row['REMARKS']) ?></td>
                    </tr>
                    <?php } ?>
                </table>
            <?php elseif ($result): // Query successful but no rows ?>
                <p style="text-align:center; padding: 20px;">No stock transaction records found.</p>
            <?php endif; // No need for an else here if $db_error_message covers $result being null ?>

           
        </div>
    </div>
</body>
</html>