<?php
include 'header.php';
include 'db.php';

// Check if user is a regular User
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'User') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Assets</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --sidebar-width: 280px;
            --primary-color:white;
            --secondary-color:white;
            --accent-color:black;
            --text-light: #000000; /* Changed from white to black */
            --text-dark: #000000; /* Changed to black */
            --card-bg: #ffffff;
            --transition-speed: 0.3s;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            color: #000000; /* Added to ensure all text is black */
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            min-height: 100vh;
            display: flex;
            color: var(--text-dark);
        }

        /* Sidebar Navigation */
        .sidebar {
            width: var(--sidebar-width);
            background: rgba(0, 0, 0, 0.25);
            backdrop-filter: blur(10px);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            z-index: 100;
        }

        .sidebar-header {
            text-align: center;
            padding: 20px 0;
            margin-bottom: 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header i {
            font-size: 2rem;
            color: var(--accent-color);
        }

        .sidebar-header h2 {
            font-size: 1.5rem;
            color: var(--text-light); /* Now black */
            margin-top: 10px;
        }

        .nav-menu {
            flex: 1;
            overflow-y: auto;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            color: var(--text-light); /* Now black */
            text-decoration: none;
            transition: all var(--transition-speed);
            position: relative;
        }

        .nav-link i {
            margin-right: 12px;
            font-size: 1.1rem;
            width: 24px;
            text-align: center;
            color: var(--text-light); /* Now black */
        }

        .nav-link:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateX(5px);
        }

        .nav-link.active {
            background: rgba(46, 204, 113, 0.2);
        }

        .nav-link::after {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: var(--accent-color);
            transform: scaleY(0);
            transition: transform var(--transition-speed);
        }

        .nav-link:hover::after,
        .nav-link.active::after {
            transform: scaleY(1);
        }

        .logout-container {
            margin-top: auto;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logout-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 12px;
            border-radius: 8px;
            background: rgba(231, 76, 60, 0.2);
            color: var(--text-light); /* Now black */
            text-decoration: none;
            transition: all var(--transition-speed);
        }

        .logout-btn i {
            margin-right: 10px;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 40px;
            min-height: 100vh;
        }

        .content-header {
            margin-bottom: 30px;
            text-align: center;
        }

        .content-header h1 {
            font-size: 2.2rem;
            margin-bottom: 10px;
            color: var(--text-light); /* Now black */
        }

        /* Table Styles */
        .asset-table-container {
            background: var(--card-bg);
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 20px;
            overflow-x: auto;
        }

        .asset-table {
            width: 100%;
            border-collapse: collapse;
            margin: 0 auto;
        }

        .asset-table th {
            background-color: var(--accent-color);
            color: white; /* Keeping header text white for contrast */
            padding: 12px;
            text-align: left;
        }

        .asset-table td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            color: #000000; /* Black text */
        }

        .asset-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .asset-table tr:hover {
            background-color: #f1f1f1;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: var(--accent-color);
            color: white; /* Keeping button text white */
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .no-assets {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            color: #000000; /* Black text */
        }

        /* Footer Styles */
        footer {
            text-align: center;
            padding: 15px;
            background: #1a1a1a;
            color: #ccc; /* Keeping footer text light for dark background */
            font-size: 0.9rem;
            margin-top: auto;
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }

            .sidebar-header h2, 
            .nav-link span {
                display: none;
            }

            .nav-link {
                justify-content: center;
                padding: 15px;
            }

            .nav-link i {
                margin-right: 0;
                font-size: 1.3rem;
            }

            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 20px;
            }
        }

        @media (max-width: 576px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: fixed;
                bottom: 0;
                top: auto;
                flex-direction: row;
                padding: 10px;
                justify-content: space-around;
                border-top: 1px solid rgba(255, 255, 255, 0.1);
                border-right: none;
            }

            .sidebar-header,
            .logout-container {
                display: none;
            }

            .nav-menu {
                display: flex;
                flex: 1;
                justify-content: space-around;
            }

            .nav-item {
                margin-bottom: 0;
            }

            .nav-link {
                flex-direction: column;
                padding: 10px 5px;
                font-size: 0.7rem;
            }

            .nav-link i {
                margin-right: 0;
                margin-bottom: 5px;
                font-size: 1.2rem;
            }

            .main-content {
                margin-left: 0;
                margin-bottom: 70px;
            }
        }
        footer {
        text-align: center;
        padding: 20px;
        background-color: var(--dark-color);
        color: white;
        font-size: 14px;
        width: 100%;
    }

    /* Responsive table */
    @media screen and (max-width: 768px) {
        table {
            display: block;
            overflow-x: auto;
            white-space: nowrap;
        }
        
        th, td {
            padding: 8px 10px;
        }
    }
    </style>
</head>
<body>
    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-user"></i>
            <h2>User Dashboard</h2>
        </div>
        
        <nav class="nav-menu">
            <div class="nav-item">
                <a href="request-asset.php" class="nav-link">
                    <i class="fas fa-hand-holding"></i>
                    <span>Request Asset</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="view-assets.php" class="nav-link">
                    <i class="fas fa-boxes"></i>
                    <span>View Assets</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="modify-account.php" class="nav-link">
                    <i class="fas fa-user-cog"></i>
                    <span>Account Settings</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="view-transferred-asset.php" class="nav-link">
                    <i class="fas fa-exchange-alt"></i>
                    <span>View Transferred Assets</span>
                </a>
            </div>
        </nav>
        
        <div class="logout-container">
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>
    <script>
        // Highlight current page in navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            if (link.href === window.location.href) {
                link.classList.add('active');
            }
        });
    </script>
    
    <footer>
        &copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.
    </footer>
</body>
</html>