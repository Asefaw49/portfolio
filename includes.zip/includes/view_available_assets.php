<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

require_once 'db.php';

$assets = [];

// Fetch available assets from the database
$sql = "SELECT AssetCode, AssetName, ModelName, Type, Cost, Quantity, Status, ExpiryDate FROM asset WHERE Status = 'Active'"; // Assuming 'Active' means available
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $assets[] = $row;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Available Assets</title>
    <style>
        body { font-family: sans-serif; }
        .container { width: 80%; margin: 20px auto; }
        h2 { margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
        th { background-color: #f0f0f0; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Available Assets</h2>

        <table>
            <thead>
                <tr>
                    <th>Asset Code</th>
                    <th>Asset Name</th>
                    <th>Model Name</th>
                    <th>Type</th>
                    <th>Cost</th>
                    <th>Quantity</th>
                    <th>Status</th>
                    <th>Expiry Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($assets as $asset): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($asset["AssetCode"]); ?></td>
                        <td><?php echo htmlspecialchars($asset["AssetName"]); ?></td>
                        <td><?php echo htmlspecialchars($asset["ModelName"]); ?></td>
                        <td><?php echo htmlspecialchars($asset["Type"]); ?></td>
                        <td><?php echo htmlspecialchars(number_format($asset["Cost"], 2)); ?></td>
                        <td><?php echo htmlspecialchars($asset["Quantity"]); ?></td>
                        <td><?php echo htmlspecialchars($asset["Status"]); ?></td>
                        <td><?php echo htmlspecialchars($asset["ExpiryDate"]); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p><a href="admin_dashboard.php">Back to Dashboard</a></p>
    </div>
</body>
</html>