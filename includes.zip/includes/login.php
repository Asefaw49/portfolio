<?php
session_start();
require_once 'db.php'; // Ensure this file correctly establishes a database connection ($conn)

$error = null; // Initialize error variable

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if (empty($username) || empty($password)) {
        $error = "Username and password are required.";
    } else {
        // Prepare statement to prevent SQL injection
        $stmt = $conn->prepare("SELECT UserID, Username, Password, role FROM user WHERE Username = ?");
        if ($stmt === false) {
            // Handle prepare error, e.g., log it or display a generic error
            error_log("Failed to prepare statement: " . $conn->error);
            $error = "An error occurred. Please try again later.";
        } else {
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                // Verify the password using password_verify()
                if (password_verify($password, $row["Password"])) {
                    // Password is correct, set session variables
                    $_SESSION["UserID"] = $row["UserID"];
                    $_SESSION["username"] = $row["Username"];
                    $_SESSION["role"] = $row["role"];

                    // Redirect based on user role
                    switch ($row["role"]) {
                        case "Administrator":
                            header("Location: admin_dashboard.php");
                            break;
                        case "Storekeeper":
                            header("Location: storekeeper_dashboard.php");
                            break;
                        case "Stock Manager":
                            header("Location: stockmanager_dashboard.php");
                            break;
                        case "Manager":
                            header("Location: manager_dashboard.php");
                            break;
                        default: // Includes "User" role and any other unspecified roles
                            header("Location: user_dashboard.php");
                            break;
                    }
                    exit(); // Important to prevent further script execution after redirection
                } else {
                    // Incorrect password
                    $error = "Incorrect username or password.";
                }
            } else {
                // Incorrect username
                $error = "Incorrect username or password."; // It's good practice to give a generic error
            }
            $stmt->close();
        }
    }
    if (isset($conn)) { // Close connection if it was opened
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Property Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap + Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
            background: white; /* Or your preferred background */
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            color: #000; /* Default text color */
        }

        .login-header {
            padding: 2rem 1rem;
            text-align: center;
            color: #000; /* Text color for the header */
        }

        .login-header i {
            font-size: 2rem; /* Icon size */
            color: #000; /* Icon color */
        }

        .login-header h2 {
            margin-top: 0.5rem;
            font-size: 1.8rem;
            color: #000; /* Title color */
        }

        .login-card {
            background: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            backdrop-filter: blur(10px); /* Frosted glass effect */
            color: #000; /* Text color inside the card */
            border-radius: 20px; /* Rounded corners */
            padding: 2rem;
            max-width: 400px;
            width: 90%; /* Responsive width */
            margin: auto; /* Center the card */
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            border: 1px solid #ddd; /* Light border */
        }

        .login-card label {
            font-weight: 500;
            margin-bottom: 0.5rem;
            color: #000; /* Label text color */
        }

        .form-control {
            border-radius: 10px; /* Rounded input fields */
            background-color: rgba(255, 255, 255, 0.9); /* Input background */
            color: #000; /* Input text color */
            border: 1px solid #ccc; /* Input border */
        }

        .form-control:focus {
            box-shadow: none; /* Remove default focus glow */
            border-color: #86b7fe; /* Bootstrap's default focus color */
        }

        .btn-login {
            margin-top: 1rem;
            background-color: #2c3e50; /* Dark blue button */
            color: #fff; /* White text on button */
            font-weight: bold;
            border-radius: 30px; /* Pill-shaped button */
            padding: 0.75rem;
            transition: all 0.3s ease; /* Smooth transition for hover effects */
            border: none; /* Remove default border */
        }

        .btn-login:hover {
            background-color: #1a252f; /* Darker shade on hover */
            transform: scale(1.03); /* Slight zoom effect on hover */
            color: #fff;
        }

        .error {
            color: #dc3545; /* Bootstrap's danger color for errors */
            font-size: 0.9rem;
            margin-bottom: 1rem;
            text-align: center;
        }

        .forgot-link, .home-link {
            display: block;
            text-align: center;
            margin-top: 1rem;
            color: #000; /* Link color */
            text-decoration: underline;
        }
        .forgot-link:hover, .home-link:hover {
            color: #0056b3; /* Darker link color on hover */
        }

        footer {
            text-align: center;
            padding: 1rem;
            background: #000; /* Black footer background */
            color: #fff; /* White text for footer */
            font-size: 0.9rem;
            margin-top: auto; /* Pushes footer to the bottom */
            border-top: 1px solid #333; /* Subtle top border for footer */
        }

        /* Responsive adjustments */
        @media (max-width: 576px) {
            .login-header h2 {
                font-size: 1.5rem; /* Smaller title on small screens */
            }

            .login-card {
                padding: 1.5rem; /* Less padding on small screens */
                width: 95%; /* Slightly wider on very small screens */
            }
        }
    </style>
</head>
<body>

    <div class="login-header">
       
        <h2>Web-Based Property Management System in Aksum University</h2>
    </div>
    <div class="login-card">
        <h4 class="text-center mb-4"><i class="fas fa-sign-in-alt"></i> Login</h4>
        <?php if (isset($error) && $error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="mb-3">
                <label for="username"><i class="fas fa-user"></i> Username</label>
                <input type="text" name="username" id="username" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="password"><i class="fas fa-lock"></i> Password</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-login w-100">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>

        <a href="forgot_password.php" class="forgot-link"><i class="fas fa-question-circle"></i> Forgot Password?</a>
        <a href="index.php" class="home-link"><i class="fas fa-arrow-left"></i> Back to Home</a>
    </div>

    <footer>
        &copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.
    </footer>

    <!-- Optional: Bootstrap JS Bundle (Popper.js included) if you need Bootstrap JavaScript components -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script> -->
</body>
</html>