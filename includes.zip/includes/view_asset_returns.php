<?php
include 'db.php';
include 'header.php';

echo '<div class="container">';
echo '<h2>Asset Return Records</h2>';

// Fetch and join data from asset_returns and asset
$sql = "
SELECT 
    ar.ReturnID,
    ar.AssetCode,
    a.AssetName,
    a.ModelName,
    a.Type,
    a.Cost,
    a.Status,
    a.ExpiryDate,
    ar.TakerFname,
    ar.TakerLname,
    ar.QuantityReturned,
    ar.ReturnDate,
    ar.Remarks,
    ar.ReturnedAt
FROM 
    asset_returns ar
JOIN 
    asset a ON ar.AssetCode = a.AssetCode
ORDER BY 
    ar.ReturnedAt DESC
";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<table class="asset-table">';
    echo '<thead>
            <tr>
                <th>#</th>
                <th>Asset Code</th>
                <th>Asset Name</th>
                <th>Model Name</th>
                <th>Type</th>
                <th>Cost</th>
                <th>Status</th>
                <th>Expiry Date</th>
                <th>Taker Name</th>
                <th>Quantity Returned</th>
                <th>Return Date</th>
                <th>Remarks</th>
                <th>Returned At</th>
            </tr>
          </thead><tbody>';

    $counter = 1;
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo "<td>{$counter}</td>";
        echo "<td>{$row['AssetCode']}</td>";
        echo "<td>{$row['AssetName']}</td>";
        echo "<td>{$row['ModelName']}</td>";
        echo "<td>{$row['Type']}</td>";
        echo "<td>{$row['Cost']}</td>";
        echo "<td>{$row['Status']}</td>";
        echo "<td>{$row['ExpiryDate']}</td>";
        echo "<td>{$row['TakerFname']} {$row['TakerLname']}</td>";
        echo "<td>{$row['QuantityReturned']}</td>";
        echo "<td>{$row['ReturnDate']}</td>";
        echo "<td>{$row['Remarks']}</td>";
        echo "<td>{$row['ReturnedAt']}</td>";
        echo '</tr>';
        $counter++;
    }

    echo '</tbody></table>';
} else {
    echo "<p class='no-records'>No asset return records found.</p>";
}

echo '<a href="storekeeper_dashboard.php" class="back-btn">Back to Dashboard</a>';
echo '</div>';
?>

<!-- Styling -->
<style>
body {
    font-family: Arial, sans-serif;
    background: #eef2f5;
    margin: 0;
    padding: 30px;
}

.container {
    max-width: 95%;
    margin: auto;
    background: #fff;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 5px 25px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #2c3e50;
}

.asset-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
}

.asset-table th,
.asset-table td {
    border: 1px solid #ccc;
    padding: 10px;
    text-align: left;
}

.asset-table th {
    background-color: #2c3e50;
    color: white;
}

.asset-table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.asset-table tr:hover {
    background-color: #f1f1f1;
}

.no-records {
    text-align: center;
    color: #888;
}

.back-btn {
    display: block;
    margin-top: 20px;
    text-align: center;
    text-decoration: none;
    padding: 10px;
    border: 2px solid #2c3e50;
    color: #2c3e50;
    border-radius: 8px;
    width: 200px;
    margin-left: auto;
    margin-right: auto;
    font-weight: bold;
}

.back-btn:hover {
    background-color: #2c3e50;
    color: white;
}
</style>
