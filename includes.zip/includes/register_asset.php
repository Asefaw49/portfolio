<?php
include 'db.php';
include 'header.php';
?>

<!-- Internal CSS Styling -->
<style>
    :root {
        --primary-color: rgb(4, 7, 4);
        --secondary-color: #2c3e50;
        --bg-color: #f9fafc;
        --text-color: #333;
        --white: #ffffff;
        --success-bg: #e6ffe6;
        --error-bg: #ffe6e6;
    }

    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        background-color: var(--bg-color);
        color: var(--text-color);
    }

    .container {
        max-width: 700px;
        margin: 60px auto;
        padding: 30px;
        background-color: var(--white);
        border-radius: 16px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
        animation: fadeIn 0.5s ease-in-out;
    }

    h2 {
        text-align: center;
        color: var(--primary-color);
        margin-bottom: 25px;
    }

    .form {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    label {
        font-weight: 600;
    }

    input[type="text"],
    input[type="number"],
    input[type="date"],
    select {
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 16px;
        transition: border-color 0.3s;
    }

    input:focus,
    select:focus {
        border-color: var(--primary-color);
        outline: none;
    }

    .submit-btn {
        padding: 12px;
        font-size: 16px;
        background-color: var(--primary-color);
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: background-color 0.3s, transform 0.2s;
    }

    .submit-btn:hover {
        background-color: #45a049;
        transform: scale(1.03);
    }

    .success-msg,
    .error-msg {
        margin-top: 20px;
        padding: 12px;
        font-weight: bold;
        border-radius: 8px;
        text-align: center;
    }

    .success-msg {
        background-color: var(--success-bg);
        border-left: 6px solid var(--primary-color);
        color: var(--primary-color);
    }

    .error-msg {
        background-color: var(--error-bg);
        border-left: 6px solid #ff4d4d;
        color: #cc0000;
    }

    .back-link {
        display: block;
        margin-top: 30px;
        text-align: center;
        text-decoration: none;
        color: var(--secondary-color);
        font-weight: 600;
    }

    .back-link:hover {
        text-decoration: underline;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @media (max-width: 600px) {
        .container {
            margin: 30px 15px;
            padding: 20px;
        }

        input,
        select,
        .submit-btn {
            font-size: 15px;
        }
    }

    footer {
        text-align: center;
        padding: 1rem;
        background: #1a1a1a;
        color: #ccc;
        font-size: 0.9rem;
        position: fixed;
        bottom: 0;
        width: 100%;
    }
</style>

<?php
echo '<div class="container">';
echo "<h2>Register Asset</h2>";
echo '<form method="post" action="" class="form">';
echo '<label for="asset_name">Asset Name:</label>';
echo '<input type="text" id="asset_name" name="AssetName" required>';
echo '<label for="model_name">Model Name:</label>';
echo '<input type="text" id="model_name" name="ModelName" required>';
echo '<label for="asset_type">Asset Type:</label>';
echo '<input type="text" id="asset_type" name="Type" required>';
echo '<label for="asset_cost">Cost (Single Unit):</label>';
echo '<input type="number" step="0.01" id="asset_cost" name="Cost" required>';
echo '<label for="asset_quantity">Quantity:</label>';
echo '<input type="number" id="asset_quantity" name="Quantity" required>';
echo '<label for="total_cost">Total Cost:</label>';
echo '<input type="number" step="0.01" id="total_cost" name="TotalCost" readonly>';
echo '<label for="asset_status">Status:</label>';
echo '<select id="asset_status" name="Status" required>';
echo '<option value="Active">Active</option>';
echo '<option value="Inactive">Inactive</option>';
echo '<option value="Damaged">Damaged</option>';
echo '</select>';
echo '<label for="expiry_date">Expiry Date:</label>';
echo '<input type="date" id="expiry_date" name="ExpiryDate">';
echo '<input type="submit" name="submit_asset" value="Register" class="submit-btn">';
echo '</form>';

// PHP Insert Logic
if (isset($_POST['submit_asset'])) {
    $asset_name = htmlspecialchars($_POST['AssetName']);
    $model_name = htmlspecialchars($_POST['ModelName']);
    $asset_type = htmlspecialchars($_POST['Type']);
    $asset_cost = floatval($_POST['Cost']);
    $asset_quantity = intval($_POST['Quantity']);
    $asset_status = htmlspecialchars($_POST['Status']);
    $expiry_date = $_POST['ExpiryDate'] ? "'" . $_POST['ExpiryDate'] . "'" : 'NULL';
    $total_cost = $asset_cost * $asset_quantity;

    $sql = "INSERT INTO asset (AssetName, ModelName, Type, Cost, Quantity, TotalCost, Status, ExpiryDate)
            VALUES (?, ?, ?, ?, ?, ?, ?, $expiry_date)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sssdids", $asset_name, $model_name, $asset_type, $asset_cost, $asset_quantity, $total_cost, $asset_status);

        if ($stmt->execute()) {
            echo "<p class='success-msg'>Asset registered successfully!<br>Total Cost: ₱" . number_format($total_cost, 2) . "</p>";
        } else {
            echo "<p class='error-msg'>Error: " . $stmt->error . "</p>";
        }
    } else {
        echo "<p class='error-msg'>Error preparing statement: " . $conn->error . "</p>";
    }

    $stmt->close();
}

echo '<a href="storekeeper_dashboard.php" class="back-link">← Back to Dashboard</a>';
echo '</div>';
?>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const costInput = document.getElementById("asset_cost");
    const quantityInput = document.getElementById("asset_quantity");
    const totalCostInput = document.getElementById("total_cost");

    function updateTotalCost() {
        const cost = parseFloat(costInput.value) || 0;
        const quantity = parseInt(quantityInput.value) || 0;
        totalCostInput.value = (cost * quantity).toFixed(2);
    }

    costInput.addEventListener("input", updateTotalCost);
    quantityInput.addEventListener("input", updateTotalCost);
});
</script>

<footer>
&copy; <?php echo date("Y"); ?> Property Management System. All Rights Reserved.
</footer>
