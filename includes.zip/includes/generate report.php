<?php
// This file handles the generation of reports.
include 'header.php';
include 'db.php';

// Check if user is an Administrator
if (!isset($_SESSION['UserID']) || $_SESSION['role'] !== 'Manager') {
    header("Location: login.php"); // Redirect to login if not an admin
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Report</title>
    <style>
        /* Global Styles */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Container */
        .container {
            width: 90%;
            max-width: 1200px;
            margin: auto;
            text-align: center;
            padding: 20px;
            flex: 1;
        }

        /* Headings */
        h2 {
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
        }

        /* Dashboard Content */
        .dashboard-content {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        /* Form Styling */
        form {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 50%;
            margin: auto;
            text-align: left;
        }

        input, select, label {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }

        input, select {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color:rgb(10, 12, 14);
            color: white;
            font-size: 16px;
            border: none;
            cursor: pointer;
            padding: 12px;
            width: auto;
        }
        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color:rgb(10, 12, 14);
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }
 /* Back Button */
 .back-button {
            width:15%;
            margin: 20px;
            padding: 10px 20px;
            background-color: #2c3e50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }
        .back-button:hover {
            background-color: #2c3e50;
        }
        /* Footer */
        .footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 15px 0;
            font-size: 14px;
            margin-top: auto;
            width: 100%;
            box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
        }

        .footer a {
            color: #f39c12;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }

        .footer a:hover {
            color: #e67e22;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Generate Report</h2>

    <div class="dashboard-content">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?action=generate_report">
            <label for="report_type">Select Report Type:</label>
            <select id="report_type" name="report_type" required>
                <option value="asset_list">Asset List</option>
                <option value="asset_usage">Asset Usage</option>
                <option value="account_list">Account List</option>
            </select>
            <br><br>
            <input type="submit" name="submit_report" value="Generate Report">
        </form>

        <?php
        if (isset($_POST['submit_report'])) {
            $report_type = $_POST['report_type'];

            echo '<div class="dashboard-content">';
            switch ($report_type) {
                case 'asset_list':
                    echo "<h3>Asset List</h3>";
                    $sql = "SELECT AssetCode, AssetName, ModelName, Type, Quantity, Status, ExpiryDate FROM asset";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        echo "<table>";
                        echo "<tr><th>Asset Code</th><th>Asset Name</th><th>Model Name</th><th>Type</th><th>Quantity</th><th>Status</th><th>Expiry Date</th></tr>";
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["AssetCode"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["AssetName"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["ModelName"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["Type"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["Quantity"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["Status"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["ExpiryDate"]) . "</td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    } else {
                        echo "<p>No assets found.</p>";
                    }
                    break;

                case 'asset_usage':
                    echo "<h3>Asset Usage Report (Placeholder)</h3>";
                    echo "<p>This report would show which assets have been transferred, when, and to whom.</p>";
                    break;

                case 'account_list':
                    echo "<h3>Account List</h3>";
                    $sql = "SELECT UserID, Username, FirstName, LastName, role FROM user";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        echo "<table>";
                        echo "<tr><th>User ID</th><th>Username</th><th>First Name</th><th>Last Name</th><th>Role</th></tr>";
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["UserID"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["Username"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["FirstName"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["LastName"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["role"]) . "</td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    } else {
                        echo "<p>No accounts found.</p>";
                    }
                    break;

                default:
                    echo "<p>Invalid report type.</p>";
            }
            echo '</div>';
        }
        ?>
    </div>
   
</div>
<a href="manager_dashboard.php" class="back-button">Back to Dashboard</a><br>
<footer class="footer">
    &copy; <?php echo date('Y'); ?> Asset Management System | All Rights Reserved.
</footer>

</body>
</html>