<?php
// ============================================
// FILE: exam_management.php
// BGSS Exam Management System - Vice Director Dashboard
// Integrated with existing school_management database
// ============================================

session_start();

// Database configuration (using your existing database)
define('DB_HOST', 'localhost');
define('DB_NAME', 'school_management');
define('DB_USER', 'root');
define('DB_PASS', '');

// Create connection function
function getConnection() {
    try {
        $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $conn;
    } catch(PDOException $e) {
        die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
    }
}

// Set default user if not logged in (for demo - Vice Director)
if (!isset($_SESSION['user_id'])) {
    // Find a vice_director user from your database
    $conn = getConnection();
    $stmt = $conn->prepare("SELECT id, username, full_name, role FROM users WHERE role = 'vice_director' LIMIT 1");
    $stmt->execute();
    $viceDirector = $stmt->fetch();
    
    if ($viceDirector) {
        $_SESSION['user_id'] = $viceDirector['id'];
        $_SESSION['username'] = $viceDirector['username'];
        $_SESSION['full_name'] = $viceDirector['full_name'];
        $_SESSION['role'] = $viceDirector['role'];
    } else {
        // Fallback: use admin user
        $_SESSION['user_id'] = 1;
        $_SESSION['username'] = 'admin';
        $_SESSION['full_name'] = 'Admin User';
        $_SESSION['role'] = 'director';
    }
}

// ============================================
// API ROUTES (AJAX Requests)
// ============================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
    header('Content-Type: application/json');
    $conn = getConnection();
    $action = $_POST['action'] ?? $_GET['action'] ?? '';
    
    // GET ALL EXAMS with subject and teacher info
    if ($action === 'get_exams') {
        $stmt = $conn->prepare("
            SELECT e.*, 
                   s.name as subject_name, s.code as subject_code,
                   t.full_name as teacher_name, t.teacher_id as teacher_code,
                   g.name as grade_name
            FROM exams e
            LEFT JOIN subjects s ON e.subject_id = s.id
            LEFT JOIN teachers t ON e.teacher_id = t.id
            LEFT JOIN students st ON e.grade_id = st.grade_id
            GROUP BY e.id
            ORDER BY e.exam_date ASC
        ");
        $stmt->execute();
        $exams = $stmt->fetchAll();
        echo json_encode(['success' => true, 'exams' => $exams]);
        exit;
    }
    
    // GET UPCOMING EXAMS
    if ($action === 'get_upcoming_exams') {
        $stmt = $conn->prepare("
            SELECT e.*, 
                   s.name as subject_name,
                   t.full_name as teacher_name,
                   DATE_FORMAT(e.exam_date, '%Y-%m-%d') as exam_date
            FROM exams e
            LEFT JOIN subjects s ON e.subject_id = s.id
            LEFT JOIN teachers t ON e.teacher_id = t.id
            WHERE e.exam_date >= CURDATE() AND e.status = 'upcoming'
            ORDER BY e.exam_date ASC
            LIMIT 10
        ");
        $stmt->execute();
        $exams = $stmt->fetchAll();
        echo json_encode(['success' => true, 'exams' => $exams]);
        exit;
    }
    
    // CREATE NEW EXAM
    if ($action === 'create_exam') {
        $subject_id = $_POST['subject_id'] ?? null;
        $grade_id = $_POST['grade_id'] ?? null;
        $teacher_id = $_POST['teacher_id'] ?? null;
        $exam_type = $_POST['exam_type'] ?? 'Mid-Term';
        $exam_date = $_POST['exam_date'] ?? '';
        $start_time = $_POST['start_time'] ?? '09:00:00';
        $end_time = $_POST['end_time'] ?? '12:00:00';
        $venue = $_POST['venue'] ?? '';
        $status = 'upcoming';
        
        $stmt = $conn->prepare("
            INSERT INTO exams (subject_id, grade_id, teacher_id, exam_type, exam_date, start_time, end_time, venue, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $result = $stmt->execute([$subject_id, $grade_id, $teacher_id, $exam_type, $exam_date, $start_time, $end_time, $venue, $status]);
        
        if ($result) {
            // Log activity (if activity_log table exists, otherwise skip)
            echo json_encode(['success' => true, 'message' => 'Exam created successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to create exam']);
        }
        exit;
    }
    
    // UPDATE EXAM
    if ($action === 'update_exam') {
        $id = $_POST['id'] ?? 0;
        $subject_id = $_POST['subject_id'] ?? null;
        $grade_id = $_POST['grade_id'] ?? null;
        $teacher_id = $_POST['teacher_id'] ?? null;
        $exam_type = $_POST['exam_type'] ?? '';
        $exam_date = $_POST['exam_date'] ?? '';
        $start_time = $_POST['start_time'] ?? '';
        $end_time = $_POST['end_time'] ?? '';
        $venue = $_POST['venue'] ?? '';
        $status = $_POST['status'] ?? 'upcoming';
        
        $stmt = $conn->prepare("
            UPDATE exams 
            SET subject_id = ?, grade_id = ?, teacher_id = ?, exam_type = ?, 
                exam_date = ?, start_time = ?, end_time = ?, venue = ?, status = ?
            WHERE id = ?
        ");
        $result = $stmt->execute([$subject_id, $grade_id, $teacher_id, $exam_type, $exam_date, $start_time, $end_time, $venue, $status, $id]);
        
        echo json_encode(['success' => $result, 'message' => $result ? 'Exam updated successfully' : 'Update failed']);
        exit;
    }
    
    // DELETE EXAM
    if ($action === 'delete_exam') {
        $id = $_POST['id'] ?? 0;
        $stmt = $conn->prepare("DELETE FROM exams WHERE id = ?");
        $result = $stmt->execute([$id]);
        echo json_encode(['success' => $result, 'message' => $result ? 'Exam deleted' : 'Delete failed']);
        exit;
    }
    
    // GET STATISTICS
    if ($action === 'get_stats') {
        // Total exams
        $totalExams = $conn->query("SELECT COUNT(*) as count FROM exams")->fetch()['count'];
        
        // Upcoming exams
        $upcomingCount = $conn->query("SELECT COUNT(*) as count FROM exams WHERE exam_date >= CURDATE() AND status = 'upcoming'")->fetch()['count'];
        
        // Completed exams
        $completedCount = $conn->query("SELECT COUNT(*) as count FROM exams WHERE status = 'completed' OR exam_date < CURDATE()")->fetch()['count'];
        
        // Total subjects
        $totalSubjects = $conn->query("SELECT COUNT(*) as count FROM subjects")->fetch()['count'];
        
        // Total teachers
        $totalTeachers = $conn->query("SELECT COUNT(*) as count FROM teachers WHERE status = 'active'")->fetch()['count'];
        
        // Total students
        $totalStudents = $conn->query("SELECT COUNT(*) as count FROM students WHERE status = 'active'")->fetch()['count'];
        
        echo json_encode([
            'success' => true,
            'totalExams' => $totalExams,
            'upcomingCount' => $upcomingCount,
            'completedCount' => $completedCount,
            'totalSubjects' => $totalSubjects,
            'totalTeachers' => $totalTeachers,
            'totalStudents' => $totalStudents
        ]);
        exit;
    }
    
    // GET SUBJECTS LIST
    if ($action === 'get_subjects') {
        $stmt = $conn->query("SELECT id, name, code FROM subjects ORDER BY name");
        $subjects = $stmt->fetchAll();
        echo json_encode(['success' => true, 'subjects' => $subjects]);
        exit;
    }
    
    // GET TEACHERS LIST
    if ($action === 'get_teachers') {
        $stmt = $conn->query("SELECT id, teacher_id, full_name, subject_name FROM teachers WHERE status = 'active' ORDER BY full_name");
        $teachers = $stmt->fetchAll();
        echo json_encode(['success' => true, 'teachers' => $teachers]);
        exit;
    }
    
    // GET GRADES/CLASSES (using grade_id from students table)
    if ($action === 'get_grades') {
        $stmt = $conn->query("SELECT DISTINCT grade_id as id, CONCAT('Grade ', grade_id) as name FROM students WHERE grade_id IS NOT NULL UNION SELECT 0, 'All Grades' ORDER BY id");
        $grades = $stmt->fetchAll();
        echo json_encode(['success' => true, 'grades' => $grades]);
        exit;
    }
    
    echo json_encode(['error' => 'Invalid action']);
    exit;
}

// Get data for initial page load
$conn = getConnection();

// Get upcoming exams for display
$upcomingExams = $conn->prepare("
    SELECT e.*, s.name as subject_name, t.full_name as teacher_name,
           DATE_FORMAT(e.exam_date, '%M %d, %Y') as formatted_date,
           TIME_FORMAT(e.start_time, '%h:%i %p') as start_time_formatted
    FROM exams e
    LEFT JOIN subjects s ON e.subject_id = s.id
    LEFT JOIN teachers t ON e.teacher_id = t.id
    WHERE e.exam_date >= CURDATE() AND e.status = 'upcoming'
    ORDER BY e.exam_date ASC
    LIMIT 5
");
$upcomingExams->execute();
$upcomingExamsList = $upcomingExams->fetchAll();

// Get statistics
$stats = [
    'total_exams' => $conn->query("SELECT COUNT(*) FROM exams")->fetchColumn(),
    'upcoming_exams' => $conn->query("SELECT COUNT(*) FROM exams WHERE exam_date >= CURDATE() AND status = 'upcoming'")->fetchColumn(),
    'total_teachers' => $conn->query("SELECT COUNT(*) FROM teachers WHERE status = 'active'")->fetchColumn(),
    'total_subjects' => $conn->query("SELECT COUNT(*) FROM subjects")->fetchColumn(),
    'total_students' => $conn->query("SELECT COUNT(*) FROM students WHERE status = 'active'")->fetchColumn()
];

// Get subjects for dropdown
$subjects = $conn->query("SELECT id, name FROM subjects ORDER BY name")->fetchAll();

// Get teachers for dropdown
$teachers = $conn->query("SELECT id, full_name FROM teachers WHERE status = 'active' ORDER BY full_name")->fetchAll();

// Get grades
$grades = $conn->query("SELECT DISTINCT grade_id as id, CONCAT('Grade ', grade_id) as name FROM students WHERE grade_id IS NOT NULL ORDER BY grade_id")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>BGSS | Vice Director - Exam Management Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #f0f4f8;
            color: #1a2c3e;
            display: flex;
            height: 100vh;
            overflow: hidden;
        }
        
        /* ========= SIDEBAR ========= */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #0f2b1d 0%, #0a2418 100%);
            color: #e2f0e8;
            display: flex;
            flex-direction: column;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.08);
            z-index: 10;
        }
        
        .logo-area { padding: 28px 24px; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 24px; }
        .logo-area h2 { font-weight: 700; font-size: 1.6rem; background: linear-gradient(135deg, #ffffff, #b9f6ca); -webkit-background-clip: text; background-clip: text; color: transparent; }
        .logo-area p { font-size: 0.75rem; opacity: 0.7; margin-top: 6px; }
        
        .nav-menu { flex: 1; padding: 0 16px; }
        .nav-item {
            display: flex; align-items: center; gap: 14px; padding: 12px 16px; margin-bottom: 8px;
            border-radius: 14px; font-weight: 500; transition: all 0.2s ease; cursor: pointer; color: #cdede0;
        }
        .nav-item i { width: 24px; font-size: 1.2rem; }
        .nav-item.active { background: rgba(46, 204, 113, 0.2); color: white; border-left: 4px solid #2ecc71; }
        .nav-item:not(.active):hover { background: rgba(46, 204, 113, 0.1); color: white; transform: translateX(4px); }
        
        .user-info { padding: 20px 16px; border-top: 1px solid rgba(255,255,255,0.1); font-size: 0.8rem; }
        .user-info i { margin-right: 8px; }
        
        /* ========= MAIN CONTENT ========= */
        .main-content {
            flex: 1;
            overflow-y: auto;
            padding: 28px 36px;
            scroll-behavior: smooth;
        }
        
        .page-header { margin-bottom: 32px; }
        .breadcrumb { font-size: 0.85rem; color: #5f7f6e; margin-bottom: 10px; }
        .breadcrumb span:last-child { color: #1e5631; font-weight: 600; }
        
        .page-header h1 {
            font-size: 2rem;
            font-weight: 700;
            color: #1a3c2c;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
        }
        
        .subtitle {
            color: #5a6e64;
            font-size: 0.9rem;
            margin-top: 8px;
            border-left: 3px solid #2ecc71;
            padding-left: 14px;
        }
        
        /* Stats Cards */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }
        
        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            border: 1px solid #eef2f0;
            transition: transform 0.2s;
        }
        
        .stat-card:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,0,0,0.08); }
        
        .stat-icon {
            width: 54px;
            height: 54px;
            background: #ebf9f0;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
            color: #2e7d32;
        }
        
        .stat-info h3 { font-size: 1.8rem; font-weight: 700; color: #1a3c2c; }
        .stat-info p { font-size: 0.8rem; color: #7b8c7d; }
        
        /* Action Cards */
        .cards-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }
        
        .action-card {
            background: white;
            border-radius: 20px;
            padding: 18px;
            text-align: center;
            cursor: pointer;
            transition: all 0.25s ease;
            border: 1px solid #eef2f0;
        }
        
        .action-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(46,204,113,0.15);
            border-color: #2ecc71;
        }
        
        .action-icon {
            width: 56px;
            height: 56px;
            background: #ebf9f0;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
            color: #2e7d32;
            margin: 0 auto 12px;
        }
        
        .action-card h4 { font-size: 1rem; margin-bottom: 4px; color: #1a3c2c; }
        .action-card p { font-size: 0.7rem; color: #8aa394; }
        
        /* Data Tables */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 0.9fr;
            gap: 24px;
            margin-bottom: 32px;
        }
        
        .data-card {
            background: white;
            border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            border: 1px solid #eef2f0;
        }
        
        .data-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 18px 20px;
            border-bottom: 1px solid #ecf3ef;
        }
        
        .data-header h3 { font-size: 1.1rem; font-weight: 600; color: #1e462e; }
        .data-header a { font-size: 0.75rem; color: #2ecc71; text-decoration: none; cursor: pointer; }
        
        .exam-table { padding: 0 16px; }
        .exam-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 14px 8px;
            border-bottom: 1px solid #f0f4f2;
            cursor: pointer;
        }
        .exam-row:hover { background: #fafef8; }
        
        .exam-name { font-weight: 600; font-size: 0.9rem; }
        .exam-meta { font-size: 0.7rem; color: #8aa394; margin-top: 4px; }
        .exam-badge {
            background: #eef6f0;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.7rem;
            color: #2b6e3c;
        }
        
        /* Buttons */
        .btn-primary {
            background: linear-gradient(95deg, #1f9e4a, #2ecc71);
            border: none;
            padding: 10px 24px;
            border-radius: 40px;
            font-weight: 600;
            color: white;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-primary:hover { transform: scale(1.02); box-shadow: 0 5px 15px rgba(46,204,113,0.3); }
        
        .btn-danger {
            background: #e74c3c;
            padding: 6px 14px;
            border-radius: 30px;
            font-size: 0.7rem;
            color: white;
            border: none;
            cursor: pointer;
        }
        
        .btn-success {
            background: #2ecc71;
            padding: 6px 14px;
            border-radius: 30px;
            font-size: 0.7rem;
            color: white;
            border: none;
            cursor: pointer;
        }
        
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            backdrop-filter: blur(4px);
            align-items: center;
            justify-content: center;
            z-index: 2000;
        }
        
        .modal-content {
            background: white;
            border-radius: 28px;
            max-width: 550px;
            width: 90%;
            max-height: 85vh;
            overflow-y: auto;
            padding: 28px;
        }
        
        .modal-content h3 { margin-bottom: 20px; color: #1e462e; }
        
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 0.8rem; font-weight: 500; margin-bottom: 6px; color: #4a6658; }
        .form-group input, .form-group select {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #d4e0da;
            border-radius: 14px;
            font-family: 'Inter', sans-serif;
            font-size: 0.9rem;
        }
        
        .form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 24px; }
        
        /* Table wrapper */
        .table-wrapper { max-height: 320px; overflow-y: auto; }
        
        .full-table { width: 100%; border-collapse: collapse; }
        .full-table th, .full-table td { padding: 12px 16px; text-align: left; border-bottom: 1px solid #ecf3ef; font-size: 0.85rem; }
        .full-table th { background: #f8fbf9; font-weight: 600; color: #2c5e3f; position: sticky; top: 0; }
        .full-table tr:hover { background: #fafef8; }
        
        .action-buttons { display: flex; gap: 8px; }
        
        @media (max-width: 980px) {
            .sidebar { width: 80px; }
            .sidebar .logo-area p, .sidebar .nav-item span, .user-info span { display: none; }
            .dashboard-grid { grid-template-columns: 1fr; }
            .main-content { padding: 20px; }
        }
        
        .toast {
            position: fixed;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            background: #1e5631;
            color: white;
            padding: 12px 24px;
            border-radius: 40px;
            font-weight: 500;
            z-index: 10000;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="logo-area">
        <h2><i class="fas fa-graduation-cap"></i> BGSS</h2>
        <p>Bole General Secondary School</p>
    </div>
    <div class="nav-menu">
        <div class="nav-item"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></div>
        <div class="nav-item active"><i class="fas fa-calendar-alt"></i> <span>Exam Management</span></div>
        <div class="nav-item"><i class="fas fa-chalkboard-user"></i> <span>Teacher Supervision</span></div>
        <div class="nav-item"><i class="fas fa-book-open"></i> <span>Class Schedule</span></div>
        <div class="nav-item"><i class="fas fa-chart-line"></i> <span>Reports</span></div>
        <div class="nav-item"><i class="fas fa-cog"></i> <span>Settings</span></div>
    </div>
    <div class="user-info">
        <i class="fas fa-user-shield"></i> <span><?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Vice Director'); ?></span><br>
        <small><?php echo htmlspecialchars($_SESSION['role'] ?? 'vice_director'); ?></small>
    </div>
</div>

<div class="main-content">
    <div class="page-header">
        <div class="breadcrumb">
            <span><i class="fas fa-home"></i> Dashboard</span> / <span>Academic Affairs</span> / <span>Exam Management</span>
        </div>
        <h1>
            Exam Management
            <button class="btn-primary" id="openCreateModalBtn">
                <i class="fas fa-plus-circle"></i> Schedule New Exam
            </button>
        </h1>
        <div class="subtitle">
            <i class="fas fa-clipboard-list"></i> Manage and schedule school examinations efficiently — organize, publish, and track results.
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-calendar-alt"></i></div>
            <div class="stat-info">
                <h3 id="totalExams"><?php echo $stats['total_exams']; ?></h3>
                <p>Total Exams</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-hourglass-half"></i></div>
            <div class="stat-info">
                <h3 id="upcomingExams"><?php echo $stats['upcoming_exams']; ?></h3>
                <p>Upcoming Exams</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-chalkboard-teacher"></i></div>
            <div class="stat-info">
                <h3><?php echo $stats['total_teachers']; ?></h3>
                <p>Teachers</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-book"></i></div>
            <div class="stat-info">
                <h3><?php echo $stats['total_subjects']; ?></h3>
                <p>Subjects</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-users"></i></div>
            <div class="stat-info">
                <h3><?php echo $stats['total_students']; ?></h3>
                <p>Students</p>
            </div>
        </div>
    </div>

    <!-- Quick Action Cards -->
    <div class="cards-row">
        <div class="action-card" onclick="openCreateModal()">
            <div class="action-icon"><i class="fas fa-calendar-plus"></i></div>
            <h4>Create Schedule</h4>
            <p>Plan exam dates & rooms</p>
        </div>
        <div class="action-card" onclick="viewAllExams()">
            <div class="action-icon"><i class="fas fa-eye"></i></div>
            <h4>View Schedule</h4>
            <p>All exams timeline</p>
        </div>
        <div class="action-card" onclick="showToast('Edit Schedule feature - Click on any exam to edit')">
            <div class="action-icon"><i class="fas fa-edit"></i></div>
            <h4>Edit Schedule</h4>
            <p>Modify & rearrange</p>
        </div>
        <div class="action-card" onclick="showToast('Publish feature - Coming soon')">
            <div class="action-icon"><i class="fas fa-bullhorn"></i></div>
            <h4>Publish Exams</h4>
            <p>Notify students & staff</p>
        </div>
        <div class="action-card" onclick="showToast('Results Dashboard - Coming soon')">
            <div class="action-icon"><i class="fas fa-chart-simple"></i></div>
            <h4>Exam Results</h4>
            <p>Grades & performance</p>
        </div>
    </div>

    <!-- Main Content Grid -->
    <div class="dashboard-grid">
        <!-- Upcoming Exams -->
        <div class="data-card">
            <div class="data-header">
                <h3><i class="far fa-clock"></i> Upcoming Exams</h3>
                <a onclick="loadExams()"><i class="fas fa-sync-alt"></i> Refresh</a>
            </div>
            <div id="upcomingExamsContainer" class="exam-table">
                <?php foreach ($upcomingExamsList as $exam): ?>
                <div class="exam-row" onclick="editExam(<?php echo $exam['id']; ?>)">
                    <div>
                        <div class="exam-name"><?php echo htmlspecialchars($exam['subject_name'] ?? 'Unknown Subject'); ?></div>
                        <div class="exam-meta">
                            📅 <?php echo date('M d, Y', strtotime($exam['exam_date'])); ?> | 
                            🕘 <?php echo date('h:i A', strtotime($exam['start_time'])); ?> | 
                            👨‍🏫 <?php echo htmlspecialchars($exam['teacher_name'] ?? 'TBD'); ?>
                        </div>
                    </div>
                    <span class="exam-badge"><?php echo htmlspecialchars($exam['exam_type']); ?></span>
                </div>
                <?php endforeach; ?>
                <?php if (empty($upcomingExamsList)): ?>
                <div style="padding: 40px; text-align: center; color: #8aa394;">No upcoming exams scheduled</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Statistics Chart -->
        <div class="data-card">
            <div class="data-header">
                <h3><i class="fas fa-chart-pie"></i> Exam Statistics</h3>
            </div>
            <div style="padding: 20px;">
                <canvas id="statsChart" height="180"></canvas>
            </div>
        </div>
    </div>

    <!-- All Exams Table -->
    <div class="data-card">
        <div class="data-header">
            <h3><i class="fas fa-list-ul"></i> All Scheduled Exams</h3>
            <a onclick="exportExams()"><i class="fas fa-download"></i> Export</a>
        </div>
        <div class="table-wrapper">
            <table class="full-table" id="allExamsTable">
                <thead>
                    <tr><th>Subject</th><th>Teacher</th><th>Exam Type</th><th>Date</th><th>Time</th><th>Venue</th><th>Status</th><th>Actions</th></tr>
                </thead>
                <tbody id="allExamsBody">
                    <tr><td colspan="8" style="text-align:center;">Loading exams...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Create/Edit Exam Modal -->
<div id="examModal" class="modal">
    <div class="modal-content">
        <h3 id="modalTitle"><i class="fas fa-plus-circle"></i> Schedule New Exam</h3>
        <form id="examForm">
            <input type="hidden" id="examId" value="">
            <div class="form-group">
                <label>Subject *</label>
                <select id="subjectId" required>
                    <option value="">Select Subject</option>
                    <?php foreach ($subjects as $subject): ?>
                    <option value="<?php echo $subject['id']; ?>"><?php echo htmlspecialchars($subject['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Teacher *</label>
                <select id="teacherId" required>
                    <option value="">Select Teacher</option>
                    <?php foreach ($teachers as $teacher): ?>
                    <option value="<?php echo $teacher['id']; ?>"><?php echo htmlspecialchars($teacher['full_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Grade/Class</label>
                <select id="gradeId">
                    <option value="">All Grades</option>
                    <?php foreach ($grades as $grade): ?>
                    <option value="<?php echo $grade['id']; ?>"><?php echo htmlspecialchars($grade['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Exam Type *</label>
                <select id="examType" required>
                    <option value="Mid-Term">Mid-Term</option>
                    <option value="Final">Final</option>
                    <option value="Quiz">Quiz</option>
                    <option value="Unit Test">Unit Test</option>
                    <option value="Practical">Practical</option>
                </select>
            </div>
            <div class="form-group">
                <label>Exam Date *</label>
                <input type="date" id="examDate" required>
            </div>
            <div class="form-group">
                <label>Start Time</label>
                <input type="time" id="startTime" value="09:00">
            </div>
            <div class="form-group">
                <label>End Time</label>
                <input type="time" id="endTime" value="12:00">
            </div>
            <div class="form-group">
                <label>Venue</label>
                <input type="text" id="venue" placeholder="e.g., Main Hall, Room 201, Lab A">
            </div>
            <div class="form-actions">
                <button type="button" class="btn-primary" onclick="saveExam()">Save Exam</button>
                <button type="button" onclick="closeModal()" style="background:#e2e8e4; color:#2c5e3f;" class="btn-primary">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
let chartInstance = null;
let allExams = [];

// Toast notification
function showToast(message, isError = false) {
    let toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerText = message;
    toast.style.background = isError ? '#c0392b' : '#1e5631';
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// API Request
async function apiRequest(action, data = {}) {
    const formData = new URLSearchParams({ action, ...data });
    try {
        const response = await fetch('', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest' },
            body: formData
        });
        return await response.json();
    } catch (error) {
        showToast('Network error', true);
        return { success: false };
    }
}

// Load all exams
async function loadExams() {
    const result = await apiRequest('get_exams');
    if (result.success && result.exams) {
        allExams = result.exams;
        renderAllExamsTable();
        renderUpcomingExams();
        updateStats();
    }
}

// Render upcoming exams
function renderUpcomingExams() {
    const upcoming = allExams.filter(e => {
        const examDate = new Date(e.exam_date);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return examDate >= today && e.status === 'upcoming';
    }).slice(0, 5);
    
    const container = document.getElementById('upcomingExamsContainer');
    if (upcoming.length === 0) {
        container.innerHTML = '<div style="padding:40px;text-align:center;color:#8aa394;">No upcoming exams</div>';
        return;
    }
    
    container.innerHTML = upcoming.map(exam => `
        <div class="exam-row" onclick="editExam(${exam.id})">
            <div>
                <div class="exam-name">${escapeHtml(exam.subject_name || 'Unknown')}</div>
                <div class="exam-meta">
                    📅 ${new Date(exam.exam_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} | 
                    🕘 ${exam.start_time ? exam.start_time.substring(0,5) : '09:00'} | 
                    👨‍🏫 ${escapeHtml(exam.teacher_name || 'TBD')}
                </div>
            </div>
            <span class="exam-badge">${escapeHtml(exam.exam_type)}</span>
        </div>
    `).join('');
}

// Render all exams table
function renderAllExamsTable() {
    const tbody = document.getElementById('allExamsBody');
    if (!allExams.length) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;">No exams found</td></tr>';
        return;
    }
    
    tbody.innerHTML = allExams.map(exam => `
        <tr>
            <td>${escapeHtml(exam.subject_name || '-')}</td>
            <td>${escapeHtml(exam.teacher_name || '-')}</td>
            <td>${escapeHtml(exam.exam_type)}</td>
            <td>${new Date(exam.exam_date).toLocaleDateString()}</td>
            <td>${exam.start_time ? exam.start_time.substring(0,5) : '-'}</td>
            <td>${escapeHtml(exam.venue || '-')}</td>
            <td><span class="exam-badge">${escapeHtml(exam.status)}</span></td>
            <td class="action-buttons">
                <button class="btn-success" onclick="editExam(${exam.id})"><i class="fas fa-edit"></i></button>
                <button class="btn-danger" onclick="deleteExam(${exam.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');
}

// Update statistics
async function updateStats() {
    const result = await apiRequest('get_stats');
    if (result.success) {
        document.getElementById('totalExams').innerText = result.totalExams;
        document.getElementById('upcomingExams').innerText = result.upcomingCount;
        
        if (chartInstance) chartInstance.destroy();
        const ctx = document.getElementById('statsChart').getContext('2d');
        chartInstance = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Upcoming Exams', 'Completed Exams'],
                datasets: [{
                    data: [result.upcomingCount, result.completedCount],
                    backgroundColor: ['#2ecc71', '#a0c4a8'],
                    borderWidth: 0
                }]
            },
            options: { responsive: true, maintainAspectRatio: true, plugins: { legend: { position: 'bottom' } } }
        });
    }
}

// Create/Update exam
async function saveExam() {
    const id = document.getElementById('examId').value;
    const subject_id = document.getElementById('subjectId').value;
    const teacher_id = document.getElementById('teacherId').value;
    const grade_id = document.getElementById('gradeId').value;
    const exam_type = document.getElementById('examType').value;
    const exam_date = document.getElementById('examDate').value;
    const start_time = document.getElementById('startTime').value;
    const end_time = document.getElementById('endTime').value;
    const venue = document.getElementById('venue').value;
    
    if (!subject_id || !teacher_id || !exam_date) {
        showToast('Please fill required fields', true);
        return;
    }
    
    let result;
    if (id) {
        result = await apiRequest('update_exam', { id, subject_id, grade_id, teacher_id, exam_type, exam_date, start_time, end_time, venue });
    } else {
        result = await apiRequest('create_exam', { subject_id, grade_id, teacher_id, exam_type, exam_date, start_time, end_time, venue });
    }
    
    if (result.success) {
        showToast(result.message);
        closeModal();
        loadExams();
    } else {
        showToast(result.message, true);
    }
}

// Edit exam
async function editExam(id) {
    const exam = allExams.find(e => e.id == id);
    if (!exam) return;
    
    document.getElementById('modalTitle').innerHTML = '<i class="fas fa-edit"></i> Edit Exam';
    document.getElementById('examId').value = exam.id;
    document.getElementById('subjectId').value = exam.subject_id || '';
    document.getElementById('teacherId').value = exam.teacher_id || '';
    document.getElementById('gradeId').value = exam.grade_id || '';
    document.getElementById('examType').value = exam.exam_type || 'Mid-Term';
    document.getElementById('examDate').value = exam.exam_date || '';
    document.getElementById('startTime').value = exam.start_time || '09:00';
    document.getElementById('endTime').value = exam.end_time || '12:00';
    document.getElementById('venue').value = exam.venue || '';
    
    document.getElementById('examModal').style.display = 'flex';
}

// Delete exam
async function deleteExam(id) {
    if (!confirm('Are you sure you want to delete this exam?')) return;
    const result = await apiRequest('delete_exam', { id });
    if (result.success) {
        showToast('Exam deleted successfully');
        loadExams();
    } else {
        showToast('Delete failed', true);
    }
}

// Export exams
function exportExams() {
    const dataStr = JSON.stringify(allExams, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bgss_exams_${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Exported successfully');
}

// View all exams
function viewAllExams() {
    document.getElementById('allExamsTable').scrollIntoView({ behavior: 'smooth' });
}

// Modal functions
function openCreateModal() {
    document.getElementById('modalTitle').innerHTML = '<i class="fas fa-plus-circle"></i> Schedule New Exam';
    document.getElementById('examForm').reset();
    document.getElementById('examId').value = '';
    document.getElementById('examModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('examModal').style.display = 'none';
}

// Escape HTML
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

// Close modal on outside click
window.onclick = (e) => { if (e.target === document.getElementById('examModal')) closeModal(); };

// Initial load
loadExams();
</script>
</body>
</html>