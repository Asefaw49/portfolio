<?php
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    header('Location: index.php');
    exit;
}

$full_name = $_SESSION['full_name'] ?? 'Parent';
$student_name = $_SESSION['user_data']['student_name'] ?? 'Your Child';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parent Portal - BOLE GENERAL SECONDARY SCHOOL</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'DM Sans', sans-serif; background: #f8f6f1; }
        
        .topbar {
            background: linear-gradient(135deg, #1a3d2b 0%, #0f2318 100%);
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
            color: white;
        }
        
        .sidebar {
            width: 240px;
            background: linear-gradient(180deg, #1e4535 0%, #162e24 100%);
            position: fixed;
            left: 0;
            top: 60px;
            height: calc(100vh - 60px);
            padding: 20px 0;
        }
        
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: rgba(255,255,255,0.7);
            cursor: pointer;
            transition: 0.2s;
        }
        
        .sidebar-link:hover { background: rgba(255,255,255,0.1); color: white; }
        .sidebar-link.active { background: rgba(82,183,136,0.2); color: white; }
        
        .main-content {
            margin-left: 240px;
            padding: 28px 32px;
        }
        
        .page-title {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 24px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            border-top: 3px solid #52b788;
        }
        
        .stat-value { font-size: 32px; font-weight: 700; margin: 8px 0; }
        .stat-label { color: #8a9bb0; font-size: 12px; text-transform: uppercase; }
        
        .card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
        }
        
        .section-page { display: none; }
        .section-page.active { display: block; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f6f1; }
        
        .chip {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .chip.green { background: #d4edda; color: #1a6b3c; }
        .chip.red { background: #fde8e8; color: #b91c1c; }
        
        .logout-btn {
            position: absolute;
            bottom: 20px;
            left: 20px;
            right: 20px;
            background: rgba(255,255,255,0.1);
            border: none;
            padding: 10px;
            color: white;
            border-radius: 8px;
            cursor: pointer;
        }
        
        .fee-status {
            background: #fef3cd;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
    </style>
</head>
<body>
    <div class="topbar">
        <div style="display: flex; align-items: center; gap: 16px;">
            <div style="width: 38px; height: 38px; background: linear-gradient(135deg, #c9a84c, #e6c96e); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold;">BGSS</div>
            <div>
                <div style="font-weight: 600;">BOLE GENERAL SECONDARY SCHOOL</div>
                <div style="font-size: 11px; opacity: 0.7;">Parent Portal</div>
            </div>
        </div>
        <div>👨‍👩‍👧 <?php echo htmlspecialchars($full_name); ?></div>
    </div>
    
    <div class="sidebar">
        <div class="sidebar-link active" onclick="showPage('dashboard')">🏠 Dashboard</div>
        <div class="sidebar-link" onclick="showPage('grades')">📝 Child's Grades</div>
        <div class="sidebar-link" onclick="showPage('attendance')">✅ Attendance</div>
        <div class="sidebar-link" onclick="showPage('fees')">💰 Fee Status</div>
        <div class="sidebar-link" onclick="showPage('announcements')">📢 Announcements</div>
        <button class="logout-btn" onclick="logout()">🚪 Sign Out</button>
    </div>
    
    <div class="main-content">
        <!-- Dashboard -->
        <div id="dashboard" class="section-page active">
            <div class="page-title">Parent Dashboard</div>
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-label">Student Name</div><div class="stat-value">Ayana T.</div><div class="stat-delta">Grade 11A</div></div>
                <div class="stat-card"><div class="stat-label">Current GPA</div><div class="stat-value">3.8</div><div class="stat-delta">↑ 0.2</div></div>
                <div class="stat-card"><div class="stat-label">Attendance</div><div class="stat-value">94%</div><div class="stat-delta">This term</div></div>
                <div class="stat-card"><div class="stat-label">Class Rank</div><div class="stat-value">#12</div><div class="stat-delta">of 42</div></div>
            </div>
            <div class="card">
                <h3>📢 School Announcements</h3>
                <div style="padding: 12px 0; border-bottom: 1px solid #eee;">📢 Parent-Teacher Meeting - November 22, 2024 at 2:00 PM</div>
                <div style="padding: 12px 0; border-bottom: 1px solid #eee;">📢 Annual Sports Day - December 5, 2024</div>
                <div style="padding: 12px 0;">📢 Fee Payment Deadline - November 30, 2024</div>
            </div>
            <div class="fee-status">
                <strong>💰 Fee Status:</strong> Paid (ETB 1,500 of 1,500) ✅
            </div>
        </div>
        
        <!-- Grades -->
        <div id="grades" class="section-page">
            <div class="page-title">Child's Academic Performance</div>
            <div class="card">
                <h3>Grade 11A - First Semester</h3>
                <table>
                    <thead><tr><th>Subject</th><th>Teacher</th><th>Mid-Term</th><th>Final</th><th>Grade</th></tr></thead>
                    <tbody>
                        <tr><td>Mathematics</td><td>Mr. Kebede</td><td>85</td><td>90</td><td><span class="chip green">A</span></td></tr>
                        <tr><td>Biology</td><td>Ms. Tigist</td><td>78</td><td>82</td><td><span class="chip green">B+</span></td></tr>
                        <tr><td>Physics</td><td>Mr. Yonas</td><td>88</td><td>91</td><td><span class="chip green">A</span></td></tr>
                        <tr><td>English</td><td>Mr. Girma</td><td>92</td><td>95</td><td><span class="chip green">A+</span></td></tr>
                        <tr><td>Chemistry</td><td>Ms. Hana</td><td>74</td><td>78</td><td><span class="chip green">B+</span></td></tr>
                    </tbody>
                </table>
                <div style="margin-top: 16px; padding: 12px; background: #e8f5ee; border-radius: 8px;">
                    <strong>📊 Overall GPA: 3.8 (Good Standing)</strong>
                </div>
            </div>
        </div>
        
        <!-- Attendance -->
        <div id="attendance" class="section-page">
            <div class="page-title">Attendance Record</div>
            <div class="card">
                <div class="stats-grid" style="grid-template-columns: repeat(3, 1fr);">
                    <div class="stat-card"><div class="stat-label">Days Present</div><div class="stat-value">82</div></div>
                    <div class="stat-card"><div class="stat-label">Days Absent</div><div class="stat-value">5</div></div>
                    <div class="stat-card"><div class="stat-label">Attendance Rate</div><div class="stat-value">94%</div></div>
                </div>
                <h3>November 2024</h3>
                <div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 5px; margin-top: 16px;">
                    <?php
                    $days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                    foreach ($days as $day) {
                        echo "<div style='text-align: center; font-weight: 600; padding: 8px;'>$day</div>";
                    }
                    for ($i = 1; $i <= 30; $i++) {
                        $status = in_array($i, [7, 14, 21]) ? 'absent' : 'present';
                        $color = $status === 'present' ? '#d4edda' : '#fde8e8';
                        echo "<div style='text-align: center; padding: 8px; background: $color; border-radius: 8px;'>$i</div>";
                    }
                    ?>
                </div>
                <div style="margin-top: 16px;">
                    <span><span style="display: inline-block; width: 12px; height: 12px; background: #d4edda; border-radius: 3px;"></span> Present (25 days)</span>
                    <span style="margin-left: 16px;"><span style="display: inline-block; width: 12px; height: 12px; background: #fde8e8; border-radius: 3px;"></span> Absent (3 days)</span>
                </div>
            </div>
        </div>
        
        <!-- Fees -->
        <div id="fees" class="section-page">
            <div class="page-title">Fee Status</div>
            <div class="card">
                <div class="stats-grid" style="grid-template-columns: repeat(3, 1fr);">
                    <div class="stat-card"><div class="stat-label">Total Fees</div><div class="stat-value">ETB 1,500</div></div>
                    <div class="stat-card"><div class="stat-label">Amount Paid</div><div class="stat-value">ETB 1,500</div></div>
                    <div class="stat-card"><div class="stat-label">Balance</div><div class="stat-value">ETB 0</div></div>
                </div>
                <div class="fee-status" style="background: #d4edda;">
                    ✅ Fee Status: Fully Paid - Good Standing
                </div>
                <table>
                    <thead><tr><th>Date</th><th>Amount (ETB)</th><th>Payment Method</th><th>Receipt No</th></tr></thead>
                    <tbody>
                        <tr><td>October 15, 2024</td><td>750</td><td>Bank Transfer</td><td>RCP-001</td></tr>
                        <tr><td>September 10, 2024</td><td>750</td><td>Cash</td><td>RCP-002</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Announcements -->
        <div id="announcements" class="section-page">
            <div class="page-title">School Announcements</div>
            <div class="card">
                <div style="padding: 16px; border-bottom: 1px solid #eee;">
                    <strong>Parent-Teacher Meeting</strong><br>
                    Date: November 22, 2024 | Time: 2:00 PM - 5:00 PM | Venue: School Hall<br>
                    <span style="font-size: 12px; color: #666;">Please come to discuss your child's progress.</span>
                </div>
                <div style="padding: 16px; border-bottom: 1px solid #eee;">
                    <strong>Annual Sports Day</strong><br>
                    Date: December 5, 2024 | Time: 9:00 AM | Venue: School Field<br>
                    <span style="font-size: 12px; color: #666;">All parents are invited to attend.</span>
                </div>
                <div style="padding: 16px;">
                    <strong>Fee Payment Deadline</strong><br>
                    Deadline: November 30, 2024<br>
                    <span style="font-size: 12px; color: #666;">Please ensure fees are paid by the deadline.</span>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function showPage(pageId) {
            document.querySelectorAll('.section-page').forEach(p => p.classList.remove('active'));
            document.getElementById(pageId).classList.add('active');
            document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
            event.target.closest('.sidebar-link').classList.add('active');
        }
        
        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                window.location.href = 'logout.php';
            }
        }
    </script>
</body>
</html>