-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 28, 2026 at 02:53 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text DEFAULT NULL,
  `audience` enum('all','director','vice_director','hr_manager','finance','teacher','student','parent') DEFAULT 'all',
  `author_id` int(11) DEFAULT NULL,
  `status` enum('draft','published') DEFAULT 'published',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `content`, `audience`, `author_id`, `status`, `created_at`) VALUES
(1, 'Staff Meeting Notice', 'There will be an emergency staff meeting on November 24, 2024, at 3:00 PM. Attendance is mandatory.', 'teacher', 1, 'published', '2024-11-22 05:00:00'),
(2, 'Grade Submission Deadline', 'All mid-term grades must be submitted by November 28, 2024. Late submissions will be noted.', 'teacher', 1, 'published', '2024-11-20 06:00:00'),
(3, 'Exam Hall Assignments', 'Exam hall assignments for Grade 12 students have been posted on the notice board. Please check your assigned room before exam day.', 'student', 1, 'published', '2024-11-19 07:00:00'),
(4, 'Scholarship Applications Open', 'Applications for the academic scholarship are now open. Eligible students must have a GPA of 3.5 or above. Deadline: December 15, 2024.', 'student', 1, 'published', '2024-11-16 08:30:00'),
(5, 'School Transport Schedule Change', 'The afternoon school bus schedule has been adjusted. Buses will now depart at 4:30 PM instead of 4:00 PM, effective December 1, 2024.', 'parent', 1, 'published', '2024-11-18 10:15:00'),
(6, 'Parent Portal Access', 'Parents can now access the online parent portal to view their child\'s grades, attendance, and fee status. Please contact the IT department for login credentials.', 'parent', 1, 'published', '2024-11-14 06:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` enum('present','absent','late') DEFAULT 'present',
  `note` text DEFAULT NULL,
  `marked_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `student_id`, `teacher_id`, `class_id`, `date`, `status`, `note`, `marked_at`) VALUES
(1, 1, 1, 101, '2024-11-18', 'present', NULL, '2024-11-18 06:00:00'),
(2, 2, 1, 101, '2024-11-18', 'present', NULL, '2024-11-18 06:00:00'),
(3, 3, 1, 101, '2024-11-18', 'absent', 'Sick', '2024-11-18 06:00:00'),
(4, 4, 1, 101, '2024-11-18', 'late', 'Arrived late', '2024-11-18 06:15:00'),
(5, 5, 1, 101, '2024-11-18', 'present', NULL, '2024-11-18 06:00:00'),
(6, 1, 2, 102, '2024-11-18', 'present', NULL, '2024-11-18 07:00:00'),
(7, 2, 2, 102, '2024-11-18', 'absent', 'Family emergency', '2024-11-18 07:00:00'),
(8, 1, 1, 101, '2024-11-19', 'present', NULL, '2024-11-19 06:00:00'),
(9, 2, 1, 101, '2024-11-19', 'present', NULL, '2024-11-19 06:00:00'),
(10, 3, 1, 101, '2024-11-19', 'present', NULL, '2024-11-19 06:00:00'),
(11, 4, 1, 101, '2024-11-19', 'absent', 'Doctor appointment', '2024-11-19 06:00:00'),
(12, 5, 1, 101, '2024-11-19', 'present', NULL, '2024-11-19 06:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `book_loans`
--

CREATE TABLE `book_loans` (
  `id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `user_type` enum('student','teacher') DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `borrow_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `status` enum('borrowed','returned','overdue') DEFAULT 'borrowed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_loans`
--

INSERT INTO `book_loans` (`id`, `book_id`, `user_type`, `user_id`, `borrow_date`, `due_date`, `return_date`, `status`) VALUES
(1, 1, 'student', 1, '2024-11-10', '2024-11-24', NULL, 'borrowed'),
(2, 2, 'student', 2, '2024-11-12', '2024-11-26', NULL, 'borrowed'),
(3, 3, 'student', 3, '2024-11-05', '2024-11-19', NULL, 'overdue'),
(4, 4, 'teacher', 1, '2024-11-15', '2024-11-29', NULL, 'borrowed'),
(5, 1, 'student', 4, '2024-11-08', '2024-11-22', NULL, 'borrowed'),
(6, 2, 'teacher', 2, '2024-11-01', '2024-11-15', NULL, 'overdue'),
(7, 3, 'student', 5, '2024-11-14', '2024-11-28', NULL, 'borrowed'),
(8, 4, 'student', 6, '2024-11-09', '2024-11-23', NULL, 'borrowed'),
(9, 1, 'student', 7, '2024-10-15', '2024-10-29', '2024-10-28', 'returned'),
(10, 2, 'teacher', 3, '2024-10-20', '2024-11-03', '2024-11-02', 'returned'),
(11, 3, 'student', 8, '2024-10-25', '2024-11-08', '2024-11-07', 'returned'),
(12, 4, 'student', 9, '2024-10-28', '2024-11-11', '2024-11-10', 'returned'),
(13, 1, 'teacher', 4, '2024-10-05', '2024-10-19', '2024-10-18', 'returned'),
(14, 2, 'student', 10, '2024-10-12', '2024-10-26', '2024-10-25', 'returned'),
(15, 3, 'student', 11, '2024-10-18', '2024-11-01', '2024-10-30', 'returned'),
(16, 4, 'teacher', 5, '2024-10-22', '2024-11-05', '2024-11-04', 'returned'),
(17, 1, 'student', 12, '2024-11-11', '2024-11-25', NULL, 'borrowed'),
(18, 2, 'student', 13, '2024-11-13', '2024-11-27', NULL, 'borrowed'),
(19, 3, 'teacher', 6, '2024-11-16', '2024-11-30', NULL, 'borrowed'),
(20, 4, 'student', 14, '2024-11-17', '2024-12-01', NULL, 'borrowed'),
(21, 1, 'student', 15, '2024-11-18', '2024-12-02', NULL, 'borrowed'),
(22, 2, 'teacher', 7, '2024-11-19', '2024-12-03', NULL, 'borrowed'),
(23, 3, 'student', 16, '2024-11-20', '2024-12-04', NULL, 'borrowed'),
(24, 4, 'student', 17, '2024-11-21', '2024-12-05', NULL, 'borrowed'),
(25, 1, 'student', 18, '2024-11-01', '2024-11-15', '2024-11-14', 'returned'),
(26, 2, 'student', 19, '2024-11-02', '2024-11-16', '2024-11-15', 'returned'),
(27, 3, 'teacher', 8, '2024-11-03', '2024-11-17', '2024-11-16', 'returned'),
(28, 4, 'student', 20, '2024-11-04', '2024-11-18', '2024-11-17', 'returned'),
(29, 1, 'student', 21, '2024-11-05', '2024-11-19', '2024-11-18', 'returned'),
(30, 2, 'teacher', 9, '2024-11-06', '2024-11-20', '2024-11-19', 'returned'),
(31, 3, 'student', 22, '2024-11-07', '2024-11-21', '2024-11-20', 'returned'),
(32, 4, 'student', 23, '2024-11-08', '2024-11-22', '2024-11-21', 'returned'),
(33, 1, 'student', 24, '2024-10-25', '2024-11-08', NULL, 'overdue'),
(34, 2, 'student', 25, '2024-10-28', '2024-11-11', NULL, 'overdue'),
(35, 3, 'teacher', 10, '2024-10-30', '2024-11-13', NULL, 'overdue'),
(36, 4, 'student', 26, '2024-11-01', '2024-11-15', NULL, 'overdue'),
(37, 1, 'student', 27, '2024-11-03', '2024-11-17', NULL, 'overdue');

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `enrolled_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `exam_type` varchar(50) DEFAULT NULL,
  `exam_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `venue` varchar(100) DEFAULT NULL,
  `status` enum('upcoming','completed') DEFAULT 'upcoming'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`id`, `subject_id`, `grade_id`, `teacher_id`, `exam_type`, `exam_date`, `start_time`, `end_time`, `venue`, `status`) VALUES
(1, 1, 3, 1, 'Mid-Term', '2024-11-18', '09:00:00', '12:00:00', 'Main Hall', 'upcoming'),
(2, 2, 3, 2, 'Mid-Term', '2024-11-25', '08:00:00', '11:00:00', 'Hall B', 'upcoming'),
(3, 3, 4, 3, 'Final', '2024-12-02', '10:00:00', '13:00:00', 'Lab A', 'upcoming'),
(4, 4, 2, 4, 'Unit Test', '2024-11-10', '10:00:00', '12:00:00', 'Room 204', 'completed'),
(5, 5, 3, 5, 'Mid-Term', '2024-11-28', '09:00:00', '12:00:00', 'Chemistry Lab', 'upcoming'),
(6, 1, 4, 1, 'Final', '2024-12-10', '09:00:00', '12:00:00', 'Main Hall', 'upcoming');

-- --------------------------------------------------------

--
-- Table structure for table `fee_payments`
--

CREATE TABLE `fee_payments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` enum('cash','bank_transfer','check','mobile_money') DEFAULT 'cash',
  `receipt_no` varchar(50) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `recorded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_payments`
--

INSERT INTO `fee_payments` (`id`, `student_id`, `parent_id`, `amount`, `payment_date`, `payment_method`, `receipt_no`, `remarks`, `recorded_by`, `created_at`) VALUES
(1, 1, NULL, 750.00, '2024-09-10', 'cash', 'RCP-001', 'First installment', NULL, '2026-05-20 11:44:23'),
(2, 1, NULL, 750.00, '2024-10-15', 'bank_transfer', 'RCP-002', 'Second installment', NULL, '2026-05-20 11:44:23'),
(3, 2, NULL, 750.00, '2024-09-15', 'cash', 'RCP-003', 'First installment', NULL, '2026-05-20 11:44:23'),
(4, 3, NULL, 750.00, '2024-09-05', 'bank_transfer', 'RCP-004', 'First installment', NULL, '2026-05-20 11:44:23'),
(5, 3, NULL, 750.00, '2024-09-20', 'cash', 'RCP-005', 'Second installment', NULL, '2026-05-20 11:44:23'),
(6, 5, NULL, 750.00, '2024-09-08', 'bank_transfer', 'RCP-006', 'First installment', NULL, '2026-05-20 11:44:23'),
(7, 5, NULL, 750.00, '2024-10-05', 'cash', 'RCP-007', 'Second installment', NULL, '2026-05-20 11:44:23');

-- --------------------------------------------------------

--
-- Table structure for table `fee_records`
--

CREATE TABLE `fee_records` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `total_fees` decimal(10,2) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT 0.00,
  `academic_year` varchar(20) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `status` enum('paid','partial','pending') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_records`
--

INSERT INTO `fee_records` (`id`, `student_id`, `total_fees`, `amount_paid`, `academic_year`, `payment_date`, `status`) VALUES
(6, 1, 1500.00, 1500.00, '2024/2025', '2024-10-15', 'paid'),
(7, 2, 1500.00, 750.00, '2024/2025', '2024-10-10', 'partial'),
(8, 3, 1500.00, 1500.00, '2024/2025', '2024-09-20', 'paid'),
(9, 4, 1500.00, 0.00, '2024/2025', NULL, 'pending'),
(10, 5, 1500.00, 1500.00, '2024/2025', '2024-10-05', 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `exam_type` varchar(50) DEFAULT NULL,
  `score` decimal(5,2) DEFAULT NULL,
  `continuous_score` decimal(5,2) DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`id`, `student_id`, `subject_id`, `exam_type`, `score`, `continuous_score`, `teacher_id`, `recorded_at`) VALUES
(1, 1, 1, 'midterm', 85.00, 18.00, 1, '2024-11-15 07:00:00'),
(2, 1, 2, 'midterm', 78.00, 17.00, 2, '2024-11-15 07:00:00'),
(3, 1, 3, 'midterm', 88.00, 19.00, 3, '2024-11-15 07:00:00'),
(4, 1, 4, 'midterm', 92.00, 20.00, 4, '2024-11-15 07:00:00'),
(5, 1, 5, 'midterm', 74.00, 16.00, 5, '2024-11-15 07:00:00'),
(6, 2, 1, 'midterm', 72.00, 15.00, 1, '2024-11-15 07:00:00'),
(7, 2, 2, 'midterm', 82.00, 18.00, 2, '2024-11-15 07:00:00'),
(8, 2, 3, 'midterm', 68.00, 14.00, 3, '2024-11-15 07:00:00'),
(9, 2, 4, 'midterm', 75.00, 16.00, 4, '2024-11-15 07:00:00'),
(10, 3, 1, 'midterm', 78.00, 16.00, 1, '2024-11-15 07:00:00'),
(11, 3, 2, 'midterm', 85.00, 18.00, 2, '2024-11-15 07:00:00'),
(12, 3, 4, 'midterm', 88.00, 19.00, 4, '2024-11-15 07:00:00'),
(13, 4, 1, 'midterm', 65.00, 12.00, 1, '2024-11-15 07:00:00'),
(14, 4, 3, 'midterm', 70.00, 15.00, 3, '2024-11-15 07:00:00'),
(15, 5, 1, 'midterm', 92.00, 20.00, 1, '2024-11-15 07:00:00'),
(16, 5, 2, 'midterm', 88.00, 19.00, 2, '2024-11-15 07:00:00'),
(17, 5, 4, 'midterm', 95.00, 20.00, 4, '2024-11-15 07:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `library_books`
--

CREATE TABLE `library_books` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `author` varchar(100) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `isbn` varchar(20) DEFAULT NULL,
  `total_copies` int(11) DEFAULT 1,
  `available_copies` int(11) DEFAULT 1,
  `color` varchar(20) DEFAULT '#4a90d9',
  `status` enum('available','checked_out') DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `library_books`
--

INSERT INTO `library_books` (`id`, `title`, `author`, `category`, `isbn`, `total_copies`, `available_copies`, `color`, `status`) VALUES
(1, 'Campbell Biology (12th Ed.)', 'Urry, Cain, Wasserman', 'Science', NULL, 5, 3, '#4a90d9', 'available'),
(2, 'Advanced Mathematics', 'Ethiopian Curriculum Press', 'Mathematics', NULL, 10, 7, '#52b788', 'available'),
(3, 'Ethiopia: A History', 'Harold G. Marcus', 'History', NULL, 4, 2, '#c9a84c', 'available'),
(4, 'Fundamentals of Physics', 'Halliday & Resnick', 'Physics', NULL, 3, 0, '#a78bfa', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `id` int(11) NOT NULL,
  `parent_id` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `grade_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `gpa` decimal(3,2) DEFAULT 0.00,
  `attendance_rate` decimal(5,2) DEFAULT 0.00,
  `class_rank` int(11) DEFAULT 0,
  `parent_name` varchar(100) DEFAULT NULL,
  `parent_phone` varchar(20) DEFAULT NULL,
  `fee_status` enum('paid','partial','pending') DEFAULT 'pending',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `parent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_id`, `full_name`, `grade_id`, `section_id`, `gpa`, `attendance_rate`, `class_rank`, `parent_name`, `parent_phone`, `fee_status`, `status`, `created_at`, `parent_id`) VALUES
(1, 'STU-001', 'Ayana Tadesse', 3, 1, 0.00, 0.00, 0, NULL, NULL, 'pending', 'active', '2026-05-20 11:41:05', NULL),
(2, 'STU-002', 'Biruk Alemu', 3, 2, 0.00, 0.00, 0, NULL, NULL, 'pending', 'active', '2026-05-20 11:41:05', NULL),
(3, 'STU-003', 'Chaltu Haile', 2, 1, 0.00, 0.00, 0, NULL, NULL, 'pending', 'active', '2026-05-20 11:41:05', NULL),
(4, 'STU-004', 'Dawit Mekonnen', 4, 3, 0.00, 0.00, 0, NULL, NULL, 'pending', 'active', '2026-05-20 11:41:05', NULL),
(5, 'STU-005', 'Eman Ibrahim', 1, 2, 0.00, 0.00, 0, NULL, NULL, 'pending', 'active', '2026-05-20 11:41:05', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `code`) VALUES
(1, 'Mathematics', 'MATH101'),
(2, 'Biology', 'BIO101'),
(3, 'Physics', 'PHY101'),
(4, 'English', 'ENG101'),
(5, 'Chemistry', 'CHEM101'),
(6, 'History', 'HIST101');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `teacher_id` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `subject_name` varchar(50) DEFAULT NULL,
  `grades_taught` varchar(50) DEFAULT NULL,
  `class_count` int(11) DEFAULT 0,
  `status` enum('active','leave','absent') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `teacher_id`, `full_name`, `subject_name`, `grades_taught`, `class_count`, `status`, `created_at`) VALUES
(1, 'TCH-001', 'Kebede Mamo', 'Mathematics', '10,11,12', 6, 'active', '2026-05-20 12:29:00'),
(2, 'TCH-002', 'Tigist Abebe', 'Biology', '11,12', 4, 'active', '2026-05-20 12:29:00'),
(3, 'TCH-003', 'Yonas Bekele', 'Physics', '9,10,11', 6, 'active', '2026-05-20 12:29:00'),
(4, 'TCH-004', 'Girma Seleshi', 'English', '9,10', 5, 'leave', '2026-05-20 12:29:00'),
(5, 'TCH-005', 'Hana Tesfaye', 'Chemistry', '11,12', 4, 'active', '2026-05-20 12:29:00'),
(6, 'TCH-006', 'Sara Hailu', 'History', '9,10', 5, 'active', '2026-05-20 12:29:00');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_subjects`
--

CREATE TABLE `teacher_subjects` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `grade_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` enum('director','vice_director','hr_manager','finance','teacher','student','parent','system_administrator') NOT NULL,
  `user_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_data`)),
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `role`, `user_data`, `status`, `created_at`) VALUES
(1, 'admin', '$2y$10$efOmHYmB1to3kY267dOk5ernfTZ1J7RSj5XLoDQJSO95NgPje.JaG', 'Admin User', 'director', NULL, 'active', '2026-05-19 09:22:12'),
(2, 'teacher1', '$2y$10$NWPDDYITjXt49rppYwgxXOXpL0kkiKAUaohiVQP25sHBkzkNwNt0K', 'Kebede Mamo', 'teacher', NULL, 'active', '2026-05-19 09:22:12'),
(3, 'student1', '$2y$10$NWPDDYITjXt49rppYwgxXOXpL0kkiKAUaohiVQP25sHBkzkNwNt0K', 'Ayana Tadesse', 'student', NULL, 'active', '2026-05-19 09:22:12'),
(4, 'parent1', '$2y$10$lc1DkKGfQkRZl3gKHaFw4eaRb3j7p/gA8G88TmBWgrtkvuefyI/l.', 'Tadesse Mamo', 'parent', '{\"student_id\": 1, \"student_name\": \"Ayana Tadesse\"}', 'active', '2026-05-20 10:56:47'),
(5, 'parent2', '$2y$10$NWPDDYITjXt49rppYwgxXOXpL0kkiKAUaohiVQP25sHBkzkNwNt0K', 'Alemu Bekele', 'parent', '{\"student_id\": 2, \"student_name\": \"Biruk Alemu\"}', 'active', '2026-05-20 10:56:47'),
(6, 'parent3', '$2y$10$NWPDDYITjXt49rppYwgxXOXpL0kkiKAUaohiVQP25sHBkzkNwNt0K', 'Haile Worku', 'parent', '{\"student_id\": 3, \"student_name\": \"Chaltu Haile\"}', 'active', '2026-05-20 10:56:47'),
(7, 'parent4', '$2y$10$NWPDDYITjXt49rppYwgxXOXpL0kkiKAUaohiVQP25sHBkzkNwNt0K', 'Mekonnen Desta', 'parent', '{\"student_id\": 4, \"student_name\": \"Dawit Mekonnen\"}', 'active', '2026-05-20 10:56:47'),
(8, 'parent5', '$2y$10$NWPDDYITjXt49rppYwgxXOXpL0kkiKAUaohiVQP25sHBkzkNwNt0K', 'Ibrahim Ahmed', 'parent', '{\"student_id\": 5, \"student_name\": \"Eman Ibrahim\"}', 'active', '2026-05-20 10:56:47'),
(9, 'vice_director1', '$2y$10$Y8vn54DzxRPP2552oNV.JurVhfUPTdNVHZ6sr8GIaeQPDrGDSYsdi', 'Dr. Solomon Tesfaye', 'vice_director', '{\"position\": \"Vice Director\", \"department\": \"Academic Affairs\"}', 'active', '2026-05-20 13:01:47'),
(10, 'director2', '$2y$10$NWPDDYITjXt49rppYwgxXOXpL0kkiKAUaohiVQP25sHBkzkNwNt0K', 'W/ro Mebrat Kebede', 'vice_director', '{\"position\": \"Vice Director\", \"department\": \"Administration\"}', 'active', '2026-05-20 13:01:47'),
(11, 'hr_manager1', '$2y$10$6RS4yyI9AF6xF9agPV4vpOxxJJ8z8X/Ck7j0puoN/VqaEOZNLzamW', 'Ato Berhanu Desta', 'hr_manager', '{\"position\": \"HR Manager\", \"department\": \"Human Resources\"}', 'active', '2026-05-20 13:01:47'),
(12, 'hr_manager2', '$2y$10$NWPDDYITjXt49rppYwgxXOXpL0kkiKAUaohiVQP25sHBkzkNwNt0K', 'W/ro Meseret Getachew', 'hr_manager', '{\"position\": \"HR Assistant Manager\", \"department\": \"Human Resources\"}', 'active', '2026-05-20 13:01:47'),
(14, 'finance1', '$2y$10$brMrUCWJ2rOt4KEew06ih.7toIHz/G5ol8ikKBc44n98lNBAP4Bdy', 'Ato Tesfaye Girma', 'finance', '{\"position\": \"Finance Manager\", \"department\": \"Finance & Accounts\"}', 'active', '2026-05-26 07:23:39'),
(15, 'finance2', '$2y$10$NWPDDYITjXt49rppYwgxXOXpL0kkiKAUaohiVQP25sHBkzkNwNt0K', 'W/ro Azeb Tadesse', 'finance', '{\"position\": \"Finance Officer\", \"department\": \"Finance & Accounts\"}', 'active', '2026-05-26 07:23:39'),
(22, 'sysadmin1', '$2y$10$aUHfwl/zbNUMfrY9xpX76uei8mRMAebkUgRh5e/sPIqGphIekkiz6', 'system_administrator', 'system_administrator', NULL, 'active', '2026-05-26 13:00:29'),
(25, 'sysadmin2', '$2y$10$123456789123456789123uQwXyZAbCdEfGhIjKlMnOpQrStUv', 'System Administrator', 'system_administrator', NULL, 'active', '2026-05-28 06:49:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author_id` (`author_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `book_loans`
--
ALTER TABLE `book_loans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `fee_payments`
--
ALTER TABLE `fee_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `receipt_no` (`receipt_no`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `fee_records`
--
ALTER TABLE `fee_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `library_books`
--
ALTER TABLE `library_books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `parent_id` (`parent_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_id` (`student_id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `teacher_subjects`
--
ALTER TABLE `teacher_subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `book_loans`
--
ALTER TABLE `book_loans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `fee_payments`
--
ALTER TABLE `fee_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `fee_records`
--
ALTER TABLE `fee_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `library_books`
--
ALTER TABLE `library_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `teacher_subjects`
--
ALTER TABLE `teacher_subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `announcements_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `book_loans`
--
ALTER TABLE `book_loans`
  ADD CONSTRAINT `book_loans_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `library_books` (`id`);

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  ADD CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`);

--
-- Constraints for table `exams`
--
ALTER TABLE `exams`
  ADD CONSTRAINT `exams_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `fee_payments`
--
ALTER TABLE `fee_payments`
  ADD CONSTRAINT `fee_payments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  ADD CONSTRAINT `fee_payments_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`id`);

--
-- Constraints for table `fee_records`
--
ALTER TABLE `fee_records`
  ADD CONSTRAINT `fee_records_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `grades`
--
ALTER TABLE `grades`
  ADD CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  ADD CONSTRAINT `grades_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `parents`
--
ALTER TABLE `parents`
  ADD CONSTRAINT `parents_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`id`);

--
-- Constraints for table `teacher_subjects`
--
ALTER TABLE `teacher_subjects`
  ADD CONSTRAINT `teacher_subjects_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`),
  ADD CONSTRAINT `teacher_subjects_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
