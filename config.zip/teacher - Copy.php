<?php
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header('Location: index.php');
    exit;
}

$full_name = $_SESSION['full_name'] ?? 'Teacher';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Portal - BOLE GENERAL SECONDARY SCHOOL</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'DM Sans', sans-serif; background: #f8f6f1; }
        
        .topbar {
            background: linear-gradient(135deg, #1a3d2b 0%, #0f2318 100%);
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
            color: white;
        }
        
        .sidebar {
            width: 240px;
            background: linear-gradient(180deg, #1e4535 0%, #162e24 100%);
            position: fixed;
            left: 0;
            top: 60px;
            height: calc(100vh - 60px);
            padding: 20px 0;
        }
        
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: rgba(255,255,255,0.7);
            cursor: pointer;
            transition: 0.2s;
        }
        
        .sidebar-link:hover { background: rgba(255,255,255,0.1); color: white; }
        .sidebar-link.active { background: rgba(82,183,136,0.2); color: white; }
        
        .main-content {
            margin-left: 240px;
            padding: 28px 32px;
        }
        
        .page-title {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 24px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            border-top: 3px solid #52b788;
        }
        
        .stat-value { font-size: 32px; font-weight: 700; margin: 8px 0; }
        .stat-label { color: #8a9bb0; font-size: 12px; text-transform: uppercase; }
        
        .card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
        }
        
        .section-page { display: none; }
        .section-page.active { display: block; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f6f1; }
        
        .field-input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-family: inherit;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #2d6a4f, #1a3d2b);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
        }
        
        .logout-btn {
            position: absolute;
            bottom: 20px;
            left: 20px;
            right: 20px;
            background: rgba(255,255,255,0.1);
            border: none;
            padding: 10px;
            color: white;
            border-radius: 8px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="topbar">
        <div style="display: flex; align-items: center; gap: 16px;">
            <div style="width: 38px; height: 38px; background: linear-gradient(135deg, #c9a84c, #e6c96e); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold;">BGSS</div>
            <div>
                <div style="font-weight: 600;">BOLE GENERAL SECONDARY SCHOOL</div>
                <div style="font-size: 11px; opacity: 0.7;">Teacher Portal</div>
            </div>
        </div>
        <div>👩‍🏫 <?php echo htmlspecialchars($full_name); ?></div>
    </div>
    
    <div class="sidebar">
        <div class="sidebar-link active" onclick="showPage('dashboard')">🏠 Dashboard</div>
        <div class="sidebar-link" onclick="showPage('students')">👥 My Students</div>
        <div class="sidebar-link" onclick="showPage('grades')">📝 Enter Grades</div>
        <div class="sidebar-link" onclick="showPage('attendance')">✅ Mark Attendance</div>
        <div class="sidebar-link" onclick="showPage('schedule')">📅 My Schedule</div>
        <button class="logout-btn" onclick="logout()">🚪 Sign Out</button>
    </div>
    
    <div class="main-content">
        <!-- Dashboard -->
        <div id="dashboard" class="section-page active">
            <div class="page-title">Teacher Dashboard</div>
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-label">My Courses</div><div class="stat-value">5</div></div>
                <div class="stat-card"><div class="stat-label">Total Students</div><div class="stat-value">205</div></div>
                <div class="stat-card"><div class="stat-label">Attendance Rate</div><div class="stat-value">91%</div></div>
                <div class="stat-card"><div class="stat-label">Pending Grades</div><div class="stat-value">3</div></div>
            </div>
            <div class="card">
                <h3>📋 Today's Classes</h3>
                <table>
                    <tr><th>Time</th><th>Class</th><th>Subject</th><th>Room</th></tr>
                    <tr><td>8:00 - 9:00</td><td>Grade 11A</td><td>Mathematics</td><td>Room 101</td></tr>
                    <tr><td>9:00 - 10:00</td><td>Grade 11B</td><td>Mathematics</td><td>Room 102</td></tr>
                    <tr><td>10:20 - 11:20</td><td>Grade 12A</td><td>Mathematics</td><td>Room 201</td></tr>
                </table>
            </div>
        </div>
        
        <!-- Students -->
        <div id="students" class="section-page">
            <div class="page-title">My Students</div>
            <div class="card">
                <div style="margin-bottom: 16px;">
                    <input type="text" class="field-input" placeholder="Search students..." style="width: 300px;">
                </div>
                <table>
                    <thead><tr><th>ID</th><th>Name</th><th>Class</th><th>Attendance</th><th>Last Grade</th></tr></thead>
                    <tbody>
                        <tr><td>STU-001</td><td>Ayana Tadesse</td><td>11A</td><td>97%</td><td>85 (A)</td></tr>
                        <tr><td>STU-002</td><td>Biruk Alemu</td><td>11B</td><td>88%</td><td>72 (B)</td></tr>
                        <tr><td>STU-003</td><td>Chaltu Haile</td><td>11A</td><td>94%</td><td>78 (B+)</td></tr>
                        <tr><td>STU-004</td><td>Dawit Mekonnen</td><td>12A</td><td>79%</td><td>65 (C)</td></tr>
                        <tr><td>STU-005</td><td>Eman Ibrahim</td><td>11A</td><td>99%</td><td>92 (A+)</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Grades -->
        <div id="grades" class="section-page">
            <div class="page-title">Enter Grades</div>
            <div class="card">
                <div style="margin-bottom: 16px; display: flex; gap: 12px;">
                    <select class="field-input">
                        <option>Grade 11A - Mathematics</option>
                        <option>Grade 11B - Mathematics</option>
                        <option>Grade 12A - Mathematics</option>
                    </select>
                    <select class="field-input">
                        <option>Mid-Term Exam</option>
                        <option>Final Exam</option>
                        <option>Quiz</option>
                    </select>
                </div>
                <table>
                    <thead><tr><th>Student</th><th>Score (0-100)</th><th>Continuous (0-20)</th><th>Actions</th></tr></thead>
                    <tbody>
                        <tr><td>Ayana Tadesse</td><td><input type="number" class="field-input" value="85" style="width: 80px;"></td><td><input type="number" class="field-input" value="18" style="width: 80px;"></td><td><button class="btn-primary">Save</button></td></tr>
                        <tr><td>Biruk Alemu</td><td><input type="number" class="field-input" value="72" style="width: 80px;"></td><td><input type="number" class="field-input" value="15" style="width: 80px;"></td><td><button class="btn-primary">Save</button></td></tr>
                        <tr><td>Chaltu Haile</td><td><input type="number" class="field-input" value="78" style="width: 80px;"></td><td><input type="number" class="field-input" value="16" style="width: 80px;"></td><td><button class="btn-primary">Save</button></td></tr>
                    </tbody>
                </table>
                <div style="margin-top: 16px;"><button class="btn-primary">Save All Grades</button></div>
            </div>
        </div>
        
        <!-- Attendance -->
        <div id="attendance" class="section-page">
            <div class="page-title">Mark Attendance</div>
            <div class="card">
                <div style="margin-bottom: 16px; display: flex; gap: 12px;">
                    <select class="field-input">
                        <option>Grade 11A - Mathematics</option>
                        <option>Grade 11B - Mathematics</option>
                        <option>Grade 12A - Mathematics</option>
                    </select>
                    <input type="date" class="field-input" value="<?php echo date('Y-m-d'); ?>">
                </div>
                <table>
                    <thead><tr><th>Student</th><th>Status</th><th>Note</th></tr></thead>
                    <tbody>
                        <tr><td>Ayana Tadesse</td><td><select class="field-input"><option>Present</option><option>Absent</option><option>Late</option></select></td><td><input type="text" class="field-input" placeholder="Optional note"></td></tr>
                        <tr><td>Biruk Alemu</td><td><select class="field-input"><option>Present</option><option>Absent</option><option>Late</option></select></td><td><input type="text" class="field-input" placeholder="Optional note"></td></tr>
                        <tr><td>Chaltu Haile</td><td><select class="field-input"><option>Present</option><option>Absent</option><option>Late</option></select></td><td><input type="text" class="field-input" placeholder="Optional note"></td></tr>
                    </tbody>
                </table>
                <div style="margin-top: 16px;"><button class="btn-primary">Submit Attendance</button></div>
            </div>
        </div>
        
        <!-- Schedule -->
        <div id="schedule" class="section-page">
            <div class="page-title">My Schedule</div>
            <div class="card">
                <table>
                    <thead><tr><th>Time</th><th>Monday</th><th>Tuesday</th><th>Wednesday</th><th>Thursday</th><th>Friday</th></tr></thead>
                    <tbody>
                        <tr><td>8:00 - 9:00</td><td>11A Math</td><td>-</td><td>11B Math</td><td>11A Math</td><td>-</td></tr>
                        <tr><td>9:00 - 10:00</td><td>-</td><td>12A Math</td><td>11A Math</td><td>-</td><td>12A Math</td></tr>
                        <tr><td>10:20 - 11:20</td><td>12B Math</td><td>11B Math</td><td>-</td><td>12B Math</td><td>11A Math</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        function showPage(pageId) {
            document.querySelectorAll('.section-page').forEach(p => p.classList.remove('active'));
            document.getElementById(pageId).classList.add('active');
            document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
            event.target.closest('.sidebar-link').classList.add('active');
        }
        
        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                window.location.href = 'logout.php';
            }
        }
    </script>
</body>
</html>