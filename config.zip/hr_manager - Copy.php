<?php
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hr_manager') {
    header('Location: index.php');
    exit;
}

$full_name = $_SESSION['full_name'] ?? 'HR Manager';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HR Manager Dashboard - BOLE GENERAL SECONDARY SCHOOL</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'DM Sans', sans-serif; background: #f8f6f1; }
        
        .topbar {
            background: linear-gradient(135deg, #1a3d2b 0%, #0f2318 100%);
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
            color: white;
        }
        
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, #1e4535 0%, #162e24 100%);
            position: fixed;
            left: 0;
            top: 60px;
            height: calc(100vh - 60px);
            padding: 20px 0;
            overflow-y: auto;
        }
        
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: rgba(255,255,255,0.7);
            cursor: pointer;
            transition: 0.2s;
        }
        
        .sidebar-link:hover { background: rgba(255,255,255,0.1); color: white; }
        .sidebar-link.active { background: rgba(82,183,136,0.2); color: white; border-left: 3px solid #52b788; }
        
        .main-content {
            margin-left: 260px;
            padding: 28px 32px;
        }
        
        .page-title {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 24px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            border-top: 3px solid #52b788;
        }
        
        .stat-value { font-size: 32px; font-weight: 700; margin: 8px 0; }
        .stat-label { color: #8a9bb0; font-size: 12px; text-transform: uppercase; }
        
        .card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
        }
        
        .section-page { display: none; }
        .section-page.active { display: block; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f6f1; }
        
        .btn-primary {
            background: linear-gradient(135deg, #2d6a4f, #1a3d2b);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
        }
        
        .logout-btn {
            position: absolute;
            bottom: 20px;
            left: 20px;
            right: 20px;
            background: rgba(255,255,255,0.1);
            border: none;
            padding: 10px;
            color: white;
            border-radius: 8px;
            cursor: pointer;
        }
        
        .toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #1a3d2b;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div class="topbar">
        <div style="display: flex; align-items: center; gap: 16px;">
            <div style="width: 38px; height: 38px; background: linear-gradient(135deg, #c9a84c, #e6c96e); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold;">BGSS</div>
            <div>
                <div style="font-weight: 600;">BOLE GENERAL SECONDARY SCHOOL</div>
                <div style="font-size: 11px; opacity: 0.7;">HR Management System</div>
            </div>
        </div>
        <div>👥 <?php echo htmlspecialchars($full_name); ?></div>
    </div>
    
    <div class="sidebar">
        <div class="sidebar-link active" onclick="showPage('dashboard')">📊 Dashboard</div>
        <div class="sidebar-link" onclick="showPage('employees')">👥 Employee Management</div>
        <div class="sidebar-link" onclick="showPage('attendance')">✅ Staff Attendance</div>
        <div class="sidebar-link" onclick="showPage('leave')">🏖️ Leave Management</div>
        <div class="sidebar-link" onclick="showPage('payroll')">💰 Payroll</div>
        <div class="sidebar-link" onclick="showPage('recruitment')">📋 Recruitment</div>
        <div class="sidebar-link" onclick="showPage('training')">📚 Training</div>
        <button class="logout-btn" onclick="logout()">🚪 Sign Out</button>
    </div>
    
    <div class="main-content">
        <div id="dashboard" class="section-page active">
            <div class="page-title">HR Dashboard</div>
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-label">Total Employees</div><div class="stat-value">68</div></div>
                <div class="stat-card"><div class="stat-label">Teachers</div><div class="stat-value">54</div></div>
                <div class="stat-card"><div class="stat-label">Admin Staff</div><div class="stat-value">14</div></div>
                <div class="stat-card"><div class="stat-label">On Leave</div><div class="stat-value">3</div></div>
            </div>
            <div class="card">
                <h3>📋 Recent HR Activities</h3>
                <div style="padding: 12px 0; border-bottom: 1px solid #eee;">✓ New teacher hired: Girma Seleshi (English)</div>
                <div style="padding: 12px 0; border-bottom: 1px solid #eee;">✓ Leave approved: Hana Tesfaye (5 days)</div>
                <div style="padding: 12px 0;">✓ Payroll processed for November</div>
            </div>
        </div>
        
        <div id="employees" class="section-page">
            <div class="page-title">Employee Management</div>
            <div class="card">
                <button class="btn-primary" onclick="showToast('Add employee form coming soon')">+ Add New Employee</button>
                <div style="margin-top: 20px;">
                    <table>
                        <thead><tr><th>ID</th><th>Name</th><th>Position</th><th>Department</th><th>Status</th></tr></thead>
                        <tbody>
                            <tr><td>TCH-001</td><td>Kebede Mamo</td><td>Senior Teacher</td><td>Mathematics</td><td>Active</td></tr>
                            <tr><td>TCH-002</td><td>Tigist Abebe</td><td>Senior Teacher</td><td>Biology</td><td>Active</td></tr>
                            <tr><td>TCH-003</td><td>Yonas Bekele</td><td>Teacher</td><td>Physics</td><td>Active</td></tr>
                            <tr><td>ADM-001</td><td>Berhanu Desta</td><td>HR Manager</td><td>Administration</td><td>Active</td></tr>
                            <tr><td>ADM-002</td><td>Meseret Getachew</td><td>Finance Officer</td><td>Finance</td><td>Active</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div id="attendance" class="section-page">
            <div class="page-title">Staff Attendance</div>
            <div class="card">
                <div class="stats-grid" style="grid-template-columns: repeat(3, 1fr);">
                    <div class="stat-card"><div class="stat-label">Present Today</div><div class="stat-value">62</div></div>
                    <div class="stat-card"><div class="stat-label">Absent</div><div class="stat-value">6</div></div>
                    <div class="stat-card"><div class="stat-label">Attendance Rate</div><div class="stat-value">91%</div></div>
                </div>
                <button class="btn-primary" onclick="showToast('Mark attendance feature coming soon')">Mark Today's Attendance</button>
            </div>
        </div>
        
        <div id="leave" class="section-page">
            <div class="page-title">Leave Management</div>
            <div class="card">
                <h3>Pending Leave Requests</h3>
                <table>
                    <thead><tr><th>Employee</th><th>Leave Type</th><th>Days</th><th>Status</th><th>Action</th></tr></thead>
                    <tbody>
                        <tr><td>Girma Seleshi</td><td>Annual</td><td>5</td><td>Pending</td><td><button class="btn-primary" style="padding: 4px 12px;">Approve</button></td></tr>
                        <tr><td>Sara Hailu</td><td>Sick</td><td>2</td><td>Pending</td><td><button class="btn-primary" style="padding: 4px 12px;">Approve</button></td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div id="payroll" class="section-page">
            <div class="page-title">Payroll Management</div>
            <div class="card">
                <button class="btn-primary" onclick="showToast('Process payroll coming soon')">Process November Payroll</button>
                <button class="btn-primary" style="margin-left: 12px;" onclick="showToast('Downloading...')">Export Payroll Report</button>
            </div>
        </div>
        
        <div id="recruitment" class="section-page">
            <div class="page-title">Recruitment</div>
            <div class="card">
                <h3>Open Positions</h3>
                <table>
                    <thead><tr><th>Position</th><th>Department</th><th>Posted Date</th><th>Applications</th></tr></thead>
                    <tbody>
                        <tr><td>Physics Teacher</td><td>Science</td><td>Nov 15, 2024</td><td>12</td></tr>
                        <tr><td>IT Specialist</td><td>Technology</td><td>Nov 10, 2024</td><td>8</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div id="training" class="section-page">
            <div class="page-title">Training & Development</div>
            <div class="card">
                <h3>Upcoming Training Programs</h3>
                <div style="padding: 12px; background: #e8f5ee; border-radius: 8px; margin-top: 12px;">
                    <strong>📚 Digital Teaching Skills Workshop</strong><br>
                    Date: December 5-6, 2024 | Venue: Computer Lab
                </div>
                <div style="padding: 12px; background: #e8f5ee; border-radius: 8px; margin-top: 12px;">
                    <strong>📋 Leadership Development Program</strong><br>
                    Date: December 12-13, 2024 | Venue: Conference Hall
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function showPage(pageId) {
            document.querySelectorAll('.section-page').forEach(p => p.classList.remove('active'));
            document.getElementById(pageId).classList.add('active');
            document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
            event.target.closest('.sidebar-link').classList.add('active');
        }
        
        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                window.location.href = 'logout.php';
            }
        }
        
        function showToast(message) {
            const toast = document.createElement('div');
            toast.className = 'toast';
            toast.textContent = message;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 3000);
        }
    </script>
</body>
</html>