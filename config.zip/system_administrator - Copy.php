<?php
session_start();

// ========================================
// CHECK LOGIN & ROLE
// ========================================
if (
    !isset($_SESSION['user_id']) ||
    $_SESSION['role'] != 'system_administrator'
) {
    header("Location: index.php");
    exit;
}

// ========================================
// USER DATA
// ========================================
$full_name = $_SESSION['full_name'] ?? 'system_administrator';
$username  = $_SESSION['username'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>System Administrator Dashboard</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:#f4f7fb;
    display:flex;
    min-height:100vh;
}

/* =========================
   SIDEBAR
========================= */

.sidebar{
    width:260px;
    background:linear-gradient(180deg,#062d1d,#04160e);
    color:#fff;
    padding:25px 20px;
    position:fixed;
    top:0;
    left:0;
    bottom:0;
    overflow-y:auto;
}

.logo{
    text-align:center;
    margin-bottom:35px;
}

.logo-circle{
    width:80px;
    height:80px;
    margin:auto;
    border-radius:50%;
    background:linear-gradient(135deg,#d4af37,#f4d76b);
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:28px;
    font-weight:700;
    color:#083524;
    margin-bottom:12px;
}

.logo h2{
    font-size:18px;
    line-height:1.4;
}

.menu{
    margin-top:20px;
}

.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    text-decoration:none;
    color:#d8e4dd;
    padding:14px 15px;
    border-radius:12px;
    margin-bottom:12px;
    transition:.3s;
    font-size:15px;
}

.menu a:hover,
.menu a.active{
    background:#0d4d33;
    color:#fff;
    transform:translateX(4px);
}

/* =========================
   MAIN CONTENT
========================= */

.main-content{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:30px;
}

/* TOPBAR */

.topbar{
    background:#fff;
    padding:18px 25px;
    border-radius:18px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 4px 20px rgba(0,0,0,0.05);
    margin-bottom:25px;
}

.topbar h1{
    font-size:24px;
    color:#083524;
}

.user-box{
    display:flex;
    align-items:center;
    gap:12px;
}

.user-avatar{
    width:45px;
    height:45px;
    border-radius:50%;
    background:#083524;
    color:#fff;
    display:flex;
    align-items:center;
    justify-content:center;
    font-weight:600;
}

/* =========================
   DASHBOARD CARDS
========================= */

.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(230px,1fr));
    gap:20px;
    margin-bottom:30px;
}

.card{
    background:#fff;
    padding:25px;
    border-radius:18px;
    box-shadow:0 4px 20px rgba(0,0,0,0.05);
    transition:.3s;
}

.card:hover{
    transform:translateY(-5px);
}

.card .icon{
    font-size:40px;
    margin-bottom:15px;
}

.card h3{
    font-size:28px;
    color:#083524;
    margin-bottom:5px;
}

.card p{
    color:#666;
}

/* =========================
   TABLE
========================= */

.table-container{
    background:#fff;
    border-radius:18px;
    padding:25px;
    box-shadow:0 4px 20px rgba(0,0,0,0.05);
}

.table-title{
    margin-bottom:20px;
    font-size:20px;
    color:#083524;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#083524;
    color:#fff;
    padding:14px;
    text-align:left;
}

table td{
    padding:14px;
    border-bottom:1px solid #eee;
}

.status{
    padding:6px 12px;
    border-radius:30px;
    font-size:12px;
    font-weight:600;
}

.active{
    background:#d4f8df;
    color:#167c3a;
}

/* =========================
   RESPONSIVE
========================= */

@media(max-width:900px){

    .sidebar{
        width:100%;
        position:relative;
        height:auto;
    }

    .main-content{
        margin-left:0;
        width:100%;
    }

    body{
        flex-direction:column;
    }
}

</style>

</head>

<body>

<!-- =========================
     SIDEBAR
========================= -->

<div class="sidebar">

    <div class="logo">

        <div class="logo-circle">
            BGSS
        </div>

        <h2>
            School Management System
        </h2>

    </div>

    <div class="menu">

        <a href="#" class="active">
            📊 Dashboard
        </a>

        <a href="#">
            👥 Manage Users
        </a>

        <a href="#">
            🏫 Manage Classes
        </a>

        <a href="#">
            📚 Subjects
        </a>

        <a href="#">
            💰 Finance
        </a>

        <a href="#">
            ⚙️ Settings
        </a>

        <a href="logout.php">
            🚪 Logout
        </a>

    </div>

</div>

<!-- =========================
     MAIN CONTENT
========================= -->

<div class="main-content">

    <!-- TOPBAR -->
    <div class="topbar">

        <h1>
            Welcome, System Administrator
        </h1>

        <div class="user-box">

            <div>
                <strong><?php echo htmlspecialchars($full_name); ?></strong><br>
                <small>@<?php echo htmlspecialchars($username); ?></small>
            </div>

            <div class="user-avatar">
                <?php echo strtoupper(substr($full_name,0,1)); ?>
            </div>

        </div>

    </div>

    <!-- DASHBOARD CARDS -->
    <div class="cards">

        <div class="card">
            <div class="icon">👨‍🎓</div>
            <h3>1,250</h3>
            <p>Total Students</p>
        </div>

        <div class="card">
            <div class="icon">👩‍🏫</div>
            <h3>85</h3>
            <p>Total Teachers</p>
        </div>

        <div class="card">
            <div class="icon">🏫</div>
            <h3>32</h3>
            <p>Total Classes</p>
        </div>

        <div class="card">
            <div class="icon">💻</div>
            <h3>12</h3>
            <p>System Users</p>
        </div>

    </div>

    <!-- RECENT USERS TABLE -->
    <div class="table-container">

        <h2 class="table-title">
            Recent System Users
        </h2>

        <table>

            <thead>

                <tr>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Status</th>
                </tr>

            </thead>

            <tbody>

                <tr>
                    <td>admin</td>
                    <td>Director</td>
                    <td>
                        <span class="status active">
                            Active
                        </span>
                    </td>
                </tr>

                <tr>
                    <td>teacher1</td>
                    <td>Teacher</td>
                    <td>
                        <span class="status active">
                            Active
                        </span>
                    </td>
                </tr>

                <tr>
                    <td>finance1</td>
                    <td>Finance</td>
                    <td>
                        <span class="status active">
                            Active
                        </span>
                    </td>
                </tr>

                <tr>
                    <td>sysadmin1</td>
                    <td>System Administrator</td>
                    <td>
                        <span class="status active">
                            Active
                        </span>
                    </td>
                </tr>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>