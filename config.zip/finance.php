<?php
require_once 'config.php';

// Auth check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'finance') {
    header('Location: index.php');
    exit;
}

$finance_user = $_SESSION['full_name'];
$user_data = $_SESSION['user_data'] ?? [];
$position = $user_data['position'] ?? 'Finance Officer';

// ─── AJAX HANDLERS ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';

    // ── Dashboard summary ──
    if ($action === 'get_summary') {
        $total_fees   = $pdo->query("SELECT COALESCE(SUM(total_fees),0) FROM fee_records")->fetchColumn();
        $total_paid   = $pdo->query("SELECT COALESCE(SUM(amount_paid),0) FROM fee_records")->fetchColumn();
        $total_pending = $total_fees - $total_paid;
        $paid_count   = $pdo->query("SELECT COUNT(*) FROM fee_records WHERE status='paid'")->fetchColumn();
        $partial_count= $pdo->query("SELECT COUNT(*) FROM fee_records WHERE status='partial'")->fetchColumn();
        $pending_count= $pdo->query("SELECT COUNT(*) FROM fee_records WHERE status='pending'")->fetchColumn();
        $total_expenses = $pdo->query("SELECT COALESCE(SUM(amount),0) FROM expenses")->fetchColumn();
        $total_salary   = $pdo->query("SELECT COALESCE(SUM(net_salary),0) FROM payroll WHERE status='paid'")->fetchColumn();
        echo json_encode([
            'total_fees'     => $total_fees,
            'total_paid'     => $total_paid,
            'total_pending'  => $total_pending,
            'paid_count'     => $paid_count,
            'partial_count'  => $partial_count,
            'pending_count'  => $pending_count,
            'total_expenses' => $total_expenses,
            'total_salary'   => $total_salary,
        ]);
        exit;
    }

    // ── Fee Records ──
    if ($action === 'get_fee_records') {
        $status = $_POST['status'] ?? '';
        $sql = "SELECT fr.*, s.full_name, s.student_id FROM fee_records fr 
                JOIN students s ON fr.student_id = s.id";
        if ($status) $sql .= " WHERE fr.status = " . $pdo->quote($status);
        $sql .= " ORDER BY fr.id DESC";
        $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rows);
        exit;
    }

    // ── Fee Payments ──
    if ($action === 'get_fee_payments') {
        $rows = $pdo->query("SELECT fp.*, s.full_name, s.student_id 
                             FROM fee_payments fp 
                             JOIN students s ON fp.student_id = s.id 
                             ORDER BY fp.payment_date DESC")->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rows);
        exit;
    }

    // ── Record Payment ──
    if ($action === 'record_payment') {
        $student_id = intval($_POST['student_id']);
        $amount     = floatval($_POST['amount']);
        $method     = $_POST['method'] ?? 'cash';
        $remarks    = $_POST['remarks'] ?? '';
        $receipt_no = 'RCP-' . strtoupper(uniqid());
        $date       = date('Y-m-d');

        $pdo->prepare("INSERT INTO fee_payments (student_id,amount,payment_date,payment_method,receipt_no,remarks,recorded_by) 
                       VALUES (?,?,?,?,?,?,?)")
            ->execute([$student_id, $amount, $date, $method, $receipt_no, $remarks, $_SESSION['user_id']]);

        // Update fee_records
        $rec = $pdo->prepare("SELECT * FROM fee_records WHERE student_id=? AND academic_year='2024/2025'");
        $rec->execute([$student_id]);
        $fee = $rec->fetch();
        if ($fee) {
            $new_paid = $fee['amount_paid'] + $amount;
            $new_status = $new_paid >= $fee['total_fees'] ? 'paid' : 'partial';
            $pdo->prepare("UPDATE fee_records SET amount_paid=?, status=?, payment_date=? WHERE id=?")
                ->execute([$new_paid, $new_status, $date, $fee['id']]);
        }
        echo json_encode(['success' => true, 'receipt_no' => $receipt_no]);
        exit;
    }

    // ── Get Students (for payment form) ──
    if ($action === 'get_students') {
        $rows = $pdo->query("SELECT s.id, s.student_id, s.full_name, 
                             COALESCE(fr.total_fees,1500) as total_fees,
                             COALESCE(fr.amount_paid,0) as amount_paid,
                             COALESCE(fr.status,'pending') as fee_status
                             FROM students s
                             LEFT JOIN fee_records fr ON s.id=fr.student_id AND fr.academic_year='2024/2025'
                             WHERE s.status='active'
                             ORDER BY s.full_name")->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rows);
        exit;
    }

    // ── Expenses ──
    if ($action === 'get_expenses') {
        try {
            $rows = $pdo->query("SELECT * FROM expenses ORDER BY expense_date DESC")->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($rows);
        } catch (Exception $e) {
            echo json_encode([]);
        }
        exit;
    }

    if ($action === 'add_expense') {
        try {
            $pdo->prepare("INSERT INTO expenses (title,category,amount,expense_date,description,recorded_by) VALUES (?,?,?,?,?,?)")
                ->execute([$_POST['title'], $_POST['category'], floatval($_POST['amount']), $_POST['expense_date'], $_POST['description'] ?? '', $_SESSION['user_id']]);
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            // Create table if not exists
            $pdo->exec("CREATE TABLE IF NOT EXISTS expenses (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(200) NOT NULL,
                category VARCHAR(100) DEFAULT 'General',
                amount DECIMAL(10,2) NOT NULL,
                expense_date DATE NOT NULL,
                description TEXT,
                recorded_by INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
            $pdo->prepare("INSERT INTO expenses (title,category,amount,expense_date,description,recorded_by) VALUES (?,?,?,?,?,?)")
                ->execute([$_POST['title'], $_POST['category'], floatval($_POST['amount']), $_POST['expense_date'], $_POST['description'] ?? '', $_SESSION['user_id']]);
            echo json_encode(['success' => true]);
        }
        exit;
    }

    // ── Payroll ──
    if ($action === 'get_payroll') {
        try {
            $rows = $pdo->query("SELECT p.*, t.full_name, t.teacher_id FROM payroll p 
                                 JOIN teachers t ON p.teacher_id = t.id 
                                 ORDER BY p.pay_month DESC")->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($rows);
        } catch (Exception $e) {
            echo json_encode([]);
        }
        exit;
    }

    if ($action === 'process_payroll') {
        try {
            $teacher_id = intval($_POST['teacher_id']);
            $gross = floatval($_POST['gross_salary']);
            $tax = $gross * 0.15;
            $pension = $gross * 0.07;
            $net = $gross - $tax - $pension;
            $month = $_POST['pay_month'];

            $pdo->prepare("INSERT INTO payroll (teacher_id, gross_salary, tax_deduction, pension_deduction, net_salary, pay_month, status, recorded_by) 
                           VALUES (?,?,?,?,?,?,'pending',?)")
                ->execute([$teacher_id, $gross, $tax, $pension, $net, $month, $_SESSION['user_id']]);
            echo json_encode(['success' => true, 'net' => $net]);
        } catch (Exception $e) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS payroll (
                id INT AUTO_INCREMENT PRIMARY KEY,
                teacher_id INT NOT NULL,
                gross_salary DECIMAL(10,2) NOT NULL,
                tax_deduction DECIMAL(10,2) DEFAULT 0,
                pension_deduction DECIMAL(10,2) DEFAULT 0,
                net_salary DECIMAL(10,2) NOT NULL,
                pay_month VARCHAR(20) NOT NULL,
                status ENUM('pending','paid') DEFAULT 'pending',
                recorded_by INT,
                paid_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
            $teacher_id = intval($_POST['teacher_id']);
            $gross = floatval($_POST['gross_salary']);
            $tax = $gross * 0.15; $pension = $gross * 0.07; $net = $gross - $tax - $pension;
            $pdo->prepare("INSERT INTO payroll (teacher_id,gross_salary,tax_deduction,pension_deduction,net_salary,pay_month,status,recorded_by) VALUES (?,?,?,?,?,?,'pending',?)")
                ->execute([$teacher_id, $gross, $tax, $pension, $net, $_POST['pay_month'], $_SESSION['user_id']]);
            echo json_encode(['success' => true, 'net' => $net]);
        }
        exit;
    }

    if ($action === 'mark_salary_paid') {
        $pdo->prepare("UPDATE payroll SET status='paid', paid_at=NOW() WHERE id=?")
            ->execute([intval($_POST['payroll_id'])]);
        echo json_encode(['success' => true]);
        exit;
    }

    // ── Get Teachers ──
    if ($action === 'get_teachers') {
        $rows = $pdo->query("SELECT id, teacher_id, full_name, subject_name FROM teachers WHERE status='active' ORDER BY full_name")->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($rows);
        exit;
    }

    // ── Reports ──
    if ($action === 'get_report') {
        $monthly = $pdo->query("SELECT DATE_FORMAT(payment_date,'%Y-%m') as month, SUM(amount) as total 
                                FROM fee_payments GROUP BY month ORDER BY month DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
        $by_method = $pdo->query("SELECT payment_method, SUM(amount) as total FROM fee_payments GROUP BY payment_method")->fetchAll(PDO::FETCH_ASSOC);
        try {
            $exp_by_cat = $pdo->query("SELECT category, SUM(amount) as total FROM expenses GROUP BY category")->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) { $exp_by_cat = []; }
        echo json_encode(['monthly' => $monthly, 'by_method' => $by_method, 'exp_by_cat' => $exp_by_cat]);
        exit;
    }

    // ── Logout ──
    if ($action === 'logout') {
        session_destroy();
        echo json_encode(['success' => true]);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Unknown action']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Finance Dashboard — BGSS</title>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
:root {
    --navy:    #0a1628;
    --navy2:   #0f2044;
    --blue:    #1e5fd4;
    --blue2:   #2d7ff9;
    --sky:     #60a5fa;
    --accent:  #38bdf8;
    --gold:    #f59e0b;
    --green:   #10b981;
    --red:     #ef4444;
    --orange:  #f97316;
    --white:   #ffffff;
    --gray1:   #f0f4ff;
    --gray2:   #e2eaf8;
    --gray3:   #94a3b8;
    --gray4:   #475569;
    --text:    #0f172a;
    --sidebar-w: 240px;
}
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:'Sora',sans-serif;background:var(--gray1);color:var(--text);display:flex;min-height:100vh;overflow-x:hidden;}

/* ── SIDEBAR ── */
.sidebar{
    width:var(--sidebar-w);min-width:var(--sidebar-w);
    background:linear-gradient(180deg,var(--navy) 0%,var(--navy2) 100%);
    display:flex;flex-direction:column;position:fixed;top:0;left:0;height:100vh;z-index:100;
    box-shadow:4px 0 24px rgba(0,0,0,0.3);
}
.sidebar-logo{
    padding:24px 20px 20px;
    border-bottom:1px solid rgba(255,255,255,0.07);
}
.logo-badge{
    width:44px;height:44px;border-radius:12px;
    background:linear-gradient(135deg,var(--blue),var(--accent));
    display:flex;align-items:center;justify-content:center;
    font-size:18px;font-weight:700;color:#fff;margin-bottom:10px;
    box-shadow:0 4px 14px rgba(30,95,212,0.5);
}
.logo-title{font-size:13px;font-weight:700;color:#fff;letter-spacing:0.5px;}
.logo-sub{font-size:10px;color:var(--sky);opacity:0.7;margin-top:2px;}

.nav-section{padding:16px 12px 8px;font-size:9px;font-weight:600;color:rgba(255,255,255,0.3);letter-spacing:1.5px;text-transform:uppercase;}
.nav-item{
    display:flex;align-items:center;gap:12px;
    padding:11px 16px;margin:2px 8px;border-radius:10px;
    cursor:pointer;transition:all 0.2s;
    font-size:13px;font-weight:500;color:rgba(255,255,255,0.6);
}
.nav-item:hover{background:rgba(255,255,255,0.08);color:#fff;}
.nav-item.active{background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;box-shadow:0 4px 12px rgba(30,95,212,0.4);}
.nav-item .ni{font-size:17px;width:20px;text-align:center;}
.nav-badge{margin-left:auto;background:var(--gold);color:#000;font-size:10px;font-weight:700;padding:2px 7px;border-radius:20px;}

.sidebar-user{
    margin-top:auto;padding:16px;border-top:1px solid rgba(255,255,255,0.07);
    display:flex;align-items:center;gap:10px;
}
.user-avatar{
    width:36px;height:36px;border-radius:50%;
    background:linear-gradient(135deg,var(--blue2),var(--accent));
    display:flex;align-items:center;justify-content:center;
    font-size:14px;font-weight:700;color:#fff;flex-shrink:0;
}
.user-info{flex:1;min-width:0;}
.user-name{font-size:12px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.user-role{font-size:10px;color:var(--sky);opacity:0.7;}
.logout-btn{
    width:28px;height:28px;border-radius:8px;border:none;
    background:rgba(255,255,255,0.08);color:rgba(255,255,255,0.5);
    cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;
    transition:all 0.2s;flex-shrink:0;
}
.logout-btn:hover{background:rgba(239,68,68,0.3);color:#fff;}

/* ── MAIN ── */
.main{margin-left:var(--sidebar-w);flex:1;display:flex;flex-direction:column;min-height:100vh;}

.topbar{
    background:#fff;padding:0 28px;height:64px;
    display:flex;align-items:center;justify-content:space-between;
    border-bottom:1px solid var(--gray2);
    position:sticky;top:0;z-index:50;
    box-shadow:0 1px 8px rgba(0,0,0,0.06);
}
.topbar-left h1{font-size:18px;font-weight:700;color:var(--navy);}
.topbar-left p{font-size:12px;color:var(--gray3);margin-top:1px;}
.topbar-right{display:flex;align-items:center;gap:12px;}
.topbar-date{font-size:12px;color:var(--gray3);font-family:'JetBrains Mono',monospace;}

.content{padding:24px 28px;flex:1;}

/* ── SECTION PAGES ── */
.page{display:none;animation:fadeIn 0.3s ease;}
.page.active{display:block;}
@keyframes fadeIn{from{opacity:0;transform:translateY(8px);}to{opacity:1;transform:translateY(0);}}

/* ── STAT CARDS ── */
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin-bottom:24px;}
.stat-card{
    background:#fff;border-radius:16px;padding:20px;
    box-shadow:0 2px 12px rgba(0,0,0,0.06);
    border:1px solid var(--gray2);
    position:relative;overflow:hidden;
    transition:transform 0.2s,box-shadow 0.2s;
}
.stat-card:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,0.1);}
.stat-card::before{
    content:'';position:absolute;top:0;left:0;right:0;height:3px;
    background:var(--card-color,var(--blue));
}
.stat-icon{
    width:42px;height:42px;border-radius:12px;
    background:var(--card-bg,rgba(30,95,212,0.1));
    display:flex;align-items:center;justify-content:center;
    font-size:20px;margin-bottom:12px;
}
.stat-value{font-size:22px;font-weight:700;color:var(--navy);font-family:'JetBrains Mono',monospace;}
.stat-label{font-size:12px;color:var(--gray3);margin-top:3px;font-weight:500;}
.stat-sub{font-size:11px;color:var(--gray4);margin-top:6px;}
.stat-sub span{font-weight:600;}

/* ── SECTION HEADER ── */
.section-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;}
.section-title{font-size:17px;font-weight:700;color:var(--navy);}
.section-title small{font-size:12px;font-weight:400;color:var(--gray3);margin-left:8px;}

/* ── BUTTONS ── */
.btn{
    padding:9px 18px;border-radius:9px;border:none;cursor:pointer;
    font-family:'Sora',sans-serif;font-size:13px;font-weight:600;
    display:inline-flex;align-items:center;gap:7px;transition:all 0.2s;
}
.btn-primary{background:linear-gradient(135deg,var(--blue),var(--blue2));color:#fff;box-shadow:0 3px 10px rgba(30,95,212,0.35);}
.btn-primary:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(30,95,212,0.45);}
.btn-success{background:linear-gradient(135deg,#059669,var(--green));color:#fff;}
.btn-success:hover{transform:translateY(-1px);}
.btn-outline{background:transparent;border:1.5px solid var(--gray2);color:var(--gray4);}
.btn-outline:hover{border-color:var(--blue);color:var(--blue);}
.btn-sm{padding:6px 12px;font-size:12px;}
.btn-danger{background:linear-gradient(135deg,#dc2626,var(--red));color:#fff;}

/* ── TABLES ── */
.table-wrap{background:#fff;border-radius:14px;border:1px solid var(--gray2);overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,0.05);}
.table-toolbar{padding:14px 18px;border-bottom:1px solid var(--gray2);display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
.search-input{
    padding:8px 14px;border:1.5px solid var(--gray2);border-radius:8px;
    font-family:'Sora',sans-serif;font-size:13px;outline:none;flex:1;min-width:180px;
    transition:border-color 0.2s;
}
.search-input:focus{border-color:var(--blue);}
.filter-select{
    padding:8px 12px;border:1.5px solid var(--gray2);border-radius:8px;
    font-family:'Sora',sans-serif;font-size:13px;outline:none;background:#fff;
    cursor:pointer;transition:border-color 0.2s;
}
.filter-select:focus{border-color:var(--blue);}
table{width:100%;border-collapse:collapse;}
th{padding:11px 16px;text-align:left;font-size:11px;font-weight:600;color:var(--gray3);
   text-transform:uppercase;letter-spacing:0.8px;background:var(--gray1);border-bottom:1px solid var(--gray2);}
td{padding:13px 16px;font-size:13px;border-bottom:1px solid var(--gray2);color:var(--text);}
tr:last-child td{border-bottom:none;}
tr:hover td{background:var(--gray1);}
.mono{font-family:'JetBrains Mono',monospace;font-size:12px;}

/* ── BADGES ── */
.badge{display:inline-flex;align-items:center;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:600;}
.badge-green{background:#d1fae5;color:#065f46;}
.badge-orange{background:#fff7ed;color:#9a3412;}
.badge-red{background:#fee2e2;color:#991b1b;}
.badge-blue{background:#dbeafe;color:#1e40af;}
.badge-gray{background:var(--gray2);color:var(--gray4);}

/* ── MODAL ── */
.modal-overlay{
    position:fixed;inset:0;background:rgba(10,22,40,0.7);
    display:none;align-items:center;justify-content:center;z-index:500;
    backdrop-filter:blur(4px);
}
.modal-overlay.open{display:flex;}
.modal{
    background:#fff;border-radius:18px;padding:28px;width:100%;max-width:480px;
    box-shadow:0 24px 60px rgba(0,0,0,0.3);animation:modalIn 0.3s ease;
    max-height:90vh;overflow-y:auto;
}
@keyframes modalIn{from{opacity:0;transform:scale(0.95);}to{opacity:1;transform:scale(1);}}
.modal-title{font-size:17px;font-weight:700;color:var(--navy);margin-bottom:20px;display:flex;align-items:center;gap:8px;}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.form-group{margin-bottom:16px;}
.form-label{font-size:12px;font-weight:600;color:var(--gray4);margin-bottom:6px;display:block;}
.form-input,.form-select,.form-textarea{
    width:100%;padding:10px 13px;border:1.5px solid var(--gray2);border-radius:9px;
    font-family:'Sora',sans-serif;font-size:13px;outline:none;transition:border-color 0.2s;
}
.form-input:focus,.form-select:focus,.form-textarea:focus{border-color:var(--blue);}
.form-textarea{resize:vertical;min-height:80px;}
.modal-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:8px;}

/* ── CHARTS AREA ── */
.charts-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:24px;}
.chart-card{background:#fff;border-radius:14px;padding:20px;border:1px solid var(--gray2);box-shadow:0 2px 10px rgba(0,0,0,0.05);}
.chart-title{font-size:14px;font-weight:700;color:var(--navy);margin-bottom:16px;}
.chart-canvas-wrap{position:relative;height:200px;}
canvas{max-height:200px;}

/* ── REPORT SUMMARY CARDS ── */
.report-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:20px;}
.report-item{
    background:var(--gray1);border-radius:12px;padding:16px;
    border-left:4px solid var(--card-color,var(--blue));
}
.report-item .ri-val{font-size:20px;font-weight:700;color:var(--navy);font-family:'JetBrains Mono',monospace;}
.report-item .ri-lbl{font-size:11px;color:var(--gray3);margin-top:3px;font-weight:500;}

/* ── TOAST ── */
.toast-wrap{position:fixed;bottom:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px;}
.toast{
    padding:12px 18px;border-radius:10px;color:#fff;font-size:13px;font-weight:500;
    box-shadow:0 4px 16px rgba(0,0,0,0.2);animation:toastIn 0.3s ease;
    display:flex;align-items:center;gap:8px;min-width:220px;
}
.toast.success{background:var(--green);}
.toast.error{background:var(--red);}
@keyframes toastIn{from{transform:translateX(100%);opacity:0;}to{transform:translateX(0);opacity:1;}}

/* ── EMPTY STATE ── */
.empty-state{padding:40px;text-align:center;color:var(--gray3);}
.empty-state .ei{font-size:40px;margin-bottom:10px;}
.empty-state p{font-size:14px;}

/* ── LOADING ── */
.loading{padding:30px;text-align:center;color:var(--gray3);font-size:13px;}

/* ── PAYROLL CALC ── */
.calc-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px dashed var(--gray2);font-size:13px;}
.calc-row:last-child{border-bottom:none;font-weight:700;color:var(--blue);font-size:14px;}

@media(max-width:900px){
    .stats-grid{grid-template-columns:repeat(2,1fr);}
    .charts-grid{grid-template-columns:1fr;}
    .report-grid{grid-template-columns:repeat(2,1fr);}
}
</style>
</head>
<body>

<!-- ═══════════════════════ SIDEBAR ═══════════════════════ -->
<aside class="sidebar">
    <div class="sidebar-logo">
        <div class="logo-badge">💰</div>
        <div class="logo-title">BGSS Finance</div>
        <div class="logo-sub">School Management System</div>
    </div>

    <div class="nav-section">Main Menu</div>
    <div class="nav-item active" onclick="showPage('dashboard',this)">
        <span class="ni">🏠</span> Dashboard
    </div>
    <div class="nav-item" onclick="showPage('fee-collection',this)">
        <span class="ni">💳</span> Fee Collection
    </div>
    <div class="nav-item" onclick="showPage('payments',this)">
        <span class="ni">🧾</span> Payment Records
    </div>

    <div class="nav-section">Management</div>
    <div class="nav-item" onclick="showPage('expenses',this)">
        <span class="ni">📊</span> Expenses
    </div>
    <div class="nav-item" onclick="showPage('payroll',this)">
        <span class="ni">👔</span> Salary & Payroll
    </div>

    <div class="nav-section">Analytics</div>
    <div class="nav-item" onclick="showPage('reports',this)">
        <span class="ni">📈</span> Reports & Charts
    </div>

    <div class="sidebar-user">
        <div class="user-avatar"><?= strtoupper(substr($finance_user,0,1)) ?></div>
        <div class="user-info">
            <div class="user-name"><?= htmlspecialchars($finance_user) ?></div>
            <div class="user-role"><?= htmlspecialchars($position) ?></div>
        </div>
        <button class="logout-btn" onclick="doLogout()" title="Logout">⏻</button>
    </div>
</aside>

<!-- ═══════════════════════ MAIN ═══════════════════════ -->
<div class="main">
    <div class="topbar">
        <div class="topbar-left">
            <h1 id="page-title">Finance Dashboard</h1>
            <p id="page-sub">Overview of school finances</p>
        </div>
        <div class="topbar-right">
            <div class="topbar-date" id="clock"></div>
        </div>
    </div>

    <div class="content">

        <!-- ══ DASHBOARD ══ -->
        <div class="page active" id="page-dashboard">
            <div class="stats-grid" id="stats-grid">
                <div class="stat-card" style="--card-color:var(--blue);--card-bg:rgba(30,95,212,0.08)">
                    <div class="stat-icon">💰</div>
                    <div class="stat-value" id="s-total-fees">—</div>
                    <div class="stat-label">Total Fees (ETB)</div>
                    <div class="stat-sub">Academic Year 2024/2025</div>
                </div>
                <div class="stat-card" style="--card-color:var(--green);--card-bg:rgba(16,185,129,0.08)">
                    <div class="stat-icon">✅</div>
                    <div class="stat-value" id="s-collected">—</div>
                    <div class="stat-label">Total Collected (ETB)</div>
                    <div class="stat-sub"><span id="s-paid-count">—</span> students fully paid</div>
                </div>
                <div class="stat-card" style="--card-color:var(--orange);--card-bg:rgba(249,115,22,0.08)">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-value" id="s-pending">—</div>
                    <div class="stat-label">Outstanding (ETB)</div>
                    <div class="stat-sub"><span id="s-pending-count">—</span> pending · <span id="s-partial-count">—</span> partial</div>
                </div>
                <div class="stat-card" style="--card-color:var(--red);--card-bg:rgba(239,68,68,0.08)">
                    <div class="stat-icon">📉</div>
                    <div class="stat-value" id="s-expenses">—</div>
                    <div class="stat-label">Total Expenses (ETB)</div>
                    <div class="stat-sub">Salary paid: <span id="s-salary">—</span> ETB</div>
                </div>
            </div>

            <!-- Recent Payments -->
            <div class="section-header">
                <div class="section-title">Recent Payments <small>Last 5 transactions</small></div>
                <button class="btn btn-primary btn-sm" onclick="showPage('fee-collection',document.querySelector('[onclick*=fee-collection]'))">+ New Payment</button>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Receipt</th><th>Student</th><th>Amount</th><th>Method</th><th>Date</th><th>Status</th></tr></thead>
                    <tbody id="recent-payments-body"><tr><td colspan="6" class="loading">Loading...</td></tr></tbody>
                </table>
            </div>
        </div>

        <!-- ══ FEE COLLECTION ══ -->
        <div class="page" id="page-fee-collection">
            <div class="section-header">
                <div class="section-title">Fee Collection <small>Student fee status</small></div>
                <div style="display:flex;gap:8px">
                    <select class="filter-select" id="fee-filter" onchange="loadFeeRecords()">
                        <option value="">All Students</option>
                        <option value="pending">Pending</option>
                        <option value="partial">Partial</option>
                        <option value="paid">Paid</option>
                    </select>
                    <button class="btn btn-primary" onclick="openPaymentModal()">💳 Record Payment</button>
                </div>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Student ID</th><th>Name</th><th>Total Fees</th><th>Paid</th><th>Balance</th><th>Status</th><th>Action</th></tr></thead>
                    <tbody id="fee-records-body"><tr><td colspan="7" class="loading">Loading...</td></tr></tbody>
                </table>
            </div>
        </div>

        <!-- ══ PAYMENT RECORDS ══ -->
        <div class="page" id="page-payments">
            <div class="section-header">
                <div class="section-title">Payment Records <small>All transactions</small></div>
                <button class="btn btn-outline btn-sm" onclick="loadPayments()">🔄 Refresh</button>
            </div>
            <div class="table-wrap">
                <div class="table-toolbar">
                    <input class="search-input" id="pay-search" placeholder="🔍 Search by student or receipt..." oninput="filterPayments()">
                </div>
                <table>
                    <thead><tr><th>Receipt No.</th><th>Student</th><th>Amount (ETB)</th><th>Method</th><th>Date</th><th>Remarks</th></tr></thead>
                    <tbody id="payments-body"><tr><td colspan="6" class="loading">Loading...</td></tr></tbody>
                </table>
            </div>
        </div>

        <!-- ══ EXPENSES ══ -->
        <div class="page" id="page-expenses">
            <div class="section-header">
                <div class="section-title">Expense Management</div>
                <button class="btn btn-primary" onclick="openExpenseModal()">➕ Add Expense</button>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Title</th><th>Category</th><th>Amount (ETB)</th><th>Date</th><th>Description</th></tr></thead>
                    <tbody id="expenses-body"><tr><td colspan="5" class="loading">Loading...</td></tr></tbody>
                </table>
            </div>
        </div>

        <!-- ══ PAYROLL ══ -->
        <div class="page" id="page-payroll">
            <div class="section-header">
                <div class="section-title">Salary & Payroll</div>
                <button class="btn btn-primary" onclick="openPayrollModal()">💼 Process Salary</button>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Teacher</th><th>Month</th><th>Gross (ETB)</th><th>Tax (15%)</th><th>Pension (7%)</th><th>Net (ETB)</th><th>Status</th><th>Action</th></tr></thead>
                    <tbody id="payroll-body"><tr><td colspan="8" class="loading">Loading...</td></tr></tbody>
                </table>
            </div>
        </div>

        <!-- ══ REPORTS ══ -->
        <div class="page" id="page-reports">
            <div class="section-header">
                <div class="section-title">Financial Reports & Charts</div>
                <button class="btn btn-outline btn-sm" onclick="loadReports()">🔄 Refresh</button>
            </div>
            <div class="report-grid" id="report-summary"></div>
            <div class="charts-grid">
                <div class="chart-card">
                    <div class="chart-title">📅 Monthly Fee Collection (ETB)</div>
                    <div class="chart-canvas-wrap"><canvas id="monthlyChart"></canvas></div>
                </div>
                <div class="chart-card">
                    <div class="chart-title">💳 Payment Methods</div>
                    <div class="chart-canvas-wrap"><canvas id="methodChart"></canvas></div>
                </div>
                <div class="chart-card">
                    <div class="chart-title">📊 Fee Status Distribution</div>
                    <div class="chart-canvas-wrap"><canvas id="statusChart"></canvas></div>
                </div>
                <div class="chart-card">
                    <div class="chart-title">🏷️ Expenses by Category</div>
                    <div class="chart-canvas-wrap"><canvas id="expChart"></canvas></div>
                </div>
            </div>
        </div>

    </div><!-- /content -->
</div><!-- /main -->

<!-- ═══════════ MODALS ═══════════ -->

<!-- Payment Modal -->
<div class="modal-overlay" id="payment-modal">
<div class="modal">
    <div class="modal-title">💳 Record Fee Payment</div>
    <div class="form-group">
        <label class="form-label">Student</label>
        <select class="form-select" id="pay-student-id">
            <option value="">Select student...</option>
        </select>
    </div>
    <div id="student-fee-info" style="display:none;background:var(--gray1);padding:12px;border-radius:9px;margin-bottom:16px;font-size:13px;"></div>
    <div class="form-row">
        <div class="form-group">
            <label class="form-label">Amount (ETB)</label>
            <input class="form-input" type="number" id="pay-amount" placeholder="0.00" min="1">
        </div>
        <div class="form-group">
            <label class="form-label">Payment Method</label>
            <select class="form-select" id="pay-method">
                <option value="cash">💵 Cash</option>
                <option value="bank_transfer">🏦 Bank Transfer</option>
                <option value="check">📝 Check</option>
                <option value="mobile_money">📱 Mobile Money</option>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label class="form-label">Remarks (optional)</label>
        <textarea class="form-textarea" id="pay-remarks" placeholder="e.g. First installment..."></textarea>
    </div>
    <div class="modal-actions">
        <button class="btn btn-outline" onclick="closeModal('payment-modal')">Cancel</button>
        <button class="btn btn-primary" onclick="submitPayment()">✅ Record Payment</button>
    </div>
</div>
</div>

<!-- Expense Modal -->
<div class="modal-overlay" id="expense-modal">
<div class="modal">
    <div class="modal-title">📊 Add Expense</div>
    <div class="form-group">
        <label class="form-label">Title</label>
        <input class="form-input" id="exp-title" placeholder="e.g. Electricity Bill">
    </div>
    <div class="form-row">
        <div class="form-group">
            <label class="form-label">Category</label>
            <select class="form-select" id="exp-category">
                <option value="Utilities">Utilities</option>
                <option value="Supplies">Supplies</option>
                <option value="Maintenance">Maintenance</option>
                <option value="Transport">Transport</option>
                <option value="Events">Events</option>
                <option value="IT">IT & Technology</option>
                <option value="Other">Other</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Amount (ETB)</label>
            <input class="form-input" type="number" id="exp-amount" placeholder="0.00">
        </div>
    </div>
    <div class="form-group">
        <label class="form-label">Date</label>
        <input class="form-input" type="date" id="exp-date">
    </div>
    <div class="form-group">
        <label class="form-label">Description</label>
        <textarea class="form-textarea" id="exp-desc" placeholder="Details..."></textarea>
    </div>
    <div class="modal-actions">
        <button class="btn btn-outline" onclick="closeModal('expense-modal')">Cancel</button>
        <button class="btn btn-primary" onclick="submitExpense()">➕ Add Expense</button>
    </div>
</div>
</div>

<!-- Payroll Modal -->
<div class="modal-overlay" id="payroll-modal">
<div class="modal">
    <div class="modal-title">💼 Process Salary</div>
    <div class="form-group">
        <label class="form-label">Teacher</label>
        <select class="form-select" id="pr-teacher">
            <option value="">Select teacher...</option>
        </select>
    </div>
    <div class="form-row">
        <div class="form-group">
            <label class="form-label">Gross Salary (ETB)</label>
            <input class="form-input" type="number" id="pr-gross" placeholder="e.g. 8000" oninput="calcPayroll()">
        </div>
        <div class="form-group">
            <label class="form-label">Pay Month</label>
            <input class="form-input" type="month" id="pr-month">
        </div>
    </div>
    <div id="payroll-calc" style="display:none;background:var(--gray1);padding:14px;border-radius:10px;margin-bottom:16px;">
        <div class="calc-row"><span>Gross Salary</span><span id="calc-gross">—</span></div>
        <div class="calc-row"><span>Tax (15%)</span><span id="calc-tax" style="color:var(--red)">—</span></div>
        <div class="calc-row"><span>Pension (7%)</span><span id="calc-pension" style="color:var(--orange)">—</span></div>
        <div class="calc-row"><span>Net Salary</span><span id="calc-net">—</span></div>
    </div>
    <div class="modal-actions">
        <button class="btn btn-outline" onclick="closeModal('payroll-modal')">Cancel</button>
        <button class="btn btn-success" onclick="submitPayroll()">✅ Process</button>
    </div>
</div>
</div>

<!-- Toast Container -->
<div class="toast-wrap" id="toasts"></div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
// ─── UTILITIES ───────────────────────────────────────────────
const fmt = n => 'ETB ' + Number(n||0).toLocaleString('en-ET', {minimumFractionDigits:2, maximumFractionDigits:2});
const fmtDate = d => d ? new Date(d).toLocaleDateString('en-GB') : '—';
function toast(msg, type='success') {
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = (type==='success'?'✅':'❌') + ' ' + msg;
    document.getElementById('toasts').appendChild(el);
    setTimeout(()=>el.remove(), 3500);
}
async function api(data) {
    const fd = new FormData();
    Object.entries(data).forEach(([k,v])=>fd.append(k,v));
    const r = await fetch('finance.php', {method:'POST', headers:{'X-Requested-With':'XMLHttpRequest'}, body:fd});
    return r.json();
}
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
function openModal(id)  { document.getElementById(id).classList.add('open'); }

// Click outside modal closes it
document.querySelectorAll('.modal-overlay').forEach(o=>{
    o.addEventListener('click', e=>{ if(e.target===o) o.classList.remove('open'); });
});

// ─── CLOCK ───────────────────────────────────────────────────
function updateClock() {
    const now = new Date();
    document.getElementById('clock').textContent = now.toLocaleDateString('en-GB',{weekday:'short',day:'2-digit',month:'short',year:'numeric'}) + ' ' + now.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
}
updateClock(); setInterval(updateClock, 1000);

// ─── PAGE NAVIGATION ─────────────────────────────────────────
const pageTitles = {
    'dashboard':      ['Finance Dashboard','Overview of school finances'],
    'fee-collection': ['Fee Collection','Student fee records & status'],
    'payments':       ['Payment Records','All fee transactions'],
    'expenses':       ['Expense Management','Track school expenditures'],
    'payroll':        ['Salary & Payroll','Teacher salary processing'],
    'reports':        ['Reports & Charts','Financial analytics & summaries'],
};
function showPage(id, navEl) {
    document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
    document.getElementById('page-'+id).classList.add('active');
    if(navEl) navEl.classList.add('active');
    const [title, sub] = pageTitles[id] || [id,''];
    document.getElementById('page-title').textContent = title;
    document.getElementById('page-sub').textContent = sub;
    // Lazy load
    if(id==='fee-collection') loadFeeRecords();
    if(id==='payments') loadPayments();
    if(id==='expenses') loadExpenses();
    if(id==='payroll') loadPayroll();
    if(id==='reports') loadReports();
}

// ─── DASHBOARD ───────────────────────────────────────────────
async function loadDashboard() {
    const d = await api({action:'get_summary'});
    document.getElementById('s-total-fees').textContent = fmt(d.total_fees);
    document.getElementById('s-collected').textContent = fmt(d.total_paid);
    document.getElementById('s-pending').textContent = fmt(d.total_pending);
    document.getElementById('s-expenses').textContent = fmt(d.total_expenses);
    document.getElementById('s-paid-count').textContent = d.paid_count;
    document.getElementById('s-pending-count').textContent = d.pending_count;
    document.getElementById('s-partial-count').textContent = d.partial_count;
    document.getElementById('s-salary').textContent = Number(d.total_salary||0).toLocaleString();

    const payments = await api({action:'get_fee_payments'});
    const recent = payments.slice(0,5);
    const tbody = document.getElementById('recent-payments-body');
    if(!recent.length) { tbody.innerHTML='<tr><td colspan="6"><div class="empty-state"><div class="ei">🧾</div><p>No payments yet</p></div></td></tr>'; return; }
    tbody.innerHTML = recent.map(p=>`
        <tr>
            <td class="mono">${p.receipt_no||'—'}</td>
            <td><strong>${p.full_name}</strong><br><span style="font-size:11px;color:var(--gray3)">${p.student_id}</span></td>
            <td class="mono" style="color:var(--green);font-weight:600">${fmt(p.amount)}</td>
            <td>${methodBadge(p.payment_method)}</td>
            <td>${fmtDate(p.payment_date)}</td>
            <td><span class="badge badge-green">Recorded</span></td>
        </tr>`).join('');
}

function methodBadge(m) {
    const map = {cash:'💵 Cash',bank_transfer:'🏦 Bank',check:'📝 Check',mobile_money:'📱 Mobile'};
    return `<span class="badge badge-blue">${map[m]||m}</span>`;
}

// ─── FEE RECORDS ─────────────────────────────────────────────
let feeData = [];
async function loadFeeRecords() {
    const status = document.getElementById('fee-filter').value;
    feeData = await api({action:'get_fee_records', status});
    renderFeeRecords();
}
function renderFeeRecords() {
    const tbody = document.getElementById('fee-records-body');
    if(!feeData.length) { tbody.innerHTML='<tr><td colspan="7"><div class="empty-state"><div class="ei">🎓</div><p>No records found</p></div></td></tr>'; return; }
    tbody.innerHTML = feeData.map(r=>{
        const balance = r.total_fees - r.amount_paid;
        const pct = Math.round((r.amount_paid/r.total_fees)*100);
        const sbadge = r.status==='paid'?'badge-green':r.status==='partial'?'badge-orange':'badge-red';
        return `<tr>
            <td class="mono">${r.student_id}</td>
            <td><strong>${r.full_name}</strong></td>
            <td class="mono">${fmt(r.total_fees)}</td>
            <td class="mono" style="color:var(--green)">${fmt(r.amount_paid)}
                <div style="margin-top:4px;height:4px;background:var(--gray2);border-radius:2px">
                    <div style="width:${pct}%;height:100%;background:var(--green);border-radius:2px"></div>
                </div>
            </td>
            <td class="mono" style="color:${balance>0?'var(--red)':'var(--green)'}">${fmt(balance)}</td>
            <td><span class="badge ${sbadge}">${r.status}</span></td>
            <td><button class="btn btn-primary btn-sm" onclick="openPaymentModalFor(${r.student_id},'${r.full_name}',${balance})">Pay</button></td>
        </tr>`;
    }).join('');
}

// ─── PAYMENTS ────────────────────────────────────────────────
let allPayments = [];
async function loadPayments() {
    allPayments = await api({action:'get_fee_payments'});
    renderPayments(allPayments);
}
function renderPayments(data) {
    const tbody = document.getElementById('payments-body');
    if(!data.length) { tbody.innerHTML='<tr><td colspan="6"><div class="empty-state"><div class="ei">🧾</div><p>No payments found</p></div></td></tr>'; return; }
    tbody.innerHTML = data.map(p=>`
        <tr>
            <td class="mono" style="color:var(--blue);font-weight:600">${p.receipt_no||'—'}</td>
            <td><strong>${p.full_name}</strong><br><span style="font-size:11px;color:var(--gray3)">${p.student_id}</span></td>
            <td class="mono" style="color:var(--green);font-weight:700">${fmt(p.amount)}</td>
            <td>${methodBadge(p.payment_method)}</td>
            <td>${fmtDate(p.payment_date)}</td>
            <td style="font-size:12px;color:var(--gray4)">${p.remarks||'—'}</td>
        </tr>`).join('');
}
function filterPayments() {
    const q = document.getElementById('pay-search').value.toLowerCase();
    renderPayments(allPayments.filter(p=>
        p.full_name.toLowerCase().includes(q) ||
        (p.receipt_no||'').toLowerCase().includes(q) ||
        p.student_id.toLowerCase().includes(q)
    ));
}

// ─── PAYMENT MODAL ───────────────────────────────────────────
let studentsCache = [];
async function openPaymentModal() {
    if(!studentsCache.length) studentsCache = await api({action:'get_students'});
    const sel = document.getElementById('pay-student-id');
    sel.innerHTML = '<option value="">Select student...</option>' +
        studentsCache.map(s=>`<option value="${s.id}" data-total="${s.total_fees}" data-paid="${s.amount_paid}" data-status="${s.fee_status}">${s.full_name} (${s.student_id})</option>`).join('');
    sel.onchange = () => {
        const opt = sel.options[sel.selectedIndex];
        if(!opt.value) { document.getElementById('student-fee-info').style.display='none'; return; }
        const total=opt.dataset.total, paid=opt.dataset.paid, bal=total-paid;
        document.getElementById('student-fee-info').style.display='block';
        document.getElementById('student-fee-info').innerHTML =
            `<strong>${opt.text}</strong><br>
             Total: <strong>${fmt(total)}</strong> | Paid: <strong style="color:var(--green)">${fmt(paid)}</strong> | Balance: <strong style="color:var(--red)">${fmt(bal)}</strong>`;
        document.getElementById('pay-amount').value = bal > 0 ? bal : '';
    };
    document.getElementById('pay-amount').value='';
    document.getElementById('pay-remarks').value='';
    openModal('payment-modal');
}
async function openPaymentModalFor(sid, name, balance) {
    await openPaymentModal();
    const sel = document.getElementById('pay-student-id');
    sel.value = sid; sel.onchange();
}
async function submitPayment() {
    const sid=document.getElementById('pay-student-id').value;
    const amt=document.getElementById('pay-amount').value;
    if(!sid||!amt||amt<=0) { toast('Please fill all required fields','error'); return; }
    const r = await api({action:'record_payment',student_id:sid,amount:amt,
                         method:document.getElementById('pay-method').value,
                         remarks:document.getElementById('pay-remarks').value});
    if(r.success) {
        toast(`Payment recorded! Receipt: ${r.receipt_no}`);
        closeModal('payment-modal');
        studentsCache=[];
        loadDashboard();
        if(document.getElementById('page-fee-collection').classList.contains('active')) loadFeeRecords();
    } else toast(r.message||'Error','error');
}

// ─── EXPENSES ────────────────────────────────────────────────
async function loadExpenses() {
    const data = await api({action:'get_expenses'});
    const tbody = document.getElementById('expenses-body');
    if(!data.length) { tbody.innerHTML='<tr><td colspan="5"><div class="empty-state"><div class="ei">📊</div><p>No expenses recorded yet</p></div></td></tr>'; return; }
    tbody.innerHTML = data.map(e=>`
        <tr>
            <td><strong>${e.title}</strong></td>
            <td><span class="badge badge-blue">${e.category}</span></td>
            <td class="mono" style="color:var(--red);font-weight:600">${fmt(e.amount)}</td>
            <td>${fmtDate(e.expense_date)}</td>
            <td style="font-size:12px;color:var(--gray4)">${e.description||'—'}</td>
        </tr>`).join('');
}
function openExpenseModal() {
    document.getElementById('exp-title').value='';
    document.getElementById('exp-amount').value='';
    document.getElementById('exp-date').value=new Date().toISOString().split('T')[0];
    document.getElementById('exp-desc').value='';
    openModal('expense-modal');
}
async function submitExpense() {
    const title=document.getElementById('exp-title').value;
    const amount=document.getElementById('exp-amount').value;
    const date=document.getElementById('exp-date').value;
    if(!title||!amount||!date) { toast('Please fill all fields','error'); return; }
    const r = await api({action:'add_expense',title,category:document.getElementById('exp-category').value,amount,expense_date:date,description:document.getElementById('exp-desc').value});
    if(r.success) { toast('Expense added!'); closeModal('expense-modal'); loadExpenses(); loadDashboard(); }
    else toast(r.message||'Error','error');
}

// ─── PAYROLL ─────────────────────────────────────────────────
let teachersCache=[];
async function loadPayroll() {
    const data = await api({action:'get_payroll'});
    const tbody = document.getElementById('payroll-body');
    if(!data.length) { tbody.innerHTML='<tr><td colspan="8"><div class="empty-state"><div class="ei">👔</div><p>No payroll records yet</p></div></td></tr>'; return; }
    tbody.innerHTML = data.map(p=>`
        <tr>
            <td><strong>${p.full_name}</strong><br><span style="font-size:11px;color:var(--gray3)">${p.teacher_id}</span></td>
            <td class="mono">${p.pay_month}</td>
            <td class="mono">${fmt(p.gross_salary)}</td>
            <td class="mono" style="color:var(--red)">-${fmt(p.tax_deduction)}</td>
            <td class="mono" style="color:var(--orange)">-${fmt(p.pension_deduction)}</td>
            <td class="mono" style="color:var(--blue);font-weight:700">${fmt(p.net_salary)}</td>
            <td><span class="badge ${p.status==='paid'?'badge-green':'badge-orange'}">${p.status}</span></td>
            <td>${p.status==='pending'?`<button class="btn btn-success btn-sm" onclick="markPaid(${p.id})">Mark Paid</button>`:'<span style="font-size:12px;color:var(--gray3)">✓ Done</span>'}</td>
        </tr>`).join('');
}
async function openPayrollModal() {
    if(!teachersCache.length) teachersCache = await api({action:'get_teachers'});
    document.getElementById('pr-teacher').innerHTML='<option value="">Select teacher...</option>'+
        teachersCache.map(t=>`<option value="${t.id}">${t.full_name} — ${t.subject_name}</option>`).join('');
    document.getElementById('pr-gross').value='';
    document.getElementById('pr-month').value=new Date().toISOString().substr(0,7);
    document.getElementById('payroll-calc').style.display='none';
    openModal('payroll-modal');
}
function calcPayroll() {
    const g=parseFloat(document.getElementById('pr-gross').value)||0;
    if(!g) { document.getElementById('payroll-calc').style.display='none'; return; }
    const tax=g*0.15, pen=g*0.07, net=g-tax-pen;
    document.getElementById('calc-gross').textContent=fmt(g);
    document.getElementById('calc-tax').textContent='-'+fmt(tax);
    document.getElementById('calc-pension').textContent='-'+fmt(pen);
    document.getElementById('calc-net').textContent=fmt(net);
    document.getElementById('payroll-calc').style.display='block';
}
async function submitPayroll() {
    const tid=document.getElementById('pr-teacher').value;
    const gross=document.getElementById('pr-gross').value;
    const month=document.getElementById('pr-month').value;
    if(!tid||!gross||!month) { toast('Please fill all fields','error'); return; }
    const r = await api({action:'process_payroll',teacher_id:tid,gross_salary:gross,pay_month:month});
    if(r.success) { toast(`Salary processed! Net: ${fmt(r.net)}`); closeModal('payroll-modal'); loadPayroll(); }
    else toast(r.message||'Error','error');
}
async function markPaid(id) {
    const r = await api({action:'mark_salary_paid',payroll_id:id});
    if(r.success) { toast('Salary marked as paid!'); loadPayroll(); loadDashboard(); }
}

// ─── REPORTS ─────────────────────────────────────────────────
let charts = {};
async function loadReports() {
    const [summary, report] = await Promise.all([api({action:'get_summary'}), api({action:'get_report'})]);

    // Summary cards
    document.getElementById('report-summary').innerHTML = `
        <div class="report-item" style="--card-color:var(--green)">
            <div class="ri-val">${fmt(summary.total_paid)}</div>
            <div class="ri-lbl">Total Fees Collected</div>
        </div>
        <div class="report-item" style="--card-color:var(--orange)">
            <div class="ri-val">${fmt(summary.total_pending)}</div>
            <div class="ri-lbl">Outstanding Balance</div>
        </div>
        <div class="report-item" style="--card-color:var(--red)">
            <div class="ri-val">${fmt(summary.total_expenses)}</div>
            <div class="ri-lbl">Total Expenses</div>
        </div>`;

    // Destroy old charts
    Object.values(charts).forEach(c=>c.destroy());
    charts={};

    const COLORS = ['#2d7ff9','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4'];

    // Monthly Collection
    if(report.monthly.length) {
        charts.monthly = new Chart(document.getElementById('monthlyChart'), {
            type:'bar',
            data:{
                labels: report.monthly.map(m=>m.month).reverse(),
                datasets:[{label:'ETB Collected', data:report.monthly.map(m=>m.total).reverse(), backgroundColor:'rgba(45,127,249,0.7)', borderColor:'#2d7ff9', borderWidth:2, borderRadius:6}]
            },
            options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{ticks:{callback:v=>'ETB '+Number(v).toLocaleString()}}}}
        });
    }

    // Payment Methods
    if(report.by_method.length) {
        charts.method = new Chart(document.getElementById('methodChart'), {
            type:'doughnut',
            data:{
                labels: report.by_method.map(m=>m.payment_method),
                datasets:[{data:report.by_method.map(m=>m.total), backgroundColor:COLORS, borderWidth:2, borderColor:'#fff'}]
            },
            options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom'}}}
        });
    }

    // Fee Status
    charts.status = new Chart(document.getElementById('statusChart'), {
        type:'pie',
        data:{
            labels:['Paid','Partial','Pending'],
            datasets:[{data:[summary.paid_count,summary.partial_count,summary.pending_count],backgroundColor:['#10b981','#f59e0b','#ef4444'],borderWidth:2,borderColor:'#fff'}]
        },
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom'}}}
    });

    // Expenses by Category
    if(report.exp_by_cat.length) {
        charts.exp = new Chart(document.getElementById('expChart'), {
            type:'bar',
            data:{
                labels:report.exp_by_cat.map(e=>e.category),
                datasets:[{label:'ETB',data:report.exp_by_cat.map(e=>e.total),backgroundColor:'rgba(239,68,68,0.7)',borderColor:'#ef4444',borderWidth:2,borderRadius:6}]
            },
            options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{ticks:{callback:v=>'ETB '+Number(v).toLocaleString()}}}}
        });
    } else {
        document.getElementById('expChart').parentElement.innerHTML='<div class="empty-state"><div class="ei">📊</div><p>No expense data yet</p></div>';
    }
}

// ─── LOGOUT ──────────────────────────────────────────────────
async function doLogout() {
    if(!confirm('Logout from Finance Dashboard?')) return;
    await api({action:'logout'});
    window.location.href='index.php';
}

// ─── INIT ─────────────────────────────────────────────────────
loadDashboard();
</script>
</body>
</html>