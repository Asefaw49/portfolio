<?php
session_start();
require_once 'config.php';

// ========================================
// AJAX LOGIN / LOGOUT
// ========================================
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest'
) {

    header('Content-Type: application/json');

    $action = $_POST['action'] ?? '';

    // ========================================
    // LOGIN
    // ========================================
    if ($action === 'login') {

        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $role     = trim($_POST['role'] ?? '');

        // VALIDATION
        if (empty($username) || empty($password) || empty($role)) {

            echo json_encode([
                'success' => false,
                'message' => 'Please fill all fields'
            ]);
            exit;
        }

        // ========================================
        // FIND USER
        // ========================================
        $stmt = $pdo->prepare("
            SELECT *
            FROM users
            WHERE username = ?
            AND role = ?
            AND status = 'active'
            LIMIT 1
        ");

        $stmt->execute([$username, $role]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // ========================================
        // CHECK PASSWORD
        // ========================================
        $validPassword = false;

        if ($user) {

            // HASHED PASSWORD
            if (password_verify($password, $user['password'])) {

                $validPassword = true;
            }

            // NORMAL PASSWORD
            elseif ($password === $user['password']) {

                $validPassword = true;
            }
        }

        // ========================================
        // LOGIN SUCCESS
        // ========================================
        if ($validPassword) {

            $_SESSION['user_id']   = $user['id'];
            $_SESSION['username']  = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role']      = $user['role'];

            echo json_encode([
                'success' => true,
                'role' => $user['role']
            ]);

        } else {

            echo json_encode([
                'success' => false,
                'message' => 'Invalid username or password'
            ]);
        }

        exit;
    }

    // ========================================
    // LOGOUT
    // ========================================
    if ($action === 'logout') {

        session_destroy();

        echo json_encode([
            'success' => true
        ]);

        exit;
    }

    echo json_encode([
        'success' => false,
        'message' => 'Invalid request'
    ]);

    exit;
}

// ========================================
// AUTO REDIRECT IF LOGGED IN
// ========================================
if (isset($_SESSION['user_id'])) {

    switch ($_SESSION['role']) {

        case 'director':
            header("Location: director.php");
            exit;

        case 'vice_director':
            header("Location: vice_director.php");
            exit;

        case 'hr_manager':
            header("Location: hr_manager.php");
            exit;

        case 'teacher':
            header("Location: teacher.php");
            exit;

        case 'student':
            header("Location: student.php");
            exit;

        case 'parent':
            header("Location: parent.php");
            exit;

        case 'finance':
            header("Location: finance.php");
            exit;

        case 'system_administrator':
            header("Location: system_administrator.php");
            exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>BOLE GENERAL SECONDARY SCHOOL</title>

<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'DM Sans',sans-serif;
    background:linear-gradient(135deg,#062d1d 0%,#041b11 100%);
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
}

.login-container{
    width:100%;
    max-width:760px;
}

.login-card{
    background:#fff;
    border-radius:24px;
    padding:40px;
    box-shadow:0 25px 80px rgba(0,0,0,0.35);
}

.logo{
    width:100px;
    height:100px;
    margin:auto;
    border-radius:50%;
    background:linear-gradient(135deg,#c9a84c,#f5d76e);
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:26px;
    font-weight:700;
    color:#083524;
    margin-bottom:25px;
}

.title{
    text-align:center;
    font-family:'Playfair Display',serif;
    font-size:40px;
    color:#083524;
    font-weight:700;
    line-height:1.2;
}

.sub{
    text-align:center;
    color:#666;
    margin-top:12px;
    font-size:16px;
    margin-bottom:40px;
}

.sign-title{
    text-align:center;
    font-size:18px;
    font-weight:600;
    margin-bottom:25px;
    color:#333;
}

.role-grid{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:16px;
    margin-bottom:35px;
}

.role-btn{
    border:2px solid #dce3ea;
    border-radius:18px;
    padding:22px 10px;
    cursor:pointer;
    transition:.3s;
    background:#fff;
    text-align:center;
}

.role-btn:hover{
    transform:translateY(-3px);
    border-color:#1d6a4b;
    background:#f3fbf6;
}

.role-btn.selected{
    border-color:#1d6a4b;
    background:#edf8f1;
    box-shadow:0 4px 15px rgba(29,106,75,0.2);
}

.role-btn .icon{
    font-size:42px;
    display:block;
    margin-bottom:10px;
}

.role-btn .text{
    font-size:15px;
    font-weight:500;
}

.field-group{
    margin-bottom:20px;
}

.field-label{
    display:block;
    margin-bottom:8px;
    font-size:15px;
    font-weight:600;
}

.field-input{
    width:100%;
    padding:16px;
    border:1.5px solid #d6dde5;
    border-radius:14px;
    font-size:15px;
    outline:none;
    transition:.3s;
}

.field-input:focus{
    border-color:#1d6a4b;
}

.login-btn{
    width:100%;
    padding:16px;
    border:none;
    border-radius:14px;
    background:linear-gradient(135deg,#1d6a4b,#083524);
    color:#fff;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:.3s;
    margin-top:10px;
}

.login-btn:hover{
    transform:translateY(-2px);
}

.footer{
    text-align:center;
    margin-top:25px;
    color:#777;
    font-size:13px;
}

.toast{
    position:fixed;
    bottom:20px;
    right:20px;
    padding:14px 20px;
    border-radius:10px;
    color:#fff;
    background:#083524;
    z-index:999;
}

.toast.error{
    background:#d9534f;
}

@media(max-width:768px){

  .role-grid{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:12px;
    margin-bottom:30px;
}

.role-btn{
    border:1.5px solid #dce3ea;
    border-radius:14px;
    padding:14px 8px;
    cursor:pointer;
    transition:.3s;
    background:#fff;
    text-align:center;
}

.role-btn:hover{
    transform:translateY(-2px);
    border-color:#1d6a4b;
    background:#f3fbf6;
}

.role-btn.selected{
    border-color:#1d6a4b;
    background:#edf8f1;
    box-shadow:0 3px 10px rgba(29,106,75,0.15);
}

.role-btn .icon{
    font-size:26px;
    display:block;
    margin-bottom:6px;
}

.role-btn .text{
    font-size:13px;
    font-weight:500;
}

/* MOBILE */
@media(max-width:768px){

    .role-grid{
        grid-template-columns:repeat(2,1fr);
    }

    .title{
        font-size:30px;
    }

    .role-btn{
        padding:12px 6px;
    }

    .role-btn .icon{
        font-size:22px;
    }

    .role-btn .text{
        font-size:12px;
    }
}

@media(max-width:500px){

    .role-grid{
        grid-template-columns:repeat(2,1fr);
        gap:10px;
    }

    .title{
        font-size:24px;
    }

    .login-card{
        padding:22px;
    }

    .role-btn{
        padding:10px 5px;
    }

    .role-btn .icon{
        font-size:20px;
    }

    .role-btn .text{
        font-size:11px;
    }
}
    .login-card{
        padding:25px;
    }
}

</style>

</head>

<body>

<div class="login-container">

<div class="login-card">

<div class="logo">
    BGSS
</div>

<div class="title">
    BOLE GENERAL SECONDARY SCHOOL
</div>

<div class="sub">
    School Management System
</div>

<div class="sign-title">
    Sign in as
</div>

<!-- ROLES -->
<div class="role-grid">

    <div class="role-btn selected"
         onclick="selectRole(this,'director')">

        <span class="icon">🏛️</span>
        <div class="text">Director</div>
    </div>

    <div class="role-btn"
         onclick="selectRole(this,'vice_director')">

        <span class="icon">👔</span>
        <div class="text">Vice Director</div>
    </div>

    <div class="role-btn"
         onclick="selectRole(this,'hr_manager')">

        <span class="icon">👥</span>
        <div class="text">HR Manager</div>
    </div>

    <div class="role-btn"
         onclick="selectRole(this,'teacher')">

        <span class="icon">👩‍🏫</span>
        <div class="text">Teacher</div>
    </div>

    <div class="role-btn"
         onclick="selectRole(this,'student')">

        <span class="icon">🎓</span>
        <div class="text">Student</div>
    </div>

    <div class="role-btn"
         onclick="selectRole(this,'parent')">

        <span class="icon">👨‍👩‍👧</span>
        <div class="text">Parent</div>
    </div>

    <div class="role-btn"
         onclick="selectRole(this,'finance')">

        <span class="icon">💰</span>
        <div class="text">Finance</div>
    </div>

    <div class="role-btn"
         onclick="selectRole(this,'system_administrator')">

        <span class="icon">🖥️</span>
        <div class="text">System Administrator</div>
    </div>

</div>

<!-- USERNAME -->
<div class="field-group">

<label class="field-label">
    Username
</label>

<input type="text"
       id="login-user"
       class="field-input"
       placeholder="Enter username">

</div>

<!-- PASSWORD -->
<div class="field-group">

<label class="field-label">
    Password
</label>

<input type="password"
       id="login-pass"
       class="field-input"
       placeholder="Enter password">

</div>

<!-- LOGIN BUTTON -->
<button class="login-btn" onclick="doLogin()">
    Sign In →
</button>

<div class="footer">
    Academic Year 2024/2025 · Addis Ababa, Ethiopia
</div>

</div>
</div>

<script>

let currentRole = 'director';

// ========================================
// SELECT ROLE
// ========================================
function selectRole(element, role){

    document.querySelectorAll('.role-btn')
        .forEach(btn => btn.classList.remove('selected'));

    element.classList.add('selected');

    currentRole = role;
}

// ========================================
// LOGIN FUNCTION
// ========================================
async function doLogin(){

    const username =
        document.getElementById('login-user').value.trim();

    const password =
        document.getElementById('login-pass').value.trim();

    if(username === '' || password === ''){

        showToast('Please enter username and password','error');
        return;
    }

    try{

        const formData = new FormData();

        formData.append('action','login');
        formData.append('username',username);
        formData.append('password',password);
        formData.append('role',currentRole);

        const response = await fetch('index.php',{

            method:'POST',
            body:formData,

            headers:{
                'X-Requested-With':'XMLHttpRequest'
            }
        });

        const data = await response.json();

        console.log(data);

        if(data.success){

            showToast('Login successful');

            setTimeout(() => {

                // SYSTEM ADMIN
                if(data.role === 'system_administrator'){

                    window.location.href =
                        'system_administrator.php';

                }else{

                    // OTHER ROLES
                    window.location.href =
                        data.role + '.php';
                }

            },1000);

        }else{

            showToast(data.message,'error');
        }

    }catch(error){

        console.log(error);

        showToast('Login failed','error');
    }
}

// ========================================
// TOAST
// ========================================
function showToast(message,type='success'){

    const toast = document.createElement('div');

    toast.className =
        `toast ${type === 'error' ? 'error' : ''}`;

    toast.innerText = message;

    document.body.appendChild(toast);

    setTimeout(() => {

        toast.remove();

    },3000);
}

</script>

</body>
</html>