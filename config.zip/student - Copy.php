<?php
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: index.php');
    exit;
}

$full_name = $_SESSION['full_name'] ?? 'Student';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Portal - BOLE GENERAL SECONDARY SCHOOL</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'DM Sans', sans-serif; background: #f8f6f1; }
        
        .topbar {
            background: linear-gradient(135deg, #1a3d2b 0%, #0f2318 100%);
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
            color: white;
        }
        
        .sidebar {
            width: 240px;
            background: linear-gradient(180deg, #1e4535 0%, #162e24 100%);
            position: fixed;
            left: 0;
            top: 60px;
            height: calc(100vh - 60px);
            padding: 20px 0;
            overflow-y: auto;
        }
        
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: rgba(255,255,255,0.7);
            cursor: pointer;
            transition: 0.2s;
        }
        
        .sidebar-link:hover { background: rgba(255,255,255,0.1); color: white; }
        .sidebar-link.active { background: rgba(82,183,136,0.2); color: white; }
        
        .main-content {
            margin-left: 240px;
            padding: 28px 32px;
            min-height: calc(100vh - 60px);
        }
        
        .page-title {
            font-family: 'Playfair Display', serif;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 24px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            border-top: 3px solid #52b788;
        }
        
        .stat-value { font-size: 32px; font-weight: 700; margin: 8px 0; }
        .stat-label { color: #8a9bb0; font-size: 12px; text-transform: uppercase; }
        
        .card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
        }
        
        .section-page { display: none; }
        .section-page.active { display: block; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f6f1; }
        
        .chip {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .chip.green { background: #d4edda; color: #1a6b3c; }
        .chip.blue { background: #dbeafe; color: #1e40af; }
        
        .logout-btn {
            position: absolute;
            bottom: 20px;
            left: 20px;
            right: 20px;
            background: rgba(255,255,255,0.1);
            border: none;
            padding: 10px;
            color: white;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.2s;
        }
        
        .logout-btn:hover {
            background: rgba(255,80,80,0.3);
            color: #ff9999;
        }
        
        .logout-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #1a3d2b;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            z-index: 1000;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="topbar">
        <div style="display: flex; align-items: center; gap: 16px;">
            <div style="width: 38px; height: 38px; background: linear-gradient(135deg, #c9a84c, #e6c96e); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold;">BGSS</div>
            <div>
                <div style="font-weight: 600;">BOLE GENERAL SECONDARY SCHOOL</div>
                <div style="font-size: 11px; opacity: 0.7;">Student Portal</div>
            </div>
        </div>
        <div style="display: flex; align-items: center; gap: 16px;">
            <div class="role-badge">🎓 <?php echo htmlspecialchars($full_name); ?></div>
        </div>
    </div>
    
    <div class="sidebar">
        <div class="sidebar-link active" onclick="showPage('dashboard')">🏠 My Dashboard</div>
        <div class="sidebar-link" onclick="showPage('grades')">📝 My Grades</div>
        <div class="sidebar-link" onclick="showPage('attendance')">✅ My Attendance</div>
        <div class="sidebar-link" onclick="showPage('schedule')">📅 My Schedule</div>
        <div class="sidebar-link" onclick="showPage('exams')">📋 Exam Schedule</div>
        <button class="logout-btn" onclick="logout()">🚪 Sign Out</button>
    </div>
    
    <div class="main-content">
        <!-- Dashboard -->
        <div id="dashboard" class="section-page active">
            <div class="page-title">Welcome, <?php echo htmlspecialchars($full_name); ?>!</div>
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-label">Current GPA</div><div class="stat-value">3.8</div></div>
                <div class="stat-card"><div class="stat-label">Attendance Rate</div><div class="stat-value">94%</div></div>
                <div class="stat-card"><div class="stat-label">Upcoming Exams</div><div class="stat-value">3</div></div>
                <div class="stat-card"><div class="stat-label">Class Rank</div><div class="stat-value">#12</div></div>
            </div>
            <div class="card">
                <h3>📢 Recent Announcements</h3>
                <div id="announcements"></div>
            </div>
        </div>
        
        <!-- Grades -->
        <div id="grades" class="section-page">
            <div class="page-title">My Grades</div>
            <div class="card">
                <table>
                    <thead><tr><th>Subject</th><th>Teacher</th><th>Mid-Term</th><th>Final</th><th>Grade</th></tr></thead>
                    <tbody>
                        <tr><td>Mathematics</td><td>Mr. Kebede</td><td>85</td><td>90</td><td><span class="chip green">A</span></td></tr>
                        <tr><td>Biology</td><td>Ms. Tigist</td><td>78</td><td>82</td><td><span class="chip blue">B+</span></td></tr>
                        <tr><td>Physics</td><td>Mr. Yonas</td><td>88</td><td>91</td><td><span class="chip green">A</span></td></tr>
                        <tr><td>English</td><td>Mr. Girma</td><td>92</td><td>95</td><td><span class="chip green">A+</span></td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Attendance -->
        <div id="attendance" class="section-page">
            <div class="page-title">My Attendance</div>
            <div class="card">
                <h3>November 2024</h3>
                <div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 5px; margin-top: 16px;">
                    <?php
                    $days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                    foreach ($days as $day) {
                        echo "<div style='text-align: center; font-weight: 600; padding: 8px;'>$day</div>";
                    }
                    for ($i = 1; $i <= 30; $i++) {
                        $status = in_array($i, [7, 14, 21]) ? 'absent' : 'present';
                        $color = $status === 'present' ? '#d4edda' : '#fde8e8';
                        echo "<div style='text-align: center; padding: 8px; background: $color; border-radius: 8px;'>$i</div>";
                    }
                    ?>
                </div>
                <div style="margin-top: 16px; display: flex; gap: 16px;">
                    <span><span style="display: inline-block; width: 12px; height: 12px; background: #d4edda; border-radius: 3px;"></span> Present (25 days)</span>
                    <span><span style="display: inline-block; width: 12px; height: 12px; background: #fde8e8; border-radius: 3px;"></span> Absent (3 days)</span>
                </div>
            </div>
        </div>
        
        <!-- Schedule -->
        <div id="schedule" class="section-page">
            <div class="page-title">My Class Schedule</div>
            <div class="card">
                <table>
                    <thead><tr><th>Time</th><th>Monday</th><th>Tuesday</th><th>Wednesday</th><th>Thursday</th><th>Friday</th></tr></thead>
                    <tbody>
                        <tr><td>8:00 - 9:00</td><td>Math</td><td>Physics</td><td>English</td><td>Math</td><td>Biology</td></tr>
                        <tr><td>9:00 - 10:00</td><td>English</td><td>Chemistry</td><td>Math</td><td>Physics</td><td>History</td></tr>
                        <tr><td>10:20 - 11:20</td><td>Biology</td><td>History</td><td>Chemistry</td><td>English</td><td>Math</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Exams -->
        <div id="exams" class="section-page">
            <div class="page-title">Exam Schedule</div>
            <div class="card">
                <div style="padding: 12px; border-bottom: 1px solid #eee;"><strong>Mathematics Mid-Term</strong><br>Date: November 18, 2024 | Time: 9:00 AM | Venue: Main Hall</div>
                <div style="padding: 12px; border-bottom: 1px solid #eee;"><strong>Biology Mid-Term</strong><br>Date: November 25, 2024 | Time: 8:00 AM | Venue: Hall B</div>
                <div style="padding: 12px;"><strong>Physics Final</strong><br>Date: December 2, 2024 | Time: 10:00 AM | Venue: Lab A</div>
            </div>
        </div>
    </div>
    
    <script>
        function showPage(pageId) {
            document.querySelectorAll('.section-page').forEach(p => p.classList.remove('active'));
            document.getElementById(pageId).classList.add('active');
            document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
            event.target.closest('.sidebar-link').classList.add('active');
        }
        
        async function logout() {
            if (confirm('Are you sure you want to logout?')) {
                const logoutBtn = document.querySelector('.logout-btn');
                const originalText = logoutBtn.innerHTML;
                
                try {
                    // Disable button and show loading state
                    logoutBtn.innerHTML = '⏳ Logging out...';
                    logoutBtn.disabled = true;
                    
                    // Send logout request
                    const formData = new FormData();
                    formData.append('action', 'logout');
                    
                    const response = await fetch('index.php', {
                        method: 'POST',
                        body: formData,
                        headers: { 'X-Requested-With': 'XMLHttpRequest' }
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        // Redirect to login page
                        window.location.href = 'index.php';
                    } else {
                        // Fallback redirect
                        window.location.href = 'index.php';
                    }
                } catch (error) {
                    console.error('Logout error:', error);
                    // Fallback redirect on error
                    window.location.href = 'index.php';
                }
            }
        }
        
        // Load announcements
        document.getElementById('announcements').innerHTML = `
            <div style="padding: 12px 0; border-bottom: 1px solid #eee;">📢 Grade 11 Exam Schedule Released - Nov 15, 2024</div>
            <div style="padding: 12px 0; border-bottom: 1px solid #eee;">📢 Annual Sports Day - December 5, 2024</div>
            <div style="padding: 12px 0;">📢 Parent-Teacher Meeting - November 22, 2024</div>
        `;
        
        // Prevent accidental logout on page refresh
        window.addEventListener('beforeunload', function(e) {
            // Don't show warning on logout
            return undefined;
        });
    </script>
</body>
</html>