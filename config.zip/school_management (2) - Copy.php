<?php
session_start();
require_once 'config.php';

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
    header('Content-Type: application/json');
    
    $action = $_POST['action'] ?? '';
    
    if ($action === 'login') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? '';
        
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND role = ? AND status = 'active'");
        $stmt->execute([$username, $role]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['user_data'] = json_decode($user['user_data'] ?? '{}', true);
            
            echo json_encode(['success' => true, 'role' => $user['role']]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
        }
        exit;
    }
    
    if ($action === 'logout') {
        session_destroy();
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($action === 'get_stats') {
        $role = $_SESSION['role'] ?? '';
        $data = [];
        
        if ($role === 'director') {
            $stmt = $pdo->query("SELECT COUNT(*) FROM students WHERE status = 'active'");
            $data['total_students'] = $stmt->fetchColumn();
            
            $stmt = $pdo->query("SELECT COUNT(*) FROM teachers WHERE status = 'active'");
            $data['total_teachers'] = $stmt->fetchColumn();
            
            $stmt = $pdo->query("SELECT ROUND(AVG(attendance_rate), 1) FROM students WHERE status = 'active'");
            $data['attendance_rate'] = $stmt->fetchColumn() ?: 92.8;
            
            $stmt = $pdo->query("SELECT ROUND((SUM(amount_paid) / SUM(total_fees)) * 100, 1) FROM fee_records WHERE academic_year = '2024/2025'");
            $data['fee_collection'] = $stmt->fetchColumn() ?: 79;
        }
        
        if ($role === 'student') {
            $student_id = $_SESSION['user_data']['student_id'] ?? 0;
            $stmt = $pdo->prepare("SELECT gpa, attendance_rate, class_rank FROM students WHERE id = ?");
            $stmt->execute([$student_id]);
            $student = $stmt->fetch();
            $data['gpa'] = $student['gpa'] ?? 3.6;
            $data['attendance_rate'] = $student['attendance_rate'] ?? 94;
            
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM exams WHERE grade = (SELECT grade FROM students WHERE id = ?) AND exam_date >= CURDATE()");
            $stmt->execute([$student_id]);
            $data['upcoming_exams'] = $stmt->fetchColumn();
            
            $data['class_rank'] = $student['class_rank'] ?? 12;
        }
        
        if ($role === 'teacher') {
            $teacher_id = $_SESSION['user_data']['teacher_id'] ?? 0;
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM teacher_subjects WHERE teacher_id = ?");
            $stmt->execute([$teacher_id]);
            $data['total_courses'] = $stmt->fetchColumn();
            
            $stmt = $pdo->prepare("SELECT COUNT(DISTINCT student_id) FROM enrollments WHERE teacher_id = ?");
            $stmt->execute([$teacher_id]);
            $data['total_students'] = $stmt->fetchColumn();
            
            $stmt = $pdo->prepare("SELECT ROUND(AVG(attendance_rate), 1) FROM attendance WHERE teacher_id = ? AND date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)");
            $stmt->execute([$teacher_id]);
            $data['attendance_rate'] = $stmt->fetchColumn() ?: 91;
        }
        
        echo json_encode($data);
        exit;
    }
    
    if ($action === 'get_announcements') {
        $limit = intval($_POST['limit'] ?? 5);
        $role = $_SESSION['role'] ?? '';
        
        $sql = "SELECT a.*, u.full_name as author_name 
                FROM announcements a 
                JOIN users u ON a.author_id = u.id 
                WHERE a.status = 'published' 
                AND (a.audience = 'all' OR a.audience = ?)
                ORDER BY a.created_at DESC LIMIT ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$role, $limit]);
        $announcements = $stmt->fetchAll();
        
        echo json_encode($announcements);
        exit;
    }
    
    if ($action === 'post_announcement') {
        if ($_SESSION['role'] !== 'director') {
            echo json_encode(['success' => false, 'message' => 'Permission denied']);
            exit;
        }
        
        $title = $_POST['title'] ?? '';
        $content = $_POST['content'] ?? '';
        $audience = $_POST['audience'] ?? 'all';
        
        if (empty($title) || empty($content)) {
            echo json_encode(['success' => false, 'message' => 'Title and content are required']);
            exit;
        }
        
        $stmt = $pdo->prepare("INSERT INTO announcements (title, content, audience, author_id, status, created_at) VALUES (?, ?, ?, ?, 'published', NOW())");
        $stmt->execute([$title, $content, $audience, $_SESSION['user_id']]);
        
        echo json_encode(['success' => true, 'id' => $pdo->lastInsertId()]);
        exit;
    }
    
    if ($action === 'get_students') {
        $search = $_POST['search'] ?? '';
        $grade = $_POST['grade'] ?? '';
        
        $sql = "SELECT s.*, g.name as grade_name, sec.name as section_name 
                FROM students s
                LEFT JOIN grades g ON s.grade_id = g.id
                LEFT JOIN sections sec ON s.section_id = sec.id
                WHERE s.status = 'active'";
        $params = [];
        
        if (!empty($search)) {
            $sql .= " AND (s.full_name LIKE ? OR s.student_id LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        
        if (!empty($grade)) {
            $sql .= " AND s.grade_id = ?";
            $params[] = $grade;
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $students = $stmt->fetchAll();
        
        echo json_encode($students);
        exit;
    }
    
    if ($action === 'enroll_student') {
        if ($_SESSION['role'] !== 'director') {
            echo json_encode(['success' => false, 'message' => 'Permission denied']);
            exit;
        }
        
        $full_name = $_POST['full_name'] ?? '';
        $grade_id = $_POST['grade_id'] ?? '';
        $section_id = $_POST['section_id'] ?? '';
        $parent_name = $_POST['parent_name'] ?? '';
        $parent_phone = $_POST['parent_phone'] ?? '';
        
        $student_id = 'STU-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        
        $stmt = $pdo->prepare("INSERT INTO students (student_id, full_name, grade_id, section_id, parent_name, parent_phone, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'active', NOW())");
        $stmt->execute([$student_id, $full_name, $grade_id, $section_id, $parent_name, $parent_phone]);
        
        echo json_encode(['success' => true, 'student_id' => $student_id]);
        exit;
    }
    
    if ($action === 'get_grades') {
        $student_id = $_POST['student_id'] ?? ($_SESSION['role'] === 'student' ? $_SESSION['user_data']['student_id'] ?? 0 : 0);
        
        $sql = "SELECT g.*, s.name as subject_name, t.full_name as teacher_name 
                FROM grades g
                JOIN subjects s ON g.subject_id = s.id
                JOIN teachers t ON g.teacher_id = t.id
                WHERE g.student_id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$student_id]);
        $grades = $stmt->fetchAll();
        
        echo json_encode($grades);
        exit;
    }
    
    if ($action === 'save_grades') {
        if ($_SESSION['role'] !== 'teacher') {
            echo json_encode(['success' => false, 'message' => 'Permission denied']);
            exit;
        }
        
        $class_id = $_POST['class_id'] ?? '';
        $exam_type = $_POST['exam_type'] ?? '';
        $grades_data = json_decode($_POST['grades_data'] ?? '[]', true);
        
        $pdo->beginTransaction();
        try {
            foreach ($grades_data as $grade) {
                $stmt = $pdo->prepare("INSERT INTO grades (student_id, subject_id, exam_type, score, continuous_score, teacher_id, recorded_at) 
                                       VALUES (?, ?, ?, ?, ?, ?, NOW())
                                       ON DUPLICATE KEY UPDATE score = ?, continuous_score = ?");
                $stmt->execute([
                    $grade['student_id'], $grade['subject_id'], $exam_type,
                    $grade['score'], $grade['continuous'], $_SESSION['user_data']['teacher_id'],
                    $grade['score'], $grade['continuous']
                ]);
            }
            $pdo->commit();
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }
    
    if ($action === 'mark_attendance') {
        if ($_SESSION['role'] !== 'teacher') {
            echo json_encode(['success' => false, 'message' => 'Permission denied']);
            exit;
        }
        
        $class_id = $_POST['class_id'] ?? '';
        $date = $_POST['date'] ?? date('Y-m-d');
        $attendance_data = json_decode($_POST['attendance_data'] ?? '[]', true);
        
        $pdo->beginTransaction();
        try {
            foreach ($attendance_data as $record) {
                $stmt = $pdo->prepare("INSERT INTO attendance (student_id, teacher_id, class_id, date, status, note, marked_at) 
                                       VALUES (?, ?, ?, ?, ?, ?, NOW())
                                       ON DUPLICATE KEY UPDATE status = ?, note = ?");
                $stmt->execute([
                    $record['student_id'], $_SESSION['user_data']['teacher_id'], $class_id, $date,
                    $record['status'], $record['note'],
                    $record['status'], $record['note']
                ]);
            }
            $pdo->commit();
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }
    
    if ($action === 'get_exams') {
        $role = $_SESSION['role'] ?? '';
        $student_id = $_SESSION['user_data']['student_id'] ?? 0;
        $teacher_id = $_SESSION['user_data']['teacher_id'] ?? 0;
        
        if ($role === 'student') {
            $stmt = $pdo->prepare("SELECT e.*, s.name as subject_name 
                                   FROM exams e
                                   JOIN subjects s ON e.subject_id = s.id
                                   WHERE e.grade_id = (SELECT grade_id FROM students WHERE id = ?)
                                   ORDER BY e.exam_date ASC");
            $stmt->execute([$student_id]);
        } else {
            $stmt = $pdo->prepare("SELECT e.*, s.name as subject_name, g.name as grade_name
                                   FROM exams e
                                   JOIN subjects s ON e.subject_id = s.id
                                   JOIN grades g ON e.grade_id = g.id
                                   WHERE e.teacher_id = ?
                                   ORDER BY e.exam_date ASC");
            $stmt->execute([$teacher_id]);
        }
        
        $exams = $stmt->fetchAll();
        echo json_encode($exams);
        exit;
    }
    
    if ($action === 'get_library_books') {
        $search = $_POST['search'] ?? '';
        $category = $_POST['category'] ?? '';
        
        $sql = "SELECT * FROM library_books WHERE status = 'available'";
        $params = [];
        
        if (!empty($search)) {
            $sql .= " AND (title LIKE ? OR author LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        
        if (!empty($category)) {
            $sql .= " AND category = ?";
            $params[] = $category;
        }
        
        $sql .= " LIMIT 20";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $books = $stmt->fetchAll();
        
        echo json_encode($books);
        exit;
    }
    
    if ($action === 'borrow_book') {
        if (!in_array($_SESSION['role'], ['student', 'teacher'])) {
            echo json_encode(['success' => false, 'message' => 'Permission denied']);
            exit;
        }
        
        $book_id = $_POST['book_id'] ?? '';
        $user_type = $_SESSION['role'];
        $user_id = $_SESSION['role'] === 'student' ? $_SESSION['user_data']['student_id'] : $_SESSION['user_data']['teacher_id'];
        
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT available_copies FROM library_books WHERE id = ? FOR UPDATE");
            $stmt->execute([$book_id]);
            $book = $stmt->fetch();
            
            if ($book['available_copies'] <= 0) {
                throw new Exception('No copies available');
            }
            
            $due_date = date('Y-m-d', strtotime('+14 days'));
            $stmt = $pdo->prepare("INSERT INTO book_loans (book_id, user_type, user_id, borrow_date, due_date, status) VALUES (?, ?, ?, NOW(), ?, 'borrowed')");
            $stmt->execute([$book_id, $user_type, $user_id, $due_date]);
            
            $stmt = $pdo->prepare("UPDATE library_books SET available_copies = available_copies - 1 WHERE id = ?");
            $stmt->execute([$book_id]);
            
            $pdo->commit();
            echo json_encode(['success' => true, 'due_date' => $due_date]);
        } catch (Exception $e) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }
    
    if ($action === 'get_finance_summary') {
        $stmt = $pdo->query("SELECT SUM(total_fees) as total_expected, SUM(amount_paid) as total_paid FROM fee_records WHERE academic_year = '2024/2025'");
        $summary = $stmt->fetch();
        
        $stmt = $pdo->query("SELECT s.full_name, s.student_id, f.amount_paid, f.payment_date, f.status
                             FROM fee_records f
                             JOIN students s ON f.student_id = s.id
                             ORDER BY f.payment_date DESC LIMIT 10");
        $recent = $stmt->fetchAll();
        
        echo json_encode(['summary' => $summary, 'recent' => $recent]);
        exit;
    }
    
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
    exit;
}

// Check if user is logged in for page requests
$is_logged_in = isset($_SESSION['user_id']);
$current_role = $_SESSION['role'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>BOLE GENERAL SECONDARY SCHOOL</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  :root {
    --green-dark: #1a3d2b;
    --green-mid: #2d6a4f;
    --green-accent: #3a8f5f;
    --green-light: #52b788;
    --gold: #c9a84c;
    --gold-light: #e6c96e;
    --white: #ffffff;
    --off-white: #f8f6f1;
    --text-dark: #1a1a1a;
    --text-mid: #4a5568;
    --text-light: #8a9bb0;
    --sidebar-w: 220px;
    --shadow: 0 4px 24px rgba(0,0,0,0.08);
    --radius: 12px;
  }

  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family:'DM Sans',sans-serif; background:var(--off-white); color:var(--text-dark); }

  /* ─── SCREENS ─── */
  .screen { display:none; min-height:100vh; }
  .screen.active { display:flex; }

  /* ══════════════════════════════════════════
     LOGIN
  ══════════════════════════════════════════ */
  #login-screen {
    background: linear-gradient(135deg, var(--green-dark) 0%, #0f2318 60%, #0a1a10 100%);
    align-items:center; justify-content:center;
    position:relative; overflow:hidden;
  }
  #login-screen::before {
    content:'';
    position:absolute; inset:0;
    background: radial-gradient(ellipse 60% 50% at 70% 30%, rgba(82,183,136,0.12) 0%, transparent 70%),
                radial-gradient(ellipse 40% 40% at 20% 80%, rgba(201,168,76,0.08) 0%, transparent 60%);
  }
  .login-card {
    background:var(--white);
    border-radius:20px;
    padding:40px 36px;
    width:100%; max-width:420px;
    box-shadow: 0 32px 80px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.05);
    position:relative; z-index:1;
    animation: fadeUp .5s ease;
  }
  @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }

  .login-logo {
    width:60px; height:60px; border-radius:50%;
    background: linear-gradient(135deg, var(--gold) 0%, var(--gold-light) 100%);
    display:flex; align-items:center; justify-content:center;
    margin:0 auto 16px;
    font-family:'Playfair Display',serif;
    font-size:20px; font-weight:700; color:var(--green-dark);
    box-shadow: 0 4px 16px rgba(201,168,76,0.4);
  }
  .login-title { text-align:center; font-family:'Playfair Display',serif; font-size:22px; font-weight:700; color:var(--green-dark); margin-bottom:4px; }
  .login-sub { text-align:center; font-size:13px; color:var(--text-light); margin-bottom:28px; }

  .sign-in-as { text-align:center; font-size:13px; color:var(--text-mid); margin-bottom:12px; }
  .role-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:24px; }
  .role-btn {
    border:2px solid #e2e8f0; border-radius:10px;
    padding:14px 10px; cursor:pointer;
    background:var(--white); transition:all .2s;
    display:flex; flex-direction:column; align-items:center; gap:6px;
    font-size:13px; font-weight:500; color:var(--text-mid);
  }
  .role-btn .icon { font-size:26px; }
  .role-btn:hover { border-color:var(--green-accent); background:#f0faf4; }
  .role-btn.selected { border-color:var(--green-accent); background:#e8f5ee; color:var(--green-dark); }

  .field-label { font-size:13px; font-weight:500; color:var(--text-dark); margin-bottom:6px; display:block; }
  .field-group { margin-bottom:16px; }
  .field-input {
    width:100%; padding:11px 14px;
    border:1.5px solid #e2e8f0; border-radius:8px;
    font-family:'DM Sans',sans-serif; font-size:14px;
    outline:none; transition:border-color .2s;
    color:var(--text-dark);
  }
  .field-input:focus { border-color:var(--green-accent); }

  .login-btn {
    width:100%; padding:14px;
    background: linear-gradient(135deg, var(--green-mid) 0%, var(--green-dark) 100%);
    color:var(--white); border:none; border-radius:10px;
    font-family:'DM Sans',sans-serif; font-size:15px; font-weight:600;
    cursor:pointer; transition:all .2s;
    margin-top:4px;
    box-shadow: 0 4px 16px rgba(45,106,79,0.4);
  }
  .login-btn:hover { transform:translateY(-1px); box-shadow:0 8px 24px rgba(45,106,79,0.5); }

  .login-footer { text-align:center; font-size:12px; color:var(--text-light); margin-top:20px; }

  /* ══════════════════════════════════════════
     APP LAYOUT (sidebar + main)
  ══════════════════════════════════════════ */
  .app-screen { flex-direction:column; }

  /* Topbar */
  .topbar {
    background: linear-gradient(135deg, var(--green-dark) 0%, #0f2318 100%);
    height:56px; display:flex; align-items:center; justify-content:space-between;
    padding:0 20px; position:sticky; top:0; z-index:100;
    box-shadow: 0 2px 12px rgba(0,0,0,0.3);
  }
  .topbar-left { display:flex; align-items:center; gap:12px; }
  .topbar-logo {
    width:34px; height:34px; border-radius:50%;
    background: linear-gradient(135deg, var(--gold) 0%, var(--gold-light) 100%);
    display:flex; align-items:center; justify-content:center;
    font-family:'Playfair Display',serif; font-size:12px; font-weight:700;
    color:var(--green-dark);
  }
  .topbar-name { color:var(--white); font-weight:600; font-size:15px; }
  .topbar-tagline { color:rgba(255,255,255,0.5); font-size:11px; }

  .topbar-right { display:flex; align-items:center; gap:12px; }
  .notif-btn {
    background:rgba(255,255,255,0.1); border:none; border-radius:8px;
    width:34px; height:34px; cursor:pointer; color:var(--white);
    font-size:16px; display:flex; align-items:center; justify-content:center;
    transition:.2s; position:relative;
  }
  .notif-btn:hover { background:rgba(255,255,255,0.2); }
  .notif-dot {
    position:absolute; top:6px; right:6px;
    width:7px; height:7px; border-radius:50%;
    background:var(--gold); border:1.5px solid var(--green-dark);
  }
  .role-badge {
    background:rgba(255,255,255,0.12); border:1px solid rgba(255,255,255,0.2);
    border-radius:8px; padding:6px 12px;
    color:var(--white); font-size:13px; font-weight:500;
    display:flex; align-items:center; gap:6px; cursor:pointer;
    transition:.2s;
  }
  .role-badge:hover { background:rgba(255,255,255,0.2); }
  .role-badge .arrow { font-size:10px; opacity:.7; }
  .avatar {
    width:32px; height:32px; border-radius:50%;
    background: linear-gradient(135deg, var(--gold) 0%, #b8860b 100%);
    display:flex; align-items:center; justify-content:center;
    font-size:13px; font-weight:700; color:var(--green-dark);
    cursor:pointer;
  }

  /* Layout body */
  .app-body { display:flex; flex:1; min-height:calc(100vh - 56px); }

  /* Sidebar */
  .sidebar {
    width:var(--sidebar-w); background: linear-gradient(180deg, #1e4535 0%, #162e24 100%);
    padding:20px 0; position:sticky; top:56px; height:calc(100vh - 56px);
    overflow-y:auto; flex-shrink:0;
  }
  .sidebar-section { padding:0 14px; margin-bottom:8px; }
  .sidebar-label {
    font-size:10px; font-weight:600; letter-spacing:1.2px;
    color:rgba(255,255,255,0.35); text-transform:uppercase;
    padding:0 8px; margin-bottom:6px; margin-top:16px;
  }
  .sidebar-link {
    display:flex; align-items:center; gap:10px;
    padding:9px 12px; border-radius:8px;
    color:rgba(255,255,255,0.65); font-size:13.5px; font-weight:500;
    cursor:pointer; transition:.2s; text-decoration:none;
    position:relative;
  }
  .sidebar-link:hover { background:rgba(255,255,255,0.08); color:var(--white); }
  .sidebar-link.active { background:rgba(82,183,136,0.2); color:var(--white); }
  .sidebar-link.active::before {
    content:''; position:absolute; left:0; top:50%; transform:translateY(-50%);
    width:3px; height:60%; border-radius:0 3px 3px 0;
    background:var(--green-light);
  }
  .sidebar-link .icon { font-size:16px; flex-shrink:0; }
  .badge {
    margin-left:auto; background:var(--gold);
    color:var(--green-dark); font-size:10px; font-weight:700;
    padding:2px 6px; border-radius:10px;
  }

  /* Main content */
  .main-content { flex:1; padding:28px; overflow-y:auto; }
  .breadcrumb { font-size:12px; color:var(--text-light); margin-bottom:6px; }
  .breadcrumb span { color:var(--text-mid); }
  .page-title { font-family:'Playfair Display',serif; font-size:26px; font-weight:700; color:var(--text-dark); margin-bottom:24px; }

  /* Stat cards */
  .stats-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:28px; }
  .stat-card {
    background:var(--white); border-radius:var(--radius);
    padding:20px; box-shadow:var(--shadow);
    border-top:3px solid transparent;
    position:relative; overflow:hidden;
    transition:.2s;
  }
  .stat-card:hover { transform:translateY(-2px); box-shadow:0 8px 32px rgba(0,0,0,0.12); }
  .stat-card.blue { border-top-color:#4a90d9; }
  .stat-card.green { border-top-color:var(--green-light); }
  .stat-card.gold { border-top-color:var(--gold); }
  .stat-card.red { border-top-color:#e05c5c; }

  .stat-label { font-size:12px; color:var(--text-light); font-weight:500; margin-bottom:8px; text-transform:uppercase; letter-spacing:.5px; }
  .stat-value { font-size:30px; font-weight:700; color:var(--text-dark); line-height:1; margin-bottom:6px; }
  .stat-delta { font-size:12px; color:#38a169; }
  .stat-delta.down { color:#e05c5c; }
  .stat-icon {
    position:absolute; right:16px; top:50%; transform:translateY(-50%);
    font-size:38px; opacity:.08;
  }

  /* Two-column grid */
  .two-col { display:grid; grid-template-columns:1fr 1fr; gap:20px; }

  /* Card */
  .card { background:var(--white); border-radius:var(--radius); padding:22px; box-shadow:var(--shadow); }
  .card-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:18px; }
  .card-title { font-size:15px; font-weight:600; color:var(--text-dark); display:flex; align-items:center; gap:8px; }
  .card-title .icon { font-size:16px; }
  .view-all { font-size:12px; color:var(--green-accent); cursor:pointer; font-weight:500; }
  .view-all:hover { text-decoration:underline; }

  /* Announcements */
  .ann-item { padding:12px 0; border-bottom:1px solid #f0f4f8; }
  .ann-item:last-child { border-bottom:none; }
  .ann-title { font-size:13.5px; font-weight:600; color:var(--text-dark); margin-bottom:4px; }
  .ann-meta { font-size:11px; color:var(--text-light); display:flex; align-items:center; gap:4px; }

  /* Activity */
  .activity-item { display:flex; gap:12px; padding:8px 0; }
  .activity-dot { width:8px; height:8px; border-radius:50%; background:var(--green-light); flex-shrink:0; margin-top:5px; }
  .activity-dot.yellow { background:var(--gold); }
  .activity-text { font-size:13px; color:var(--text-mid); line-height:1.5; }
  .activity-time { font-size:11px; color:var(--text-light); }

  /* Page sections */
  .section-page { display:none; }
  .section-page.active { display:block; }

  /* Table */
  .table-wrap { overflow-x:auto; }
  table { width:100%; border-collapse:collapse; font-size:13.5px; }
  th { background:#f8f6f1; color:var(--text-mid); font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:.5px; padding:11px 14px; text-align:left; }
  td { padding:11px 14px; border-bottom:1px solid #f0f4f8; color:var(--text-dark); }
  tr:hover td { background:#fafcff; }
  .chip {
    display:inline-block; padding:3px 10px; border-radius:20px;
    font-size:11px; font-weight:600;
  }
  .chip.green { background:#d4edda; color:#1a6b3c; }
  .chip.red { background:#fde8e8; color:#b91c1c; }
  .chip.gold { background:#fef3cd; color:#7d5a00; }
  .chip.blue { background:#dbeafe; color:#1e40af; }

  /* Form */
  .form-row { display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:16px; }
  .form-group { display:flex; flex-direction:column; gap:5px; }
  .form-group label { font-size:13px; font-weight:500; color:var(--text-mid); }
  .form-group input, .form-group select, .form-group textarea {
    padding:9px 12px; border:1.5px solid #e2e8f0; border-radius:8px;
    font-family:'DM Sans',sans-serif; font-size:13px; outline:none;
    transition:border-color .2s;
  }
  .form-group input:focus, .form-group select:focus { border-color:var(--green-accent); }
  .btn-primary {
    background: linear-gradient(135deg, var(--green-mid), var(--green-dark));
    color:var(--white); border:none; border-radius:8px;
    padding:10px 22px; font-family:'DM Sans',sans-serif;
    font-size:13.5px; font-weight:600; cursor:pointer;
    box-shadow:0 3px 12px rgba(45,106,79,0.35);
    transition:.2s;
  }
  .btn-primary:hover { transform:translateY(-1px); }
  .btn-outline {
    background:transparent; color:var(--green-mid);
    border:1.5px solid var(--green-mid); border-radius:8px;
    padding:9px 20px; font-family:'DM Sans',sans-serif;
    font-size:13.5px; font-weight:600; cursor:pointer; transition:.2s;
  }
  .btn-outline:hover { background:#f0faf4; }

  /* Schedule grid */
  .schedule-grid { display:grid; grid-template-columns:80px repeat(5,1fr); gap:4px; font-size:12px; }
  .sched-header { background:var(--green-dark); color:var(--white); padding:8px; border-radius:6px; text-align:center; font-weight:600; }
  .sched-time { background:#f0f4f8; color:var(--text-mid); padding:8px; border-radius:6px; text-align:center; font-size:11px; }
  .sched-cell { background:var(--white); padding:8px; border-radius:6px; border:1px solid #e8edf3; min-height:60px; }
  .sched-cell.has-class { background:#e8f5ee; border-color:#b2dfcd; }
  .sched-subject { font-weight:600; color:var(--green-dark); font-size:12px; }
  .sched-room { color:var(--text-light); font-size:11px; }

  /* Grades chart bar */
  .grade-bar-wrap { margin-bottom:14px; }
  .grade-bar-label { display:flex; justify-content:space-between; font-size:13px; margin-bottom:5px; }
  .grade-bar-bg { background:#f0f4f8; border-radius:10px; height:10px; overflow:hidden; }
  .grade-bar-fill { height:100%; border-radius:10px; transition:width 1s ease; }

  /* GPA ring placeholder */
  .gpa-ring { display:flex; align-items:center; gap:20px; padding:16px 0; }
  .ring-num { font-size:40px; font-weight:700; color:var(--green-mid); font-family:'Playfair Display',serif; }
  .ring-label { font-size:14px; color:var(--text-mid); }
  .ring-delta { font-size:13px; color:#38a169; font-weight:500; }

  /* Logout confirm */
  .logout-area { margin-top:16px; padding:0 14px; }
  .logout-btn {
    width:100%; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.12);
    border-radius:8px; padding:9px 12px; color:rgba(255,255,255,0.6);
    font-size:13px; cursor:pointer; transition:.2s; text-align:left;
    display:flex; align-items:center; gap:8px;
    font-family:'DM Sans',sans-serif;
  }
  .logout-btn:hover { background:rgba(255,80,80,0.15); color:#f87171; border-color:rgba(255,80,80,0.3); }

  /* Attendance summary */
  .att-summary { display:flex; gap:16px; margin-bottom:20px; }
  .att-box { flex:1; background:var(--white); border-radius:var(--radius); padding:16px; text-align:center; box-shadow:var(--shadow); }
  .att-box .num { font-size:28px; font-weight:700; color:var(--text-dark); }
  .att-box .lbl { font-size:12px; color:var(--text-light); margin-top:4px; }
  .att-box.green .num { color:var(--green-mid); }
  .att-box.red .num { color:#e05c5c; }
  .att-box.gold .num { color:var(--gold); }

  /* Month calendar placeholder */
  .calendar-mini { display:grid; grid-template-columns:repeat(7,1fr); gap:4px; }
  .cal-day { aspect-ratio:1; display:flex; align-items:center; justify-content:center;
    border-radius:6px; font-size:12px; cursor:pointer; transition:.2s; }
  .cal-day.header { font-weight:600; color:var(--text-light); font-size:11px; }
  .cal-day.present { background:#e8f5ee; color:var(--green-mid); }
  .cal-day.absent { background:#fde8e8; color:#b91c1c; }
  .cal-day.holiday { background:#fef3cd; color:#7d5a00; }
  .cal-day.empty { background:transparent; }
  .cal-day:not(.header):not(.empty):hover { filter:brightness(.92); }

  /* Exam card */
  .exam-card { background:var(--white); border-radius:var(--radius); padding:18px; box-shadow:var(--shadow); margin-bottom:14px; display:flex; align-items:center; gap:16px; }
  .exam-date-box { background: linear-gradient(135deg, var(--green-mid), var(--green-dark)); color:var(--white); border-radius:10px; padding:10px 14px; text-align:center; flex-shrink:0; min-width:56px; }
  .exam-date-box .day { font-size:22px; font-weight:700; line-height:1; }
  .exam-date-box .month { font-size:11px; opacity:.8; }
  .exam-info { flex:1; }
  .exam-subject { font-size:15px; font-weight:600; color:var(--text-dark); }
  .exam-detail { font-size:12px; color:var(--text-light); margin-top:3px; }

  /* Library */
  .book-card { background:var(--white); border-radius:var(--radius); padding:16px; box-shadow:var(--shadow); display:flex; gap:14px; align-items:center; margin-bottom:12px; }
  .book-spine { width:10px; align-self:stretch; border-radius:3px; flex-shrink:0; }
  .book-title { font-size:14px; font-weight:600; color:var(--text-dark); }
  .book-author { font-size:12px; color:var(--text-light); margin-top:2px; }

  /* Announcement form */
  .ann-chip { display:inline-flex; align-items:center; gap:6px; background:#e8f5ee; color:var(--green-dark); padding:4px 10px; border-radius:20px; font-size:12px; font-weight:500; margin:3px; cursor:pointer; border:1.5px solid transparent; transition:.2s; }
  .ann-chip.selected { background:var(--green-dark); color:var(--white); }

  /* Finance */
  .finance-row { display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:20px; }
  .finance-box { background:var(--white); border-radius:var(--radius); padding:18px; box-shadow:var(--shadow); }
  .finance-box .f-lbl { font-size:12px; color:var(--text-light); text-transform:uppercase; letter-spacing:.5px; margin-bottom:8px; }
  .finance-box .f-val { font-size:22px; font-weight:700; }
  .finance-box .f-val.green { color:var(--green-mid); }
  .finance-box .f-val.red { color:#e05c5c; }
  .finance-box .f-val.gold { color:var(--gold); }

  .loading { opacity: 0.6; pointer-events: none; }
  .toast { position: fixed; bottom: 20px; right: 20px; background: var(--green-dark); color: white; padding: 12px 20px; border-radius: 8px; z-index: 1000; animation: slideIn 0.3s ease; }
  .toast.error { background: #e05c5c; }
  @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
</style>
</head>
<body>

<!-- ═══════════════════════════ LOGIN ═══════════════════════════ -->
<div id="login-screen" class="screen <?php echo !$is_logged_in ? 'active' : ''; ?>" style="<?php echo $is_logged_in ? 'display:none' : 'display:flex'; ?>">
  <div class="login-card">
    <div class="login-logo">BGSS</div>
    <div class="login-title">BOLE GENERAL SECONDARY SCHOOL</div>
    <div class="login-sub">School Management System</div>

    <div class="sign-in-as">Sign in as</div>
    <div class="role-grid">
      <div class="role-btn selected" data-role="director" onclick="selectRole(this,'director')">
        <span class="icon">🏛️</span> Director
      </div>
      <div class="role-btn" data-role="teacher" onclick="selectRole(this,'teacher')">
        <span class="icon">👩‍🏫</span> Teacher
      </div>
      <div class="role-btn" data-role="student" onclick="selectRole(this,'student')">
        <span class="icon">🎓</span> Student
      </div>
      <div class="role-btn" data-role="parent" onclick="selectRole(this,'parent')">
        <span class="icon">👨‍👩‍👧</span> Parent
      </div>
    </div>

    <div class="field-group">
      <label class="field-label">Username / ID</label>
      <input id="login-user" class="field-input" type="text" placeholder="Enter username or ID">
    </div>
    <div class="field-group">
      <label class="field-label">Password</label>
      <input id="login-pass" class="field-input" type="password" placeholder="Enter password">
    </div>

    <button class="login-btn" onclick="doLogin()">Sign In →</button>
    <div class="login-footer">Academic Year 2024/2025 · Addis Ababa, Ethiopia</div>
  </div>
</div>

<?php if ($is_logged_in): ?>
<!-- ═══════════════════════════ DIRECTOR ═══════════════════════════ -->
<div id="director-screen" class="screen app-screen <?php echo $current_role === 'director' ? 'active' : ''; ?>" style="<?php echo $current_role === 'director' ? 'display:flex' : 'display:none'; ?>">
  <div class="topbar">
    <div class="topbar-left">
      <div class="topbar-logo">BGSS</div>
      <div>
        <div class="topbar-name">BOLE GENERAL SECONDARY SCHOOL</div>
        <div class="topbar-tagline">Integrated School Management System</div>
      </div>
    </div>
    <div class="topbar-right">
      <button class="notif-btn" onclick="loadNotifications()">🔔<div class="notif-dot"></div></button>
      <div class="role-badge">🏛️ <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Director'); ?> <span class="arrow">▾</span></div>
      <div class="avatar" onclick="showLogoutConfirm()"><?php echo strtoupper(substr($_SESSION['full_name'] ?? 'AD', 0, 2)); ?></div>
    </div>
  </div>
  <div class="app-body">
    <div class="sidebar" id="dir-sidebar">
      <div class="sidebar-section">
        <div class="sidebar-label">Overview</div>
        <div class="sidebar-link active" onclick="dirNav(this,'dir-dashboard')"><span class="icon">🏠</span> Dashboard</div>
        <div class="sidebar-link" onclick="dirNav(this,'dir-reports')"><span class="icon">📊</span> Reports &amp; Analytics</div>
        <div class="sidebar-link" onclick="dirNav(this,'dir-announce')"><span class="icon">📢</span> Announcements</div>
      </div>
      <div class="sidebar-section">
        <div class="sidebar-label">Academic</div>
        <div class="sidebar-link" onclick="dirNav(this,'dir-students')"><span class="icon">👥</span> Students <span class="badge" id="student-count-badge">+8</span></div>
        <div class="sidebar-link" onclick="dirNav(this,'dir-teachers')"><span class="icon">👩‍🏫</span> Teachers <span class="badge" id="teacher-count-badge">54</span></div>
        <div class="sidebar-link" onclick="dirNav(this,'dir-grades')"><span class="icon">📝</span> Grades</div>
        <div class="sidebar-link" onclick="dirNav(this,'dir-attendance')"><span class="icon">✅</span> Attendance</div>
        <div class="sidebar-link" onclick="dirNav(this,'dir-schedule')"><span class="icon">📅</span> Schedule</div>
        <div class="sidebar-link" onclick="dirNav(this,'dir-exams')"><span class="icon">📋</span> Examinations</div>
      </div>
      <div class="sidebar-section">
        <div class="sidebar-label">Administration</div>
        <div class="sidebar-link" onclick="dirNav(this,'dir-library')"><span class="icon">📚</span> Library</div>
        <div class="sidebar-link" onclick="dirNav(this,'dir-finance')"><span class="icon">💰</span> Finance &amp; Fees</div>
        <div class="sidebar-link" onclick="dirNav(this,'dir-settings')"><span class="icon">⚙️</span> Settings</div>
      </div>
      <div class="logout-area">
        <button class="logout-btn" onclick="doLogout()">🚪 Sign Out</button>
      </div>
    </div>
    <div class="main-content">

      <!-- Dashboard -->
      <div class="section-page active" id="dir-dashboard">
        <div class="breadcrumb">Home / <span>Dashboard</span></div>
        <div class="page-title">Dashboard Overview</div>
        <div class="stats-grid" id="dir-stats">
          <div class="stat-card blue">
            <div class="stat-label">Total Students</div>
            <div class="stat-value" id="stat-students">--</div>
            <div class="stat-delta">↑ 12 this term</div>
            <div class="stat-icon">👥</div>
          </div>
          <div class="stat-card green">
            <div class="stat-label">Teaching Staff</div>
            <div class="stat-value" id="stat-teachers">--</div>
            <div class="stat-delta" style="color:#e05c5c">3 on leave</div>
            <div class="stat-icon">👩‍🏫</div>
          </div>
          <div class="stat-card gold">
            <div class="stat-label">Attendance Today</div>
            <div class="stat-value" id="stat-attendance">--</div>
            <div class="stat-delta">↑ 1.2%</div>
            <div class="stat-icon">✅</div>
          </div>
          <div class="stat-card red">
            <div class="stat-label">Fee Collection</div>
            <div class="stat-value" id="stat-fee">--</div>
            <div class="stat-delta" id="stat-fee-delta">ETB 842K collected</div>
            <div class="stat-icon">💰</div>
          </div>
        </div>
        <div class="two-col">
          <div class="card">
            <div class="card-header">
              <div class="card-title"><span class="icon">📢</span> Announcements</div>
              <div class="view-all" onclick="loadAllAnnouncements()">View All</div>
            </div>
            <div id="announcements-list"></div>
          </div>
          <div class="card">
            <div class="card-header">
              <div class="card-title"><span class="icon">⏱️</span> Recent Activity</div>
            </div>
            <div id="activity-list"></div>
          </div>
        </div>
      </div>

      <!-- Students -->
      <div class="section-page" id="dir-students">
        <div class="breadcrumb">Home / <span>Students</span></div>
        <div class="page-title">Student Records</div>
        <div style="display:flex;gap:10px;margin-bottom:18px;align-items:center;">
          <input class="field-input" id="student-search" style="max-width:260px;" placeholder="🔍  Search student..." onkeyup="loadStudents()">
          <select class="field-input" id="student-grade-filter" style="max-width:140px;" onchange="loadStudents()">
            <option value="">All Grades</option>
            <option value="1">Grade 9</option>
            <option value="2">Grade 10</option>
            <option value="3">Grade 11</option>
            <option value="4">Grade 12</option>
          </select>
          <button class="btn-primary" style="margin-left:auto;" onclick="openEnrollModal()">+ Enroll Student</button>
        </div>
        <div class="card">
          <div class="table-wrap">
            <table id="students-table">
              <thead><tr><th>ID</th><th>Name</th><th>Grade</th><th>Section</th><th>GPA</th><th>Attendance</th><th>Fee Status</th><th>Actions</th></tr></thead>
              <tbody><tr><td colspan="8" style="text-align:center">Loading...</td></tr></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Teachers -->
      <div class="section-page" id="dir-teachers">
        <div class="breadcrumb">Home / <span>Teachers</span></div>
        <div class="page-title">Teaching Staff</div>
        <div style="display:flex;gap:10px;margin-bottom:18px;">
          <input class="field-input" id="teacher-search" style="max-width:260px;" placeholder="🔍  Search teacher...">
          <button class="btn-primary" style="margin-left:auto;" onclick="openAddTeacherModal()">+ Add Teacher</button>
        </div>
        <div class="card">
          <div class="table-wrap">
            <table id="teachers-table">
              <thead><tr><th>ID</th><th>Name</th><th>Subject</th><th>Grades</th><th>Classes</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody><tr><td colspan="7" style="text-align:center">Loading...</td></tr></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Grades -->
      <div class="section-page" id="dir-grades">
        <div class="breadcrumb">Home / <span>Grades</span></div>
        <div class="page-title">Academic Performance</div>
        <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);">
          <div class="stat-card green"><div class="stat-label">School Average GPA</div><div class="stat-value" id="avg-gpa">3.4</div><div class="stat-delta">↑ 0.1 this term</div></div>
          <div class="stat-card blue"><div class="stat-label">Honour Roll Students</div><div class="stat-value" id="honor-roll">124</div><div class="stat-delta">Top 14.7%</div></div>
          <div class="stat-card red"><div class="stat-label">Students at Risk</div><div class="stat-value" id="at-risk">38</div><div class="stat-delta" style="color:#e05c5c">Needs attention</div></div>
        </div>
        <div class="two-col">
          <div class="card">
            <div class="card-header"><div class="card-title">📊 Average Grade by Subject</div></div>
            <div id="subject-grades-chart"></div>
          </div>
          <div class="card">
            <div class="card-header"><div class="card-title">🏆 Top Students</div></div>
            <div class="table-wrap">
              <table id="top-students-table">
                <thead><tr><th>Rank</th><th>Name</th><th>Grade</th><th>GPA</th></tr></thead>
                <tbody><tr><td colspan="4" style="text-align:center">Loading...</td></tr></tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- Attendance -->
      <div class="section-page" id="dir-attendance">
        <div class="breadcrumb">Home / <span>Attendance</span></div>
        <div class="page-title">Attendance Overview</div>
        <div class="att-summary" id="att-summary">
          <div class="att-box green"><div class="num" id="att-present">--</div><div class="lbl">Present Today</div></div>
          <div class="att-box red"><div class="num" id="att-absent">--</div><div class="lbl">Absent Today</div></div>
          <div class="att-box gold"><div class="num" id="att-late">--</div><div class="lbl">Late Arrivals</div></div>
          <div class="att-box"><div class="num" id="att-rate">--</div><div class="lbl">Attendance Rate</div></div>
        </div>
        <div class="card">
          <div class="card-header"><div class="card-title">📅 Class Attendance — Today</div></div>
          <div class="table-wrap">
            <table id="class-attendance-table">
              <thead><tr><th>Class</th><th>Teacher</th><th>Present</th><th>Absent</th><th>Rate</th><th>Status</th></tr></thead>
              <tbody><tr><td colspan="6" style="text-align:center">Loading...</td></tr></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Schedule -->
      <div class="section-page" id="dir-schedule">
        <div class="breadcrumb">Home / <span>Schedule</span></div>
        <div class="page-title">School Schedule</div>
        <div class="card">
          <div class="card-header"><div class="card-title">📅 Master Timetable — Grade 11A</div></div>
          <div class="schedule-grid" id="schedule-grid"></div>
        </div>
      </div>

      <!-- Exams -->
      <div class="section-page" id="dir-exams">
        <div class="breadcrumb">Home / <span>Examinations</span></div>
        <div class="page-title">Examination Schedule</div>
        <div id="exams-list"></div>
      </div>

      <!-- Library -->
      <div class="section-page" id="dir-library">
        <div class="breadcrumb">Home / <span>Library</span></div>
        <div class="page-title">Library Management</div>
        <div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px;" id="library-stats">
          <div class="stat-card blue"><div class="stat-label">Total Books</div><div class="stat-value" id="lib-total">3,420</div></div>
          <div class="stat-card green"><div class="stat-label">Borrowed</div><div class="stat-value" id="lib-borrowed">186</div></div>
          <div class="stat-card red"><div class="stat-label">Overdue</div><div class="stat-value" id="lib-overdue">23</div></div>
          <div class="stat-card gold"><div class="stat-label">New This Month</div><div class="stat-value" id="lib-new">14</div></div>
        </div>
        <div id="library-books-list"></div>
      </div>

      <!-- Finance -->
      <div class="section-page" id="dir-finance">
        <div class="breadcrumb">Home / <span>Finance &amp; Fees</span></div>
        <div class="page-title">Finance Overview</div>
        <div class="finance-row" id="finance-summary">
          <div class="finance-box"><div class="f-lbl">Total Expected</div><div class="f-val gold" id="fin-total">ETB --</div></div>
          <div class="finance-box"><div class="f-lbl">Collected</div><div class="f-val green" id="fin-collected">ETB --</div></div>
          <div class="finance-box"><div class="f-lbl">Outstanding</div><div class="f-val red" id="fin-outstanding">ETB --</div></div>
        </div>
        <div class="card">
          <div class="card-header"><div class="card-title">💳 Recent Payments</div></div>
          <div class="table-wrap">
            <table id="recent-payments-table">
              <thead><tr><th>Student</th><th>Grade</th><th>Amount (ETB)</th><th>Date</th><th>Status</th></tr></thead>
              <tbody><tr><td colspan="5" style="text-align:center">Loading...</td></tr></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Reports -->
      <div class="section-page" id="dir-reports">
        <div class="breadcrumb">Home / <span>Reports</span></div>
        <div class="page-title">Reports &amp; Analytics</div>
        <div class="two-col">
          <div class="card">
            <div class="card-header"><div class="card-title">📈 Enrollment Trend</div></div>
            <div id="enrollment-trend"></div>
          </div>
          <div class="card">
            <div class="card-header"><div class="card-title">📊 Generate Report</div></div>
            <div class="form-group" style="margin-bottom:12px;"><label>Report Type</label>
              <select id="report-type">
                <option value="academic">Academic Performance</option>
                <option value="attendance">Attendance Summary</option>
                <option value="finance">Fee Collection</option>
              </select>
            </div>
            <div class="form-row">
              <div class="form-group"><label>From</label><input type="date" id="report-from" value="2024-09-01"></div>
              <div class="form-group"><label>To</label><input type="date" id="report-to" value="2024-11-15"></div>
            </div>
            <div style="display:flex;gap:10px;margin-top:8px;">
              <button class="btn-primary" onclick="generateReport()">📄 Generate PDF</button>
              <button class="btn-outline" onclick="exportReport()">📊 Export CSV</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Announcements -->
      <div class="section-page" id="dir-announce">
        <div class="breadcrumb">Home / <span>Announcements</span></div>
        <div class="page-title">Post Announcement</div>
        <div class="two-col">
          <div class="card">
            <div class="card-header"><div class="card-title">✏️ New Announcement</div></div>
            <div class="form-group" style="margin-bottom:12px;"><label>Title</label><input type="text" id="ann-title" placeholder="Announcement title..."></div>
            <div class="form-group" style="margin-bottom:12px;"><label>Message</label><textarea id="ann-content" rows="4" placeholder="Write your message here..." style="resize:vertical;border:1.5px solid #e2e8f0;border-radius:8px;padding:9px 12px;font-family:'DM Sans',sans-serif;font-size:13px;width:100%;outline:none;"></textarea></div>
            <div style="margin-bottom:16px;">
              <div style="font-size:13px;color:var(--text-mid);margin-bottom:8px;font-weight:500;">Audience</div>
              <span class="ann-chip selected" data-audience="all" onclick="selectAudience(this)">All</span>
              <span class="ann-chip" data-audience="teacher" onclick="selectAudience(this)">Teachers</span>
              <span class="ann-chip" data-audience="student" onclick="selectAudience(this)">Students</span>
              <span class="ann-chip" data-audience="parent" onclick="selectAudience(this)">Parents</span>
            </div>
            <button class="btn-primary" onclick="postAnnouncement()">📢 Post Announcement</button>
          </div>
          <div class="card">
            <div class="card-header"><div class="card-title">📋 Recent Announcements</div></div>
            <div id="recent-announcements-list"></div>
          </div>
        </div>
      </div>

      <!-- Settings -->
      <div class="section-page" id="dir-settings">
        <div class="breadcrumb">Home / <span>Settings</span></div>
        <div class="page-title">System Settings</div>
        <div class="two-col">
          <div class="card">
            <div class="card-header"><div class="card-title">🏫 School Information</div></div>
            <div class="form-row">
              <div class="form-group"><label>School Name</label><input id="school-name" value="Bole General Secondary School"></div>
              <div class="form-group"><label>Academic Year</label><input id="academic-year" value="2024/2025"></div>
            </div>
            <div class="form-row">
              <div class="form-group"><label>City</label><input id="school-city" value="Addis Ababa"></div>
              <div class="form-group"><label>Region</label><input id="school-region" value="Addis Ababa City Admin."></div>
            </div>
            <button class="btn-primary" onclick="saveSettings()">💾 Save Changes</button>
          </div>
          <div class="card">
            <div class="card-header"><div class="card-title">🔒 Security</div></div>
            <div class="form-group" style="margin-bottom:12px;"><label>Current Password</label><input type="password" id="current-pwd"></div>
            <div class="form-group" style="margin-bottom:12px;"><label>New Password</label><input type="password" id="new-pwd"></div>
            <div class="form-group" style="margin-bottom:16px;"><label>Confirm Password</label><input type="password" id="confirm-pwd"></div>
            <button class="btn-primary" onclick="updatePassword()">🔑 Update Password</button>
          </div>
        </div>
      </div>

    </div><!-- end main-content -->
  </div><!-- end app-body -->
</div><!-- end director-screen -->
<?php endif; ?>

<script>
let currentRole = '<?php echo $current_role ?? ''; ?>';
let selectedAudience = 'all';

// ── Login ──
function selectRole(el, role) {
    document.querySelectorAll('.role-btn').forEach(b => b.classList.remove('selected'));
    el.classList.add('selected');
    currentRole = role;
}

async function doLogin() {
    const username = document.getElementById('login-user').value.trim();
    const password = document.getElementById('login-pass').value.trim();
    const role = currentRole;
    
    if (!username || !password) {
        showToast('Please enter username and password', 'error');
        return;
    }
    
    try {
        const formData = new FormData();
        formData.append('action', 'login');
        formData.append('username', username);
        formData.append('password', password);
        formData.append('role', role);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        
        if (data.success) {
            window.location.reload();
        } else {
            showToast(data.message || 'Invalid credentials', 'error');
        }
    } catch (error) {
        showToast('Login failed', 'error');
    }
}

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type === 'error' ? 'error' : ''}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

async function doLogout() {
    if (!confirm('Sign out?')) return;
    
    try {
        const formData = new FormData();
        formData.append('action', 'logout');
        
        await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        window.location.reload();
    } catch (error) {
        window.location.reload();
    }
}

function showLogoutConfirm() {
    if (confirm('Sign out of your account?')) doLogout();
}

// ── Navigation ──
function dirNav(el, pageId) {
    const links = document.querySelectorAll('#dir-sidebar .sidebar-link');
    links.forEach(l => l.classList.remove('active'));
    el.classList.add('active');
    document.querySelectorAll('#director-screen .section-page').forEach(p => p.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
    
    // Load data when navigating to specific pages
    if (pageId === 'dir-students') loadStudents();
    if (pageId === 'dir-teachers') loadTeachers();
    if (pageId === 'dir-grades') loadGradeStats();
    if (pageId === 'dir-attendance') loadAttendanceOverview();
    if (pageId === 'dir-exams') loadExams();
    if (pageId === 'dir-library') loadLibraryBooks();
    if (pageId === 'dir-finance') loadFinanceData();
    if (pageId === 'dir-announce') loadRecentAnnouncements();
}

// ── Dashboard Data Loading ──
async function loadDashboardStats() {
    try {
        const formData = new FormData();
        formData.append('action', 'get_stats');
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        
        if (document.getElementById('stat-students')) {
            document.getElementById('stat-students').textContent = data.total_students || '842';
            document.getElementById('stat-teachers').textContent = data.total_teachers || '54';
            document.getElementById('stat-attendance').textContent = (data.attendance_rate || '92.8') + '%';
            document.getElementById('stat-fee').textContent = (data.fee_collection || '79') + '%';
            
            document.getElementById('student-count-badge').textContent = '+' + (data.new_students || '8');
            document.getElementById('teacher-count-badge').textContent = data.total_teachers || '54';
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

async function loadAnnouncements() {
    try {
        const formData = new FormData();
        formData.append('action', 'get_announcements');
        formData.append('limit', 5);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const announcements = await response.json();
        
        const container = document.getElementById('announcements-list');
        if (container) {
            if (announcements.length === 0) {
                container.innerHTML = '<div class="ann-item">No announcements</div>';
            } else {
                container.innerHTML = announcements.map(ann => `
                    <div class="ann-item">
                        <div class="ann-title">${escapeHtml(ann.title)}</div>
                        <div class="ann-meta">📅 ${new Date(ann.created_at).toLocaleDateString()} · ${escapeHtml(ann.author_name)}</div>
                        <div style="font-size:12px;color:var(--text-mid);margin-top:4px;">${escapeHtml(ann.content.substring(0, 100))}${ann.content.length > 100 ? '...' : ''}</div>
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading announcements:', error);
    }
}

// ── Students Management ──
async function loadStudents() {
    const search = document.getElementById('student-search')?.value || '';
    const grade = document.getElementById('student-grade-filter')?.value || '';
    
    try {
        const formData = new FormData();
        formData.append('action', 'get_students');
        formData.append('search', search);
        formData.append('grade', grade);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const students = await response.json();
        
        const tbody = document.querySelector('#students-table tbody');
        if (tbody) {
            if (students.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align:center">No students found</td></tr>';
            } else {
                tbody.innerHTML = students.map(s => `
                    <tr>
                        <td>${escapeHtml(s.student_id)}</td>
                        <td>${escapeHtml(s.full_name)}</td>
                        <td>${escapeHtml(s.grade_name || 'N/A')}</td>
                        <td>${escapeHtml(s.section_name || 'A')}</td>
                        <td>${s.gpa || '3.5'}</td>
                        <td>${s.attendance_rate || '94'}%</td>
                        <td><span class="chip ${s.fee_status === 'paid' ? 'green' : (s.fee_status === 'partial' ? 'gold' : 'red')}">${s.fee_status === 'paid' ? 'Paid' : (s.fee_status === 'partial' ? 'Partial' : 'Pending')}</span></td>
                        <td><span class="view-all" onclick="viewStudent(${s.id})">View</span></td>
                    </tr>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading students:', error);
    }
}

function openEnrollModal() {
    const grade = prompt('Enter Grade (9-12):');
    const name = prompt('Enter Student Full Name:');
    if (name && grade) {
        enrollStudent(name, grade);
    }
}

async function enrollStudent(name, grade) {
    try {
        const formData = new FormData();
        formData.append('action', 'enroll_student');
        formData.append('full_name', name);
        formData.append('grade_id', grade);
        formData.append('section_id', 'A');
        formData.append('parent_name', '');
        formData.append('parent_phone', '');
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        
        if (data.success) {
            showToast(`Student enrolled successfully. ID: ${data.student_id}`);
            loadStudents();
        } else {
            showToast(data.message || 'Enrollment failed', 'error');
        }
    } catch (error) {
        showToast('Enrollment failed', 'error');
    }
}

// ── Teachers Management ──
async function loadTeachers() {
    try {
        const formData = new FormData();
        formData.append('action', 'get_teachers');
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const teachers = await response.json();
        
        const tbody = document.querySelector('#teachers-table tbody');
        if (tbody) {
            if (teachers.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" style="text-align:center">No teachers found</td></tr>';
            } else {
                tbody.innerHTML = teachers.map(t => `
                    <tr>
                        <td>${escapeHtml(t.teacher_id)}</td>
                        <td>${escapeHtml(t.full_name)}</td>
                        <td>${escapeHtml(t.subject_name || 'N/A')}</td>
                        <td>${escapeHtml(t.grades_taught || '9-12')}</td>
                        <td>${t.class_count || '4'}</td>
                        <td><span class="chip ${t.status === 'active' ? 'green' : (t.status === 'leave' ? 'gold' : 'red')}">${t.status === 'active' ? 'Active' : (t.status === 'leave' ? 'On Leave' : 'Absent')}</span></td>
                        <td><span class="view-all" onclick="viewTeacher(${t.id})">View</span></td>
                    </tr>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading teachers:', error);
    }
}

// ── Grades ──
async function loadGradeStats() {
    try {
        const formData = new FormData();
        formData.append('action', 'get_grade_stats');
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        
        if (data) {
            document.getElementById('avg-gpa').textContent = data.avg_gpa || '3.4';
            document.getElementById('honor-roll').textContent = data.honor_roll || '124';
            document.getElementById('at-risk').textContent = data.at_risk || '38';
            
            const chartContainer = document.getElementById('subject-grades-chart');
            if (chartContainer && data.subject_grades) {
                chartContainer.innerHTML = data.subject_grades.map(sg => `
                    <div class="grade-bar-wrap">
                        <div class="grade-bar-label"><span>${escapeHtml(sg.subject)}</span><span>${sg.avg_score}%</span></div>
                        <div class="grade-bar-bg"><div class="grade-bar-fill" style="width:${sg.avg_score}%;background:${sg.color || '#4a90d9'}"></div></div>
                    </div>
                `).join('');
            }
            
            const topStudentsTbody = document.querySelector('#top-students-table tbody');
            if (topStudentsTbody && data.top_students) {
                topStudentsTbody.innerHTML = data.top_students.map((s, i) => `
                    <tr>
                        <td>${i === 0 ? '🥇' : (i === 1 ? '🥈' : (i === 2 ? '🥉' : (i + 1)))} ${i + 1}</td>
                        <td>${escapeHtml(s.name)}</td>
                        <td>${escapeHtml(s.grade)}</td>
                        <td>${s.gpa}</td>
                    </tr>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading grade stats:', error);
    }
}

// ── Attendance ──
async function loadAttendanceOverview() {
    try {
        const formData = new FormData();
        formData.append('action', 'get_attendance_overview');
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        
        if (data) {
            document.getElementById('att-present').textContent = data.present_today || '779';
            document.getElementById('att-absent').textContent = data.absent_today || '63';
            document.getElementById('att-late').textContent = data.late_today || '12';
            document.getElementById('att-rate').textContent = (data.attendance_rate || '92.8') + '%';
            
            const tableBody = document.querySelector('#class-attendance-table tbody');
            if (tableBody && data.classes) {
                tableBody.innerHTML = data.classes.map(c => `
                    <tr>
                        <td>${escapeHtml(c.class_name)}</td>
                        <td>${escapeHtml(c.teacher_name)}</td>
                        <td>${c.present}</td>
                        <td>${c.absent}</td>
                        <td>${c.rate}%</td>
                        <td><span class="chip ${c.status === 'marked' ? 'green' : 'gold'}">${c.status === 'marked' ? 'Marked' : 'Pending'}</span></td>
                    </tr>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading attendance:', error);
    }
}

// ── Exams ──
async function loadExams() {
    try {
        const formData = new FormData();
        formData.append('action', 'get_exams');
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const exams = await response.json();
        
        const container = document.getElementById('exams-list');
        if (container) {
            if (exams.length === 0) {
                container.innerHTML = '<div class="card">No exams scheduled</div>';
            } else {
                container.innerHTML = exams.map(e => `
                    <div class="exam-card">
                        <div class="exam-date-box">
                            <div class="day">${new Date(e.exam_date).getDate()}</div>
                            <div class="month">${new Date(e.exam_date).toLocaleString('default', { month: 'short' }).toUpperCase()}</div>
                        </div>
                        <div class="exam-info">
                            <div class="exam-subject">${escapeHtml(e.grade_name || '')} — ${escapeHtml(e.subject_name)} ${escapeHtml(e.exam_type)}</div>
                            <div class="exam-detail">📍 ${escapeHtml(e.venue || 'Main Hall')} · ${e.start_time || '9:00 AM'} – ${e.end_time || '12:00 PM'}</div>
                        </div>
                        <span class="chip ${e.status === 'upcoming' ? 'blue' : 'green'}">${e.status === 'upcoming' ? 'Upcoming' : 'Completed'}</span>
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading exams:', error);
    }
}

// ── Library ──
async function loadLibraryBooks(search = '') {
    try {
        const formData = new FormData();
        formData.append('action', 'get_library_books');
        formData.append('search', search);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const books = await response.json();
        
        const container = document.getElementById('library-books-list');
        if (container) {
            if (books.length === 0) {
                container.innerHTML = '<div class="card">No books found</div>';
            } else {
                container.innerHTML = books.map(b => `
                    <div class="book-card">
                        <div class="book-spine" style="background:${b.color || '#4a90d9'}"></div>
                        <div>
                            <div class="book-title">${escapeHtml(b.title)}</div>
                            <div class="book-author">${escapeHtml(b.author)} · Available: ${b.available_copies}</div>
                        </div>
                        ${b.available_copies > 0 ? `<button class="btn-outline" style="margin-left:auto;padding:6px 14px;font-size:12px;" onclick="borrowBook(${b.id})">Borrow</button>` : `<span class="chip red" style="margin-left:auto">Checked Out</span>`}
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading library books:', error);
    }
}

async function borrowBook(bookId) {
    try {
        const formData = new FormData();
        formData.append('action', 'borrow_book');
        formData.append('book_id', bookId);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        
        if (data.success) {
            showToast(`Book borrowed! Due date: ${data.due_date}`);
            loadLibraryBooks();
        } else {
            showToast(data.message || 'Failed to borrow book', 'error');
        }
    } catch (error) {
        showToast('Failed to borrow book', 'error');
    }
}

// ── Finance ──
async function loadFinanceData() {
    try {
        const formData = new FormData();
        formData.append('action', 'get_finance_summary');
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        
        if (data.summary) {
            const total = data.summary.total_expected || 1066000;
            const collected = data.summary.total_paid || 842000;
            document.getElementById('fin-total').textContent = `ETB ${(total / 1000).toFixed(0)}K`;
            document.getElementById('fin-collected').textContent = `ETB ${(collected / 1000).toFixed(0)}K`;
            document.getElementById('fin-outstanding').textContent = `ETB ${((total - collected) / 1000).toFixed(0)}K`;
        }
        
        const tableBody = document.querySelector('#recent-payments-table tbody');
        if (tableBody && data.recent) {
            tableBody.innerHTML = data.recent.map(p => `
                <tr>
                    <td>${escapeHtml(p.full_name)}</td>
                    <td>${escapeHtml(p.student_id)}</td>
                    <td>ETB ${p.amount_paid || 0}</td>
                    <td>${p.payment_date ? new Date(p.payment_date).toLocaleDateString() : '—'}</td>
                    <td><span class="chip ${p.status === 'paid' ? 'green' : (p.status === 'partial' ? 'gold' : 'red')}">${p.status === 'paid' ? 'Paid' : (p.status === 'partial' ? 'Partial' : 'Pending')}</span></td>
                </tr>
            `).join('');
        }
    } catch (error) {
        console.error('Error loading finance data:', error);
    }
}

// ── Announcements ──
function selectAudience(el) {
    document.querySelectorAll('.ann-chip').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    selectedAudience = el.getAttribute('data-audience');
}

async function postAnnouncement() {
    const title = document.getElementById('ann-title')?.value;
    const content = document.getElementById('ann-content')?.value;
    
    if (!title || !content) {
        showToast('Please enter title and content', 'error');
        return;
    }
    
    try {
        const formData = new FormData();
        formData.append('action', 'post_announcement');
        formData.append('title', title);
        formData.append('content', content);
        formData.append('audience', selectedAudience);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        
        if (data.success) {
            showToast('Announcement posted successfully');
            document.getElementById('ann-title').value = '';
            document.getElementById('ann-content').value = '';
            loadAnnouncements();
            loadRecentAnnouncements();
        } else {
            showToast(data.message || 'Failed to post announcement', 'error');
        }
    } catch (error) {
        showToast('Failed to post announcement', 'error');
    }
}

async function loadRecentAnnouncements() {
    try {
        const formData = new FormData();
        formData.append('action', 'get_announcements');
        formData.append('limit', 5);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const announcements = await response.json();
        
        const container = document.getElementById('recent-announcements-list');
        if (container) {
            if (announcements.length === 0) {
                container.innerHTML = '<div class="ann-item">No announcements</div>';
            } else {
                container.innerHTML = announcements.map(ann => `
                    <div class="ann-item">
                        <div class="ann-title">${escapeHtml(ann.title)}</div>
                        <div class="ann-meta">📅 ${new Date(ann.created_at).toLocaleDateString()} · ${escapeHtml(ann.author_name)}</div>
                    </div>
                `).join('');
            }
        }
    } catch (error) {
        console.error('Error loading recent announcements:', error);
    }
}

// ── Reports ──
async function generateReport() {
    const reportType = document.getElementById('report-type')?.value;
    const fromDate = document.getElementById('report-from')?.value;
    const toDate = document.getElementById('report-to')?.value;
    
    showToast(`Generating ${reportType} report...`);
    // In production, this would trigger PDF generation on the server
    window.open(`/generate_report.php?type=${reportType}&from=${fromDate}&to=${toDate}`, '_blank');
}

function exportReport() {
    showToast('Exporting CSV...');
    // In production, this would trigger CSV download
}

// ── Settings ──
async function saveSettings() {
    const schoolName = document.getElementById('school-name')?.value;
    const academicYear = document.getElementById('academic-year')?.value;
    
    try {
        const formData = new FormData();
        formData.append('action', 'save_settings');
        formData.append('school_name', schoolName);
        formData.append('academic_year', academicYear);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        
        if (data.success) {
            showToast('Settings saved successfully');
        } else {
            showToast(data.message || 'Failed to save settings', 'error');
        }
    } catch (error) {
        showToast('Failed to save settings', 'error');
    }
}

async function updatePassword() {
    const currentPwd = document.getElementById('current-pwd')?.value;
    const newPwd = document.getElementById('new-pwd')?.value;
    const confirmPwd = document.getElementById('confirm-pwd')?.value;
    
    if (!currentPwd || !newPwd) {
        showToast('Please enter current and new password', 'error');
        return;
    }
    
    if (newPwd !== confirmPwd) {
        showToast('New passwords do not match', 'error');
        return;
    }
    
    try {
        const formData = new FormData();
        formData.append('action', 'update_password');
        formData.append('current_password', currentPwd);
        formData.append('new_password', newPwd);
        
        const response = await fetch(window.location.href, {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const data = await response.json();
        
        if (data.success) {
            showToast('Password updated successfully');
            document.getElementById('current-pwd').value = '';
            document.getElementById('new-pwd').value = '';
            document.getElementById('confirm-pwd').value = '';
        } else {
            showToast(data.message || 'Failed to update password', 'error');
        }
    } catch (error) {
        showToast('Failed to update password', 'error');
    }
}

// ── Utility Functions ──
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function loadAllAnnouncements() {
    dirNav(document.querySelector('#dir-sidebar .sidebar-link[onclick*="dir-announce"]'), 'dir-announce');
}

function viewStudent(id) {
    showToast(`Viewing student details (ID: ${id})`);
}

function viewTeacher(id) {
    showToast(`Viewing teacher details (ID: ${id})`);
}

function openAddTeacherModal() {
    const name = prompt('Enter Teacher Full Name:');
    if (name) {
        showToast(`Adding teacher: ${name}`);
    }
}

// ── Initial Load ──
if (document.getElementById('director-screen') && document.getElementById('director-screen').classList.contains('active')) {
    loadDashboardStats();
    loadAnnouncements();
    loadStudents();
    loadTeachers();
    loadGradeStats();
    loadAttendanceOverview();
    loadExams();
    loadLibraryBooks();
    loadFinanceData();
    loadRecentAnnouncements();
}

// Schedule grid load
async function loadSchedule() {
    const container = document.getElementById('schedule-grid');
    if (container) {
        container.innerHTML = `
            <div class="sched-header">Time</div>
            <div class="sched-header">Mon</div><div class="sched-header">Tue</div>
            <div class="sched-header">Wed</div><div class="sched-header">Thu</div><div class="sched-header">Fri</div>
            <div class="sched-time">8:00–9:00</div>
            <div class="sched-cell has-class"><div class="sched-subject">Math</div><div class="sched-room">Room 101</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">Physics</div><div class="sched-room">Lab A</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">English</div><div class="sched-room">Room 204</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">Math</div><div class="sched-room">Room 101</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">Biology</div><div class="sched-room">Lab B</div></div>
            <div class="sched-time">9:00–10:00</div>
            <div class="sched-cell has-class"><div class="sched-subject">English</div><div class="sched-room">Room 204</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">Chemistry</div><div class="sched-room">Lab C</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">Math</div><div class="sched-room">Room 101</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">Physics</div><div class="sched-room">Lab A</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">History</div><div class="sched-room">Room 305</div></div>
            <div class="sched-time">10:00–10:20</div>
            <div class="sched-cell" style="grid-column:span 5;text-align:center;color:var(--text-light);font-size:13px;">☕ Break</div>
            <div class="sched-time">10:20–11:20</div>
            <div class="sched-cell has-class"><div class="sched-subject">Biology</div><div class="sched-room">Lab B</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">History</div><div class="sched-room">Room 305</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">Chemistry</div><div class="sched-room">Lab C</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">English</div><div class="sched-room">Room 204</div></div>
            <div class="sched-cell has-class"><div class="sched-subject">Math</div><div class="sched-room">Room 101</div></div>
        `;
    }
}
loadSchedule();

function loadNotifications() {
    showToast('You have 3 new notifications');
}

function loadActivity() {
    const container = document.getElementById('activity-list');
    if (container) {
        container.innerHTML = `
            <div class="activity-item"><div class="activity-dot"></div><div><div class="activity-text">Attendance marked for Grade 11A — 38/40 present</div><div class="activity-time">Today 9:00 AM</div></div></div>
            <div class="activity-item"><div class="activity-dot yellow"></div><div><div class="activity-text">New student enrolled: Selam Bekele (Grade 11B)</div><div class="activity-time">Today 8:15 AM</div></div></div>
            <div class="activity-item"><div class="activity-dot"></div><div><div class="activity-text">Mid-term grades submitted by 12 teachers</div><div class="activity-time">Yesterday 4:50 PM</div></div></div>
            <div class="activity-item"><div class="activity-dot yellow"></div><div><div class="activity-text">Library: 14 books borrowed, 6 returned</div><div class="activity-time">Yesterday 2:15 PM</div></div></div>
            <div class="activity-item"><div class="activity-dot"></div><div><div class="activity-text">Staff meeting minutes uploaded to system</div><div class="activity-time">Nov 12, 10:30 AM</div></div></div>
        `;
    }
}
loadActivity();

function loadEnrollmentTrend() {
    const container = document.getElementById('enrollment-trend');
    if (container) {
        container.innerHTML = `
            <div class="grade-bar-wrap"><div class="grade-bar-label"><span>Grade 9</span><span>215</span></div><div class="grade-bar-bg"><div class="grade-bar-fill" style="width:100%;background:#4a90d9"></div></div></div>
            <div class="grade-bar-wrap"><div class="grade-bar-label"><span>Grade 10</span><span>208</span></div><div class="grade-bar-bg"><div class="grade-bar-fill" style="width:97%;background:var(--green-light)"></div></div></div>
            <div class="grade-bar-wrap"><div class="grade-bar-label"><span>Grade 11</span><span>225</span></div><div class="grade-bar-bg"><div class="grade-bar-fill" style="width:100%;background:var(--gold)"></div></div></div>
            <div class="grade-bar-wrap"><div class="grade-bar-label"><span>Grade 12</span><span>194</span></div><div class="grade-bar-bg"><div class="grade-bar-fill" style="width:90%;background:#a78bfa"></div></div></div>
        `;
    }
}
loadEnrollmentTrend();
</script>
</body>
</html>