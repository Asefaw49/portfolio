<?php
session_start();
require_once 'config.php';

// Require login to access this page
requireLogin();

$conn = mysqli_connect("localhost", "root", "", "mesob_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['submit'])){
    $date = mysqli_real_escape_string($conn, $_POST['report_date']);
    $ethiopian_date = $date;
    $employee = mysqli_real_escape_string($conn, $_POST['employee_name']);
    $branch = mysqli_real_escape_string($conn, $_POST['branch']);
    
    $organizations = $_POST['organization'];
    $service_types = $_POST['service_type'];
    $service_given = $_POST['service_given'];
    $service_not_complete = $_POST['service_not_complete'];
    
    // Calculate totals
    $total_given = array_sum($service_given);
    $total_not_complete = array_sum($service_not_complete);
    $grand_total = $total_given + $total_not_complete;
    
    // Get or create branch ID
    $branch_query = "SELECT branch_id FROM branches WHERE branch_code = '$branch' OR branch_name = '$branch' LIMIT 1";
    $branch_result = mysqli_query($conn, $branch_query);
    if(mysqli_num_rows($branch_result) > 0) {
        $branch_row = mysqli_fetch_assoc($branch_result);
        $branch_id = $branch_row['branch_id'];
    } else {
        $insert_branch = "INSERT INTO branches (branch_code, branch_name) VALUES ('$branch', '$branch')";
        mysqli_query($conn, $insert_branch);
        $branch_id = mysqli_insert_id($conn);
    }
    
    // Get or create employee ID
    $emp_query = "SELECT employee_id FROM employees WHERE full_name = '$employee' LIMIT 1";
    $emp_result = mysqli_query($conn, $emp_query);
    if(mysqli_num_rows($emp_result) > 0) {
        $emp_row = mysqli_fetch_assoc($emp_result);
        $employee_id = $emp_row['employee_id'];
    } else {
        $insert_emp = "INSERT INTO employees (employee_code, full_name, branch_id) VALUES ('EMP" . rand(1000,9999) . "', '$employee', '$branch_id')";
        mysqli_query($conn, $insert_emp);
        $employee_id = mysqli_insert_id($conn);
    }
    
    $success_count = 0;
    
    // Insert each service record
    for($i = 0; $i < count($organizations); $i++) {
        $org = mysqli_real_escape_string($conn, $organizations[$i]);
        $service = mysqli_real_escape_string($conn, $service_types[$i]);
        $given = (int)$service_given[$i];
        $not_complete = (int)$service_not_complete[$i];
        $total = $given + $not_complete;
        
        // Get or create organization ID
        $org_query = "SELECT organization_id FROM organizations WHERE organization_name = '$org' LIMIT 1";
        $org_result = mysqli_query($conn, $org_query);
        if(mysqli_num_rows($org_result) > 0) {
            $org_row = mysqli_fetch_assoc($org_result);
            $org_id = $org_row['organization_id'];
        } else {
            $insert_org = "INSERT INTO organizations (organization_name) VALUES ('$org')";
            mysqli_query($conn, $insert_org);
            $org_id = mysqli_insert_id($conn);
        }
        
        // Get or create service type ID
        $serv_query = "SELECT service_id FROM service_types WHERE service_name = '$service' LIMIT 1";
        $serv_result = mysqli_query($conn, $serv_query);
        if(mysqli_num_rows($serv_result) > 0) {
            $serv_row = mysqli_fetch_assoc($serv_result);
            $service_id = $serv_row['service_id'];
        } else {
            $insert_service = "INSERT INTO service_types (service_name) VALUES ('$service')";
            mysqli_query($conn, $insert_service);
            $service_id = mysqli_insert_id($conn);
        }
        
        $report_date_formatted = date('Y-m-d', strtotime(str_replace('/', '-', $date)));
        
        $query = "INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, 
                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) 
                  VALUES ('$report_date_formatted', '$ethiopian_date', '$employee_id', '$employee', '$branch_id', '$branch', 
                  '$org_id', '$org', '$service_id', '$service', $given, $not_complete, $total)";
        
        if(mysqli_query($conn, $query)) {
            $success_count++;
        }
    }
    
    // Insert summary record
    $summary_query = "INSERT INTO report_summaries (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, 
                      total_services_given, total_services_not_complete, grand_total, total_organizations_served) 
                      VALUES ('$report_date_formatted', '$ethiopian_date', '$employee_id', '$employee', '$branch_id', '$branch', 
                      $total_given, $total_not_complete, $grand_total, $success_count)";
    mysqli_query($conn, $summary_query);
    
    // Log activity
    logActivity($conn, $_SESSION['user_id'], 'report_submitted', "Submitted daily report for $date with $grand_total total services");
    
    if($success_count > 0) {
        echo "<script>
            alert('✅ Daily Report Submitted Successfully!\\n\\n📅 Date: $date\\n👤 Employee: $employee\\n🏢 Branch: $branch\\n📊 Total Services: $grand_total\\n✅ Given: $total_given\\n⚠️ Incomplete: $total_not_complete');
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MESOB Daily Report - Welcome <?php echo htmlspecialchars($_SESSION['full_name']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: #edf2f7;
            padding: 20px;
        }

        .container {
            width: 98%;
            margin: auto;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .header {
            background: #1f3b57;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .header h1 {
            font-size: 32px;
        }

        .user-info {
            background: #f8fafc;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ddd;
        }

        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 8px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: 500;
            transition: 0.3s;
        }

        .logout-btn:hover {
            background: #c82333;
        }

        /* Rest of your existing CSS styles here */
        .top-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            padding: 20px;
            background: #f8fafc;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            margin-bottom: 7px;
            font-weight: 600;
            color: #1f3b57;
        }

        .form-group input, .form-group select {
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        .table-container {
            overflow-x: auto;
            padding: 20px;
            max-height: 500px;
            overflow-y: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1100px;
        }

        table thead {
            background: #d9c5c5;
            position: sticky;
            top: 0;
        }

        table th {
            padding: 15px;
            border: 1px solid #999;
            text-align: center;
            font-size: 15px;
            background: #d9c5c5;
            font-weight: 600;
        }

        table td {
            border: 1px solid #ccc;
            padding: 8px;
        }

        table td input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            outline: none;
            font-size: 14px;
        }

        .summary {
            display: flex;
            justify-content: flex-end;
            gap: 20px;
            padding: 20px;
            flex-wrap: wrap;
        }

        .summary-box {
            background: #1f3b57;
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            text-align: center;
            min-width: 180px;
        }

        .summary-box h3 {
            font-size: 14px;
            margin-bottom: 5px;
        }

        .summary-box span {
            font-size: 24px;
            font-weight: bold;
        }

        .button-area {
            text-align: center;
            padding: 25px;
        }

        button {
            padding: 14px 30px;
            border: none;
            background: #1f3b57;
            color: white;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: 0.3s;
            font-weight: 500;
        }

        button:hover {
            background: #355f86;
            transform: translateY(-2px);
        }

        .footer {
            text-align: center;
            padding: 15px;
            color: #666;
            font-size: 14px;
            border-top: 1px solid #eee;
        }
    </style>
</head>

<body>
<div class="container">
    <div class="header">
        <h1>📋 Addis MESOB HQ Universal Service Daily Report</h1>
        <p>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</p>
    </div>

    <div class="user-info">
        <div>👤 Logged in as: <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong> | Role: <?php echo ucfirst($_SESSION['role']); ?></div>
        <a href="logout.php" class="logout-btn">🚪 Logout</a>
    </div>

    <form method="POST">
        <div class="top-form">
            <div class="form-group">
                <label>📅 Report Date (Ethiopian)</label>
                <input type="text" name="report_date" placeholder="e.g., 20/09/2018" value="20/09/2018" required>
            </div>
            <div class="form-group">
                <label>👤 Employee Name</label>
                <input type="text" name="employee_name" placeholder="Enter Employee Name" value="Wendmu" required>
            </div>
            <div class="form-group">
                <label>🏢 Branch</label>
                <select name="branch" required>
                    <option value="A-MESOB">A-MESOB</option>
                    <option value="B-MESOB">B-MESOB</option>
                    <option value="Head Office">Head Office</option>
                </select>
            </div>
        </div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>S.N</th>
                        <th>Organization</th>
                        <th>Service Type</th>
                        <th>Service Given</th>
                        <th>Service Not Complete<br><small>(Missing Documents)</small></th>
                        <th>Total Service Given</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $services = [
                        ['org' => 'እሽተሽ', 'service' => 'የመንጃ ፈቃድ እድሳት', 'given' => 2, 'not_complete' => 1],
                        ['org' => 'እሽተሽ', 'service' => 'የበሎ እድሳት', 'given' => 7, 'not_complete' => 2],
                        ['org' => 'ጤና ቢሮ', 'service' => 'ጤና ምርመራ(ሜዳካል)', 'given' => 7, 'not_complete' => 1],
                        ['org' => 'ቤቶች ልማት አስተዳደር', 'service' => 'የመንግስት ቤት ውል እድሳት', 'given' => 1, 'not_complete' => 1],
                        ['org' => 'ንግድ ቢሮ', 'service' => 'ንግድ ፈቃድ ማደስ', 'given' => 0, 'not_complete' => 0],
                        ['org' => 'ንግድ ቢሮ', 'service' => 'የንግድ ስራ ፈቃድ', 'given' => 1, 'not_complete' => 1],
                        ['org' => 'ግንባታ ፈቃድ', 'service' => 'የፕላን ስምምነት', 'given' => 0, 'not_complete' => 0],
                        ['org' => 'የሲቪል ምዝገባ', 'service' => 'የልደት ሰርቲፍኬት ማረጋገጥ', 'given' => 0, 'not_complete' => 0],
                        ['org' => 'የሲቪል ምዝገባ', 'service' => 'መታወቂያ እድሳት', 'given' => 0, 'not_complete' => 0],
                        ['org' => 'ሲቪል ምዝገባ', 'service' => 'የጋብቻ', 'given' => 0, 'not_complete' => 0]
                    ];
                    
                    $sn = 1;
                    foreach($services as $service){
                    ?>
                    <tr>
                        <td style="text-align:center; font-weight:bold;"><?php echo $sn; ?></td>
                        <td><input type="text" name="organization[]" value="<?php echo htmlspecialchars($service['org']); ?>" required></td>
                        <td><input type="text" name="service_type[]" value="<?php echo htmlspecialchars($service['service']); ?>" required></td>
                        <td><input type="number" class="given" name="service_given[]" value="<?php echo $service['given']; ?>" min="0" required></td>
                        <td><input type="number" class="notcomplete" name="service_not_complete[]" value="<?php echo $service['not_complete']; ?>" min="0" required></td>
                        <td><input type="number" class="total" readonly style="background:#f0f0f0; font-weight:bold;"></td>
                    </tr>
                    <?php
                    $sn++;
                    }
                    ?>
                </tbody>
            点化
        </div>

        <div class="summary">
            <div class="summary-box">
                <h3>✅ Total Service Given</h3>
                <span id="totalGiven">0</span>
            </div>
            <div class="summary-box">
                <h3>⚠️ Total Not Complete</h3>
                <span id="totalNot">0</span>
            </div>
            <div class="summary-box">
                <h3>📊 Grand Total</h3>
                <span id="grandTotal">0</span>
            </div>
        </div>

        <div class="button-area">
            <button type="submit" name="submit">📤 Submit Daily Report</button>
            <button type="button" onclick="resetForm()" style="background:#6c757d;">⟳ Reset Form</button>
        </div>
    </form>

    <div class="footer">
        Addis MESOB HQ Universal Service Reporting System | Powered by MESOB
    </div>
</div>

<script>
function calculateTotals(){
    let givenInputs = document.querySelectorAll('.given');
    let notInputs = document.querySelectorAll('.notcomplete');
    let totalInputs = document.querySelectorAll('.total');
    
    let totalGiven = 0;
    let totalNot = 0;
    let grandTotal = 0;
    
    for(let i=0; i<givenInputs.length; i++){
        let given = parseInt(givenInputs[i].value) || 0;
        let notComplete = parseInt(notInputs[i].value) || 0;
        let total = given + notComplete;
        
        totalInputs[i].value = total;
        
        totalGiven += given;
        totalNot += notComplete;
        grandTotal += total;
    }
    
    document.getElementById('totalGiven').innerText = totalGiven;
    document.getElementById('totalNot').innerText = totalNot;
    document.getElementById('grandTotal').innerText = grandTotal;
}

function resetForm(){
    if(confirm('Are you sure you want to reset all values?')){
        let givenInputs = document.querySelectorAll('.given');
        let notInputs = document.querySelectorAll('.notcomplete');
        
        <?php
        $reset_values_given = array_column($services, 'given');
        $reset_values_not = array_column($services, 'not_complete');
        ?>
        
        let originalGiven = [<?php echo implode(',', $reset_values_given); ?>];
        let originalNot = [<?php echo implode(',', $reset_values_not); ?>];
        
        for(let i=0; i<givenInputs.length; i++){
            givenInputs[i].value = originalGiven[i];
            notInputs[i].value = originalNot[i];
        }
        
        calculateTotals();
    }
}

document.querySelectorAll('.given, .notcomplete').forEach(input => {
    input.addEventListener('input', calculateTotals);
});

calculateTotals();
</script>

</body>
</html>

<?php mysqli_close($conn); ?>