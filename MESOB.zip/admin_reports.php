<?php
session_start();
require_once 'config.php';

// Require admin access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$conn = mysqli_connect("localhost", "root", "", "mesob_db");
if (!$conn) die("Connection failed");

// Handle Excel Export
if (isset($_GET['export_excel'])) {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="all_mesob_reports_' . date('Y-m-d') . '.xls"');
    header('Cache-Control: max-age=0');
    
    $export_query = "SELECT * FROM daily_reports ORDER BY report_id DESC";
    $export_result = mysqli_query($conn, $export_query);
    
    echo '<table border="1">';
    echo '<tr>';
    echo '<th>ID</th><th>Date (Ethiopian)</th><th>Employee Name</th><th>Branch</th>';
    echo '<th>Organization</th><th>Service Type</th><th>Service Given</th>';
    echo '<th>Service Not Complete</th><th>Total Service</th><th>Report Date</th><th>Submitted At</th>';
    echo '</tr>';
    
    while($row = mysqli_fetch_assoc($export_result)) {
        echo '<tr>';
        echo '<td>' . $row['report_id'] . '</td>';
        echo '<td>' . htmlspecialchars($row['ethiopian_date']) . '</td>';
        echo '<td>' . htmlspecialchars($row['employee_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['branch_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['organization_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['service_type_name']) . '</td>';
        echo '<td>' . $row['service_given'] . '</td>';
        echo '<td>' . $row['service_not_complete'] . '</td>';
        echo '<td>' . $row['total_service'] . '</td>';
        echo '<td>' . $row['report_date'] . '</td>';
        echo '<td>' . $row['submitted_at'] . '</td>';
        echo '</tr>';
    }
    echo '</table>';
    exit();
}

$user_name = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin';
$reports = mysqli_query($conn, "SELECT * FROM daily_reports ORDER BY report_id DESC LIMIT 200");
$total_reports = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM daily_reports"))['c'];
$total_services = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_service) as s FROM daily_reports"))['s'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - View All Reports</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
      <style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#edf2f7;
    padding:5px;
    font-size:12px;
}

.container{
    max-width:1400px;
    margin:auto;
    background:#fff;
    border-radius:4px;
    overflow:hidden;
    box-shadow:0 1px 4px rgba(0,0,0,.08);
}

.header{
    background:#1f3b57;
    color:#fff;
    padding:8px;
    text-align:center;
}

.header h1{
    font-size:18px;
    margin-bottom:2px;
}

.header p{
    font-size:11px;
}

.nav-bar{
    background:#f8fafc;
    padding:4px 8px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
}

.nav-links{
    display:flex;
    gap:4px;
    flex-wrap:wrap;
}

.nav-links a{
    color:#1f3b57;
    text-decoration:none;
    padding:4px 8px;
    border-radius:3px;
    font-size:11px;
    transition:.2s;
}

.nav-links a:hover{
    background:#1f3b57;
    color:#fff;
}

.role-badge{
    background:#dc3545;
    color:#fff;
    padding:2px 8px;
    border-radius:10px;
    font-size:10px;
    font-weight:600;
}

.logout-btn{
    background:#dc3545;
    color:#fff;
    padding:4px 8px;
    border-radius:3px;
    text-decoration:none;
    font-size:11px;
}

.export-btn{
    background:#007bff;
    color:#fff;
    padding:4px 8px;
    border-radius:3px;
    text-decoration:none;
    font-size:11px;
}

.export-btn:hover{
    background:#0056b3;
}

.warning-box{
    background:#fff3cd;
    color:#856404;
    padding:5px 8px;
    margin:5px;
    border-radius:3px;
    border-left:2px solid #ffc107;
    font-size:11px;
}

.stats{
    display:flex;
    gap:5px;
    padding:5px;
    background:#f8fafc;
    flex-wrap:wrap;
}

.stat-card{
    background:#fff;
    padding:6px 10px;
    border-radius:4px;
    box-shadow:0 1px 2px rgba(0,0,0,.08);
    min-width:120px;
}

.stat-card h3{
    font-size:11px;
    margin-bottom:2px;
}

.stat-card .number{
    font-size:18px;
    font-weight:bold;
    color:#1f3b57;
}

.search-box{
    margin:5px;
    display:flex;
    gap:4px;
}

.search-box input{
    padding:4px 8px;
    border:1px solid #ddd;
    border-radius:3px;
    width:220px;
    font-size:11px;
}

.table-container{
    overflow-x:auto;
    overflow-y:auto;
    padding:5px;
    max-height:500px;
}

table{
    width:100%;
    border-collapse:collapse;
    font-size:10px;
}

thead th{
    background:#d9c5c5;
    position:sticky;
    top:0;
    z-index:10;
}

th{
    padding:3px 4px;
    border:1px solid #999;
    text-align:center;
    white-space:nowrap;
    height:24px;
    font-size:10px;
}

td{
    padding:2px 4px;
    border:1px solid #ccc;
    text-align:center;
    white-space:nowrap;
    height:22px;
    font-size:10px;
}

tbody tr:nth-child(even){
    background:#fafafa;
}

tbody tr:hover{
    background:#eef5ff;
}

.footer{
    text-align:center;
    padding:6px;
    color:#666;
    border-top:1px solid #eee;
    font-size:10px;
}

/* Extra Compact on Small Screens */
@media (max-width:768px){

    .header h1{
        font-size:15px;
    }

    .nav-links a,
    .logout-btn,
    .export-btn{
        font-size:10px;
        padding:3px 6px;
    }

    .search-box input{
        width:100%;
    }

    table{
        font-size:9px;
    }

    th,
    td{
        padding:2px;
        height:18px;
    }
}
</style>
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>👑 Admin - All Reports</h1>
        <p>View Only Mode - Export Available</p>
    </div>
    <div class="nav-bar">
        <div class="nav-links">
            <a href="admin_dashboard.php">📊 Dashboard</a>
            <a href="admin_reports.php">📋 All Reports</a>
            <a href="reports_summary.php">📈 Summary</a>
            <a href="manage_users.php">👥 Manage Users</a>
            <a href="?export_excel=1" class="export-btn">📎 Export All to Excel</a>
        </div>
        <div>
            <span class="role-badge">ADMIN</span>
            <span style="margin:0 10px">👤 <?php echo htmlspecialchars($user_name); ?></span>
            <a href="logout.php" class="logout-btn">🚪 Logout</a>
        </div>
    </div>

    <div class="warning-box">
        🔒 <strong>READ ONLY:</strong> You are in View Only mode. Use Export button to download reports.
    </div>

    <div class="stats">
        <div class="stat-card"><h3>Total Reports</h3><div class="number"><?php echo $total_reports; ?></div></div>
        <div class="stat-card"><h3>Total Services</h3><div class="number"><?php echo number_format($total_services ?: 0); ?></div></div>
    </div>

    <div class="search-box">
        <input type="text" id="searchInput" placeholder="🔍 Search reports..." onkeyup="searchTable()">
    </div>

    <div class="table-container">
        <table id="reportTable">
            <thead>
                <tr>
                    <th>ID</th><th>Date</th><th>Employee</th><th>Branch</th>
                    <th>Organization</th><th>Service</th><th>Given</th><th>Missing</th><th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($reports)){ ?>
                <tr>
                    <td><?php echo $row['report_id']; ?></td>
                    <td><?php echo $row['ethiopian_date']; ?></td>
                    <td><?php echo htmlspecialchars($row['employee_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['branch_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['organization_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['service_type_name']); ?></td>
                    <td><?php echo $row['service_given']; ?></td>
                    <td><?php echo $row['service_not_complete']; ?></td>
                    <td><strong><?php echo $row['total_service']; ?></strong></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <div class="footer">MESOB HQ | Admin View Only | Total: <?php echo $total_reports; ?> reports</div>
</div>

<script>
function searchTable() {
    let input = document.getElementById("searchInput");
    let filter = input.value.toUpperCase();
    let table = document.getElementById("reportTable");
    let tr = table.getElementsByTagName("tr");
    
    for (let i = 1; i < tr.length; i++) {
        let tdArray = tr[i].getElementsByTagName("td");
        let found = false;
        for (let j = 0; j < tdArray.length; j++) {
            if (tdArray[j]) {
                let textValue = tdArray[j].textContent || tdArray[j].innerText;
                if (textValue.toUpperCase().indexOf(filter) > -1) {
                    found = true;
                    break;
                }
            }
        }
        tr[i].style.display = found ? "" : "none";
    }
}
</script>
</body>
</html>
<?php mysqli_close($conn); ?>