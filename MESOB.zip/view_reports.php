<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Block admin - redirect to admin view
if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    header("Location: admin_reports.php");
    exit();
}

$conn = mysqli_connect("localhost", "root", "", "mesob_db");
if (!$conn) die("Connection failed");

// Handle Excel Export
if (isset($_GET['export_excel'])) {
    // Set headers for Excel download
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="mesob_reports_' . date('Y-m-d') . '.xls"');
    header('Cache-Control: max-age=0');
    
    // Get all reports for export (no limit)
    $export_query = "SELECT * FROM daily_reports ORDER BY report_id DESC";
    $export_result = mysqli_query($conn, $export_query);
    
    // Create HTML table for Excel
    echo '<table border="1">';
    echo '<tr>';
    echo '<th>ID</th>';
    echo '<th>Date (Ethiopian)</th>';
    echo '<th>Employee Name</th>';
    echo '<th>Branch</th>';
    echo '<th>Organization</th>';
    echo '<th>Service Type</th>';
    echo '<th>Service Given</th>';
    echo '<th>Service Not Complete</th>';
    echo '<th>Total Service</th>';
    echo '<th>Report Date</th>';
    echo '<th>Submitted At</th>';
    echo '</tr>';
    
    while($row = mysqli_fetch_assoc($export_result)) {
        echo '<tr>';
        echo '<td>' . $row['report_id'] . '</td>';
        echo '<td>' . htmlspecialchars($row['ethiopian_date']) . '</td>';
        echo '<td>' . htmlspecialchars($row['employee_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['branch_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['organization_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['service_type_name']) . '</td>';
        echo '<td>' . $row['service_given'] . '</td>';
        echo '<td>' . $row['service_not_complete'] . '</td>';
        echo '<td>' . $row['total_service'] . '</td>';
        echo '<td>' . $row['report_date'] . '</td>';
        echo '<td>' . $row['submitted_at'] . '</td>';
        echo '</tr>';
    }
    echo '</table>';
    exit();
}

$user_name = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Staff';
$reports = mysqli_query($conn, "SELECT * FROM daily_reports ORDER BY report_id DESC LIMIT 100");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff - View Reports</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;}
        body{background:#edf2f7;padding:20px;}
        .container{max-width:1400px;margin:auto;background:white;border-radius:10px;overflow:hidden;}
        .header{background:#28a745;color:white;padding:15px;text-align:center;}
        .nav-bar{background:#f8fafc;padding:10px 20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;}
        .nav-links{display:flex;gap:10px;flex-wrap:wrap;}
        .nav-links a{color:#28a745;text-decoration:none;padding:6px 15px;border-radius:5px;transition:0.3s;}
        .nav-links a:hover{background:#28a745;color:white;}
        .role-badge{background:#28a745;color:white;padding:4px 12px;border-radius:20px;}
        .logout-btn{background:#dc3545;color:white;padding:6px 15px;border-radius:5px;text-decoration:none;}
        .export-btn{background:#007bff;color:white;padding:6px 15px;border-radius:5px;text-decoration:none;margin-left:10px;}
        .export-btn:hover{background:#0056b3;}
        .table-container{overflow-x:auto;padding:15px;max-height:500px;overflow-y:auto;}
        table{width:100%;border-collapse:collapse;font-size:12px;}
        th{background:#d9c5c5;padding:10px;border:1px solid #999;position:sticky;top:0;}
        td{padding:8px;border:1px solid #ccc;text-align:center;}
        .footer{text-align:center;padding:15px;color:#666;border-top:1px solid #eee;}
        .search-box{margin:15px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;}
        .search-box input{padding:8px;border:1px solid #ddd;border-radius:5px;width:250px;}
        .search-box button{padding:8px 15px;background:#28a745;color:white;border:none;border-radius:5px;cursor:pointer;}
        .filter-group{display:flex;gap:10px;flex-wrap:wrap;}
        @media(max-width:768px){
            .nav-bar{flex-direction:column;gap:10px;}
            .search-box{flex-direction:column;}
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>📋 My Reports</h1>
        <p>View and Export Your Submitted Reports</p>
    </div>
    <div class="nav-bar">
        <div class="nav-links">
            <a href="mesob.php">📝 New Report</a>
            <a href="view_reports.php">📊 View Reports</a>
            <a href="reports_summary.php">📈 Summary</a>
            <a href="?export_excel=1" class="export-btn">📎 Export to Excel</a>
        </div>
        <div>
            <span class="role-badge">STAFF</span>
            <span style="margin:0 10px">👤 <?php echo htmlspecialchars($user_name); ?></span>
            <a href="logout.php" class="logout-btn">🚪 Logout</a>
        </div>
    </div>

    <!-- Search/Filter Section -->
    <div class="search-box">
        <input type="text" id="searchInput" placeholder="🔍 Search by Employee, Branch, Organization..." onkeyup="searchTable()">
        <div class="filter-group">
            <select id="filterBranch" onchange="filterTable()">
                <option value="">All Branches</option>
                <?php
                $branches = mysqli_query($conn, "SELECT DISTINCT branch_name FROM daily_reports");
                while($branch = mysqli_fetch_assoc($branches)) {
                    echo "<option value='" . htmlspecialchars($branch['branch_name']) . "'>" . htmlspecialchars($branch['branch_name']) . "</option>";
                }
                ?>
            </select>
            <select id="filterEmployee" onchange="filterTable()">
                <option value="">All Employees</option>
                <?php
                $employees = mysqli_query($conn, "SELECT DISTINCT employee_name FROM daily_reports");
                while($emp = mysqli_fetch_assoc($employees)) {
                    echo "<option value='" . htmlspecialchars($emp['employee_name']) . "'>" . htmlspecialchars($emp['employee_name']) . "</option>";
                }
                ?>
            </select>
            <button onclick="clearFilters()">Clear Filters</button>
        </div>
    </div>

    <div class="table-container">
        <table id="reportTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Employee</th>
                    <th>Branch</th>
                    <th>Organization</th>
                    <th>Service</th>
                    <th>Given</th>
                    <th>Missing</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody id="tableBody">
                <?php while($row = mysqli_fetch_assoc($reports)){ ?>
                <tr>
                    <td><?php echo $row['report_id']; ?></td>
                    <td><?php echo $row['ethiopian_date']; ?></td>
                    <td class="employee-name"><?php echo htmlspecialchars($row['employee_name']); ?></td>
                    <td class="branch-name"><?php echo htmlspecialchars($row['branch_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['organization_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['service_type_name']); ?></td>
                    <td><?php echo $row['service_given']; ?></td>
                    <td><?php echo $row['service_not_complete']; ?></td>
                    <td><strong><?php echo $row['total_service']; ?></strong></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <div class="footer">
        MESOB HQ | Staff - Create & View Reports | Total Records: <?php echo mysqli_num_rows($reports); ?>
    </div>
</div>

<script>
// Search function
function searchTable() {
    let input = document.getElementById("searchInput");
    let filter = input.value.toUpperCase();
    let table = document.getElementById("reportTable");
    let tr = table.getElementsByTagName("tr");
    
    for (let i = 1; i < tr.length; i++) {
        let tdArray = tr[i].getElementsByTagName("td");
        let found = false;
        for (let j = 0; j < tdArray.length; j++) {
            if (tdArray[j]) {
                let textValue = tdArray[j].textContent || tdArray[j].innerText;
                if (textValue.toUpperCase().indexOf(filter) > -1) {
                    found = true;
                    break;
                }
            }
        }
        tr[i].style.display = found ? "" : "none";
    }
}

// Filter by branch and employee
function filterTable() {
    let branchFilter = document.getElementById("filterBranch").value;
    let employeeFilter = document.getElementById("filterEmployee").value;
    let table = document.getElementById("reportTable");
    let tr = table.getElementsByTagName("tr");
    
    for (let i = 1; i < tr.length; i++) {
        let branchCell = tr[i].getElementsByClassName("branch-name")[0];
        let employeeCell = tr[i].getElementsByClassName("employee-name")[0];
        let showRow = true;
        
        if (branchFilter && branchCell) {
            let branchText = branchCell.textContent || branchCell.innerText;
            if (branchText !== branchFilter) showRow = false;
        }
        
        if (employeeFilter && employeeCell && showRow) {
            let employeeText = employeeCell.textContent || employeeCell.innerText;
            if (employeeText !== employeeFilter) showRow = false;
        }
        
        tr[i].style.display = showRow ? "" : "none";
    }
}

// Clear all filters
function clearFilters() {
    document.getElementById("searchInput").value = "";
    document.getElementById("filterBranch").value = "";
    document.getElementById("filterEmployee").value = "";
    
    let table = document.getElementById("reportTable");
    let tr = table.getElementsByTagName("tr");
    for (let i = 1; i < tr.length; i++) {
        tr[i].style.display = "";
    }
}
</script>
</body>
</html>
<?php mysqli_close($conn); ?>