<?php
$conn = mysqli_connect("localhost", "root", "", "mesob_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Add column if not exists
$alter_query = "ALTER TABLE users ADD COLUMN IF NOT EXISTS must_change_password TINYINT DEFAULT 1 AFTER password_hash";
mysqli_query($conn, $alter_query);

// Set all staff users to change password on next login
$update_staff = "UPDATE users SET must_change_password = 1 WHERE role = 'staff'";
mysqli_query($conn, $update_staff);

// Set admin not to change password (or set to 1 if you want admin to also change)
$update_admin = "UPDATE users SET must_change_password = 0 WHERE username = 'admin'";
mysqli_query($conn, $update_admin);

echo "✅ Setup completed!<br>";
echo "All staff users will be required to change password on next login.<br>";
echo "Admin user will NOT be required to change password.<br>";

mysqli_close($conn);
?>