<?php
session_start();
require_once 'config.php';

if (isset($_SESSION['user_id'])) {
    // Log logout activity
    logActivity($conn, $_SESSION['user_id'], 'user_logout', "User logged out");
    
    // Destroy session
    session_destroy();
}

header("Location: login.php");
exit();
?>