<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// ✅ BLOCK ADMIN FROM ACCESSING REPORT CREATION PAGE
if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    header("Location: admin_reports.php");
    exit();
}

// Database connection
$conn = mysqli_connect("localhost", "root", "", "mesob_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if password change is required
$check_query = "SELECT must_change_password FROM users WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $check_query);
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

if ($user && $user['must_change_password'] == 1) {
    header("Location: change_password.php");
    exit();
}

// Get user role and info
$user_role = $_SESSION['role'] ?? 'staff';
$user_name = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Staff';

function logAudit($conn, $action, $table, $record_id, $user, $old_data, $new_data) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $old_data_esc = mysqli_real_escape_string($conn, json_encode($old_data));
    $new_data_esc = mysqli_real_escape_string($conn, json_encode($new_data));
    $query = "INSERT INTO audit_logs (action_type, table_name, record_id, user_name, old_data, new_data, ip_address) 
              VALUES ('$action', '$table', '$record_id', '$user', '$old_data_esc', '$new_data_esc', '$ip')";
    mysqli_query($conn, $query);
}

if(isset($_POST['submit'])){
    $date = mysqli_real_escape_string($conn, $_POST['report_date']);
    $ethiopian_date = $date;
    $employee = mysqli_real_escape_string($conn, $_POST['employee_name']);
    $branch = mysqli_real_escape_string($conn, $_POST['branch']);
    
    $organizations = $_POST['organization'];
    $service_types = $_POST['service_type'];
    $service_given = $_POST['service_given'];
    $service_not_complete = $_POST['service_not_complete'];
    
    $total_given = array_sum($service_given);
    $total_not_complete = array_sum($service_not_complete);
    $grand_total = $total_given + $total_not_complete;
    
    $branch_query = "SELECT branch_id FROM branches WHERE branch_code = '$branch' OR branch_name = '$branch' LIMIT 1";
    $branch_result = mysqli_query($conn, $branch_query);
    if(mysqli_num_rows($branch_result) > 0) {
        $branch_row = mysqli_fetch_assoc($branch_result);
        $branch_id = $branch_row['branch_id'];
    } else {
        $insert_branch = "INSERT INTO branches (branch_code, branch_name) VALUES ('$branch', '$branch')";
        mysqli_query($conn, $insert_branch);
        $branch_id = mysqli_insert_id($conn);
    }
    
    $emp_query = "SELECT employee_id FROM employees WHERE full_name = '$employee' LIMIT 1";
    $emp_result = mysqli_query($conn, $emp_query);
    if(mysqli_num_rows($emp_result) > 0) {
        $emp_row = mysqli_fetch_assoc($emp_result);
        $employee_id = $emp_row['employee_id'];
    } else {
        $insert_emp = "INSERT INTO employees (employee_code, full_name, branch_id) VALUES ('EMP" . rand(1000,9999) . "', '$employee', '$branch_id')";
        mysqli_query($conn, $insert_emp);
        $employee_id = mysqli_insert_id($conn);
    }
    
    $success_count = 0;
    
    for($i = 0; $i < count($organizations); $i++) {
        $org = mysqli_real_escape_string($conn, $organizations[$i]);
        $service = mysqli_real_escape_string($conn, $service_types[$i]);
        $given = (int)$service_given[$i];
        $not_complete = (int)$service_not_complete[$i];
        $total = $given + $not_complete;
        
        $org_query = "SELECT organization_id FROM organizations WHERE organization_name = '$org' LIMIT 1";
        $org_result = mysqli_query($conn, $org_query);
        if(mysqli_num_rows($org_result) > 0) {
            $org_row = mysqli_fetch_assoc($org_result);
            $org_id = $org_row['organization_id'];
        } else {
            $insert_org = "INSERT INTO organizations (organization_name) VALUES ('$org')";
            mysqli_query($conn, $insert_org);
            $org_id = mysqli_insert_id($conn);
        }
        
        $serv_query = "SELECT service_id FROM service_types WHERE service_name = '$service' LIMIT 1";
        $serv_result = mysqli_query($conn, $serv_query);
        if(mysqli_num_rows($serv_result) > 0) {
            $serv_row = mysqli_fetch_assoc($serv_result);
            $service_id = $serv_row['service_id'];
        } else {
            $insert_service = "INSERT INTO service_types (service_name) VALUES ('$service')";
            mysqli_query($conn, $insert_service);
            $service_id = mysqli_insert_id($conn);
        }
        
        $report_date_formatted = date('Y-m-d', strtotime(str_replace('/', '-', $date)));
        
        $query = "INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, 
                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) 
                  VALUES ('$report_date_formatted', '$ethiopian_date', '$employee_id', '$employee', '$branch_id', '$branch', 
                  '$org_id', '$org', '$service_id', '$service', $given, $not_complete, $total)";
        
        if(mysqli_query($conn, $query)) {
            $success_count++;
            logAudit($conn, 'INSERT', 'daily_reports', mysqli_insert_id($conn), $employee, null, $query);
        }
    }
    
    $summary_query = "INSERT INTO report_summaries (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, 
                      total_services_given, total_services_not_complete, grand_total, total_organizations_served) 
                      VALUES ('$report_date_formatted', '$ethiopian_date', '$employee_id', '$employee', '$branch_id', '$branch', 
                      $total_given, $total_not_complete, $grand_total, $success_count)
                      ON DUPLICATE KEY UPDATE 
                      total_services_given = total_services_given + $total_given,
                      total_services_not_complete = total_services_not_complete + $total_not_complete,
                      grand_total = grand_total + $grand_total,
                      total_organizations_served = total_organizations_served + $success_count,
                      submitted_at = CURRENT_TIMESTAMP";
    
    mysqli_query($conn, $summary_query);
    
    if($success_count > 0) {
        echo "<script>alert('✅ Daily Report Submitted Successfully!\\n\\n📅 Date: $date\\n👤 Employee: $employee\\n🏢 Branch: $branch\\n📊 Total Services: $grand_total');</script>";
        echo "<script>window.location.href='view_reports.php';</script>";
    } else {
        echo "<script>alert('❌ Error submitting report. Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MESOB - Create Report (Staff)</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#edf2f7;
    padding:2px;
    font-size:11px;
}

.container{
    max-width:1400px;
    margin:auto;
    background:#fff;
    border-radius:2px;
    overflow:hidden;
    box-shadow:0 1px 3px rgba(0,0,0,.08);
}

.header{
    background:#1f3b57;
    color:#fff;
    text-align:center;
    padding:6px;
}

.header h1{
    font-size:18px;
}

.nav-bar{
    background:#f8fafc;
    padding:4px 8px;
    border-bottom:1px solid #ddd;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
}

.nav-links{
    display:flex;
    gap:3px;
    flex-wrap:wrap;
}

.nav-links a{
    color:#1f3b57;
    text-decoration:none;
    padding:3px 8px;
    border-radius:2px;
    font-size:10px;
}

.nav-links a:hover{
    background:#1f3b57;
    color:#fff;
}

.role-badge{
    background:#28a745;
    color:#fff;
    padding:2px 6px;
    border-radius:10px;
    font-size:9px;
}

.user-info{
    display:flex;
    align-items:center;
    gap:5px;
    font-size:10px;
}

.logout-btn{
    background:#dc3545;
    color:#fff;
    padding:3px 8px;
    border-radius:2px;
    text-decoration:none;
    font-size:10px;
}

.top-form{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
    gap:4px;
    padding:6px;
    background:#f8fafc;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group label{
    font-size:10px;
    font-weight:600;
    color:#1f3b57;
    margin-bottom:1px;
}

.form-group input,
.form-group select{
    padding:3px 6px;
    border:1px solid #ccc;
    border-radius:2px;
    font-size:10px;
    height:26px;
}

.table-container{
    overflow-x:auto;
    padding:4px;
    max-height:450px;
}

table{
    width:100%;
    border-collapse:collapse;
    font-size:9px;
}

table th{
    background:#d9c5c5;
    padding:3px;
    border:1px solid #999;
    height:22px;
    white-space:nowrap;
}

table td{
    padding:2px;
    border:1px solid #ccc;
    height:20px;
}

table td input{
    width:100%;
    padding:2px 4px;
    border:1px solid #ddd;
    border-radius:1px;
    font-size:9px;
    height:20px;
}

.summary{
    display:flex;
    justify-content:flex-end;
    gap:4px;
    padding:4px 6px;
    flex-wrap:wrap;
}

.summary-box{
    background:#1f3b57;
    color:#fff;
    padding:4px 8px;
    border-radius:2px;
    text-align:center;
    min-width:90px;
}

.summary-box h3{
    font-size:10px;
    margin-bottom:1px;
}

.summary-box span{
    font-size:14px;
    font-weight:bold;
}

.button-area{
    text-align:center;
    padding:6px;
}

button{
    padding:4px 12px;
    background:#1f3b57;
    color:#fff;
    border:none;
    border-radius:2px;
    cursor:pointer;
    font-size:10px;
}

.footer{
    text-align:center;
    padding:4px;
    color:#666;
    font-size:10px;
}

@media(max-width:768px){

    .header h1{
        font-size:15px;
    }

    .top-form{
        grid-template-columns:1fr;
    }

    .summary{
        justify-content:center;
    }

    table{
        font-size:8px;
    }

    table th,
    table td{
        padding:1px;
        height:18px;
    }

    table td input{
        height:18px;
        font-size:8px;
    }
}
</style>
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>📋 Create Daily Report</h1>
    </div>
    <div class="nav-bar">
        <div class="nav-links">
            <a href="mesob.php">📝 New Report</a>
            <a href="view_reports.php">📊 View Reports</a>
            <a href="reports_summary.php">📈 Summary</a>
        </div>
        <div class="user-info">
            <span class="role-badge">STAFF</span>
            <span>👤 <?php echo htmlspecialchars($user_name); ?></span>
            <a href="logout.php" class="logout-btn">🚪 Logout</a>
        </div>
    </div>

    <form method="POST">
        <div class="top-form">
            <div class="form-group">
                <label>📅 Date</label>
                <input type="text" name="report_date" value="20/09/2018" required>
            </div>
            <div class="form-group">
                <label>👤 Employee</label>
                <input type="text" name="employee_name" value="Wendmu" required>
            </div>
            <div class="form-group">
                <label>🏢 Branch</label>
                <select name="branch" required>
                    <option value="A-MESOB">A-MESOB</option>
                    <option value="B-MESOB">B-MESOB</option>
                    <option value="Head Office">Head Office</option>
                </select>
            </div>
        </div>

        <div class="table-container">
            <table>
                <thead><tr><th>#</th><th>Organization</th><th>Service Type</th><th>Given</th><th>Missing</th><th>Total</th></tr></thead>
                <tbody>
                    <?php
                    $services = [
                        ['org' => 'እሽተሽ', 'service' => 'የመንጃ ፈቃድ እድሳት', 'given' => 2, 'not_complete' => 1],
                        ['org' => 'እሽተሽ', 'service' => 'የበሎ እድሳት', 'given' => 7, 'not_complete' => 2],
                        ['org' => 'ጤና ቢሮ', 'service' => 'ጤና ምርመራ', 'given' => 7, 'not_complete' => 1],
                        ['org' => 'ቤቶች ልማት', 'service' => 'የመንግስት ቤት ውል እድሳት', 'given' => 1, 'not_complete' => 1],
                        ['org' => 'ንግድ ቢሮ', 'service' => 'ንግድ ፈቃድ ማደስ', 'given' => 0, 'not_complete' => 0],
                        ['org' => 'ንግድ ቢሮ', 'service' => 'የንግድ ስራ ፈቃድ', 'given' => 1, 'not_complete' => 1],
                        ['org' => 'ግንባታ ፈቃድ', 'service' => 'የፕላን ስምምነት', 'given' => 0, 'not_complete' => 0],
                        ['org' => 'የሲቪል ምዝገባ', 'service' => 'የልደት ሰርቲፍኬት', 'given' => 0, 'not_complete' => 0],
                        ['org' => 'የሲቪል ምዝገባ', 'service' => 'መታወቂያ እድሳት', 'given' => 0, 'not_complete' => 0],
                        ['org' => 'ሲቪል ምዝገባ', 'service' => 'የጋብቻ', 'given' => 0, 'not_complete' => 0]
                    ];
                    $sn = 1;
                    foreach($services as $s){
                    ?>
                    <tr>
                        <td><?php echo $sn; ?></td>
                        <td><input type="text" name="organization[]" value="<?php echo htmlspecialchars($s['org']); ?>"></td>
                        <td><input type="text" name="service_type[]" value="<?php echo htmlspecialchars($s['service']); ?>"></td>
                        <td><input type="number" class="given" name="service_given[]" value="<?php echo $s['given']; ?>" style="width:60px;"></td>
                        <td><input type="number" class="notcomplete" name="service_not_complete[]" value="<?php echo $s['not_complete']; ?>" style="width:60px;"></td>
                        <td><input type="number" class="total" readonly style="width:60px;background:#f0f0f0;"></td>
                    </tr>
                    <?php $sn++; } ?>
                </tbody>
            </table>
        </div>

        <div class="summary">
            <div class="summary-box"><h3>✅ Given</h3><span id="totalGiven">0</span></div>
            <div class="summary-box"><h3>⚠️ Missing</h3><span id="totalNot">0</span></div>
            <div class="summary-box"><h3>📊 Total</h3><span id="grandTotal">0</span></div>
        </div>

        <div class="button-area">
            <button type="submit" name="submit">📤 Submit Report</button>
            <button type="button" onclick="resetForm()" style="background:#6c757d;">⟳ Reset</button>
        </div>
    </form>
    <div class="footer">MESOB Reporting System | Staff - Create Reports</div>
</div>
<script>
function calculateTotals(){
    let given = document.querySelectorAll('.given');
    let notComp = document.querySelectorAll('.notcomplete');
    let total = document.querySelectorAll('.total');
    let tg=0, tn=0, gr=0;
    for(let i=0;i<given.length;i++){
        let g=parseInt(given[i].value)||0;
        let n=parseInt(notComp[i].value)||0;
        let t=g+n;
        total[i].value=t;
        tg+=g; tn+=n; gr+=t;
    }
    document.getElementById('totalGiven').innerText=tg;
    document.getElementById('totalNot').innerText=tn;
    document.getElementById('grandTotal').innerText=gr;
}
function resetForm(){
    if(confirm('Reset all values?')){
        let given=document.querySelectorAll('.given');
        let notComp=document.querySelectorAll('.notcomplete');
        let origGiven=[2,7,7,1,0,1,0,0,0,0];
        let origNot=[1,2,1,1,0,1,0,0,0,0];
        for(let i=0;i<given.length;i++){
            given[i].value=origGiven[i];
            notComp[i].value=origNot[i];
        }
        calculateTotals();
    }
}
document.querySelectorAll('.given, .notcomplete').forEach(el=>el.addEventListener('input',calculateTotals));
calculateTotals();
</script>
</body>
</html>
<?php mysqli_close($conn); ?>