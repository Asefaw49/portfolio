<?php
// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'mesob_db';

// Create connection
$conn = mysqli_connect($host, $username, $password);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Create database if not exists
$sql = "CREATE DATABASE IF NOT EXISTS $database";
if (mysqli_query($conn, $sql)) {
    echo "Database '$database' created successfully.<br>";
} else {
    echo "Error creating database: " . mysqli_error($conn) . "<br>";
}

// Select the database
mysqli_select_db($conn, $database);

// SQL to create tables
$tables_sql = "

-- Table: branches
CREATE TABLE IF NOT EXISTS branches (
    branch_id INT AUTO_INCREMENT PRIMARY KEY,
    branch_code VARCHAR(50) NOT NULL UNIQUE,
    branch_name VARCHAR(100) NOT NULL,
    location VARCHAR(200),
    phone VARCHAR(20),
    email VARCHAR(100),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: employees
CREATE TABLE IF NOT EXISTS employees (
    employee_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_code VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    position VARCHAR(100),
    branch_id INT,
    phone VARCHAR(20),
    email VARCHAR(100),
    hire_date DATE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: organizations
CREATE TABLE IF NOT EXISTS organizations (
    organization_id INT AUTO_INCREMENT PRIMARY KEY,
    organization_name VARCHAR(200) NOT NULL UNIQUE,
    description TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: service_types
CREATE TABLE IF NOT EXISTS service_types (
    service_id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(200) NOT NULL UNIQUE,
    category VARCHAR(100),
    description TEXT,
    expected_documents TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: daily_reports
CREATE TABLE IF NOT EXISTS daily_reports (
    report_id INT AUTO_INCREMENT PRIMARY KEY,
    report_date DATE NOT NULL,
    ethiopian_date VARCHAR(20) NOT NULL,
    employee_id INT,
    employee_name VARCHAR(100) NOT NULL,
    branch_id INT,
    branch_name VARCHAR(100) NOT NULL,
    organization_id INT,
    organization_name VARCHAR(200) NOT NULL,
    service_type_id INT,
    service_type_name VARCHAR(200) NOT NULL,
    service_given INT DEFAULT 0,
    service_not_complete INT DEFAULT 0,
    total_service INT DEFAULT 0,
    missing_documents_reason TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE SET NULL,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id) ON DELETE SET NULL,
    FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE SET NULL,
    FOREIGN KEY (service_type_id) REFERENCES service_types(service_id) ON DELETE SET NULL,
    INDEX idx_report_date (report_date),
    INDEX idx_employee (employee_id),
    INDEX idx_branch (branch_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: report_summaries
CREATE TABLE IF NOT EXISTS report_summaries (
    summary_id INT AUTO_INCREMENT PRIMARY KEY,
    report_date DATE NOT NULL,
    ethiopian_date VARCHAR(20) NOT NULL,
    employee_id INT,
    employee_name VARCHAR(100) NOT NULL,
    branch_id INT,
    branch_name VARCHAR(100) NOT NULL,
    total_services_given INT DEFAULT 0,
    total_services_not_complete INT DEFAULT 0,
    grand_total INT DEFAULT 0,
    total_organizations_served INT DEFAULT 0,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_report (report_date, employee_id, branch_id),
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE SET NULL,
    FOREIGN KEY (branch_id) REFERENCES branches(branch_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: audit_logs
CREATE TABLE IF NOT EXISTS audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    action_type VARCHAR(50) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    user_name VARCHAR(100),
    old_data TEXT,
    new_data TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

";

// Execute multiple queries
if (mysqli_multi_query($conn, $tables_sql)) {
    do {
        // Store result to free memory
        if ($result = mysqli_store_result($conn)) {
            mysqli_free_result($result);
        }
    } while (mysqli_next_result($conn));
    echo "All tables created successfully.<br>";
} else {
    echo "Error creating tables: " . mysqli_error($conn) . "<br>";
}

// Insert initial data
$initial_data = "

-- Insert branches
INSERT INTO branches (branch_code, branch_name, location) VALUES 
('A-MESOB', 'A-MESOB Branch', 'Addis Ababa, Arada Sub-city'),
('B-MESOB', 'B-MESOB Branch', 'Addis Ababa, Bole Sub-city'),
('HO-001', 'Head Office', 'Addis Ababa, Kirkos Sub-city')
ON DUPLICATE KEY UPDATE branch_name = VALUES(branch_name);

-- Insert employees
INSERT INTO employees (employee_code, full_name, position, branch_id) VALUES 
('EMP001', 'Wendmu', 'Senior Service Officer', 1),
('EMP002', 'Almaz Desta', 'Service Coordinator', 1),
('EMP003', 'Tekle Berhan', 'Customer Service Rep', 2)
ON DUPLICATE KEY UPDATE full_name = VALUES(full_name);

-- Insert organizations
INSERT INTO organizations (organization_name, description) VALUES 
('እሽተሽ', 'Driver license and vehicle registration authority'),
('ጤና ቢሮ', 'Health Bureau - Medical examination services'),
('ቤቶች ልማት አስተዳደር', 'Housing Development Administration'),
('ንግድ ቢሮ', 'Trade Bureau - Business licensing'),
('ግንባታ ፈቃድ', 'Construction Permit Authority'),
('የሲቪል ምዝገባ', 'Civil Registration Agency')
ON DUPLICATE KEY UPDATE description = VALUES(description);

-- Insert service types
INSERT INTO service_types (service_name, category, expected_documents) VALUES 
('የመንጃ ፈቃድ እድሳት', 'Driver License', 'Old license, ID, medical certificate'),
('የበሎ እድሳት', 'Vehicle Registration', 'Old registration, insurance, inspection'),
('ጤና ምርመራ(ሜዳካል)', 'Medical Services', 'Referral letter, ID'),
('የመንግስት ቤት ውል እድሳት', 'Housing', 'Old contract, payment receipt'),
('ንግድ ፈቃድ ማደስ', 'Business License', 'Old license, tax clearance'),
('የንግድ ስራ ፈቃድ', 'Business License', 'Business plan, ID, rental agreement'),
('የፕላን ስምምነት', 'Construction', 'Building plan, title deed'),
('የልደት ሰርቲፍኬት ማረጋገጥ', 'Civil Registration', 'Birth certificate, parent ID'),
('መታወቂያ እድሳት', 'Civil Registration', 'Old ID, proof of residence'),
('የጋብቻ', 'Civil Registration', 'ID, witness statements')
ON DUPLICATE KEY UPDATE category = VALUES(category);

";

if (mysqli_multi_query($conn, $initial_data)) {
    do {
        if ($result = mysqli_store_result($conn)) {
            mysqli_free_result($result);
        }
    } while (mysqli_next_result($conn));
    echo "Initial data inserted successfully.<br>";
} else {
    echo "Error inserting initial data: " . mysqli_error($conn) . "<br>";
}

// Close connection
mysqli_close($conn);

echo "<br><strong>✅ Database setup completed successfully!</strong><br>";
echo "<a href='mesob.php'>Go to MESOB Daily Report Form →</a>";
?>