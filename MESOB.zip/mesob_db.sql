-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2026 at 12:07 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mesob_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `log_id` int(11) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `old_data` text DEFAULT NULL,
  `new_data` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`log_id`, `action_type`, `table_name`, `record_id`, `user_name`, `old_data`, `new_data`, `ip_address`, `created_at`) VALUES
(1, 'INSERT', 'daily_reports', 1, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 3, 1, 4)\"', '::1', '2026-05-29 09:00:11'),
(2, 'INSERT', 'daily_reports', 2, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 7, 2, 9)\"', '::1', '2026-05-29 09:00:11'),
(3, 'INSERT', 'daily_reports', 3, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'3\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b(\\u121c\\u12f3\\u12ab\\u120d)\', 7, 1, 8)\"', '::1', '2026-05-29 09:00:11'),
(4, 'INSERT', 'daily_reports', 4, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'3\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275 \\u12a0\\u1235\\u1270\\u12f3\\u12f0\\u122d\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-29 09:00:11'),
(5, 'INSERT', 'daily_reports', 5, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-29 09:00:11'),
(6, 'INSERT', 'daily_reports', 6, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-29 09:00:11'),
(7, 'INSERT', 'daily_reports', 7, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 09:00:11'),
(8, 'INSERT', 'daily_reports', 8, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'8\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275 \\u121b\\u1228\\u130b\\u1308\\u1325\', 0, 0, 0)\"', '::1', '2026-05-29 09:00:11'),
(9, 'INSERT', 'daily_reports', 9, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 09:00:11'),
(10, 'INSERT', 'daily_reports', 10, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-29 09:00:11'),
(11, 'INSERT', 'daily_reports', 11, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 2, 2, 4)\"', '::1', '2026-05-29 11:54:23'),
(12, 'INSERT', 'daily_reports', 12, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 7, 3, 10)\"', '::1', '2026-05-29 11:54:23'),
(13, 'INSERT', 'daily_reports', 13, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 7, 1, 8)\"', '::1', '2026-05-29 11:54:23'),
(14, 'INSERT', 'daily_reports', 14, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-29 11:54:23'),
(15, 'INSERT', 'daily_reports', 15, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-29 11:54:24'),
(16, 'INSERT', 'daily_reports', 16, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-29 11:54:24'),
(17, 'INSERT', 'daily_reports', 17, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:54:24'),
(18, 'INSERT', 'daily_reports', 18, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:54:24'),
(19, 'INSERT', 'daily_reports', 19, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:54:24'),
(20, 'INSERT', 'daily_reports', 20, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-29 11:54:24'),
(21, 'INSERT', 'daily_reports', 21, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 2, 2, 4)\"', '::1', '2026-05-29 11:57:40'),
(22, 'INSERT', 'daily_reports', 22, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 7, 3, 10)\"', '::1', '2026-05-29 11:57:40'),
(23, 'INSERT', 'daily_reports', 23, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 7, 1, 8)\"', '::1', '2026-05-29 11:57:40'),
(24, 'INSERT', 'daily_reports', 24, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-29 11:57:40'),
(25, 'INSERT', 'daily_reports', 25, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-29 11:57:40'),
(26, 'INSERT', 'daily_reports', 26, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-29 11:57:40'),
(27, 'INSERT', 'daily_reports', 27, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:57:40'),
(28, 'INSERT', 'daily_reports', 28, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:57:40'),
(29, 'INSERT', 'daily_reports', 29, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:57:40'),
(30, 'INSERT', 'daily_reports', 30, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-29 11:57:40'),
(31, 'INSERT', 'daily_reports', 31, 'tadesse', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'4\', \'tadesse\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 2, 1, 3)\"', '::1', '2026-05-29 11:58:19'),
(32, 'INSERT', 'daily_reports', 32, 'tadesse', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'4\', \'tadesse\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 7, 2, 9)\"', '::1', '2026-05-29 11:58:19'),
(33, 'INSERT', 'daily_reports', 33, 'tadesse', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'4\', \'tadesse\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 7, 1, 8)\"', '::1', '2026-05-29 11:58:19'),
(34, 'INSERT', 'daily_reports', 34, 'tadesse', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'4\', \'tadesse\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-29 11:58:19'),
(35, 'INSERT', 'daily_reports', 35, 'tadesse', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'4\', \'tadesse\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-29 11:58:19'),
(36, 'INSERT', 'daily_reports', 36, 'tadesse', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'4\', \'tadesse\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-29 11:58:19'),
(37, 'INSERT', 'daily_reports', 37, 'tadesse', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'4\', \'tadesse\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:58:19'),
(38, 'INSERT', 'daily_reports', 38, 'tadesse', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'4\', \'tadesse\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:58:20'),
(39, 'INSERT', 'daily_reports', 39, 'tadesse', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'4\', \'tadesse\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:58:20'),
(40, 'INSERT', 'daily_reports', 40, 'tadesse', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'4\', \'tadesse\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-29 11:58:20'),
(41, 'INSERT', 'daily_reports', 41, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 2, 1, 3)\"', '::1', '2026-05-29 11:59:37'),
(42, 'INSERT', 'daily_reports', 42, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 7, 2, 9)\"', '::1', '2026-05-29 11:59:37'),
(43, 'INSERT', 'daily_reports', 43, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 7, 1, 8)\"', '::1', '2026-05-29 11:59:37'),
(44, 'INSERT', 'daily_reports', 44, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-29 11:59:37'),
(45, 'INSERT', 'daily_reports', 45, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-29 11:59:37'),
(46, 'INSERT', 'daily_reports', 46, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-29 11:59:37'),
(47, 'INSERT', 'daily_reports', 47, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:59:37'),
(48, 'INSERT', 'daily_reports', 48, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:59:37'),
(49, 'INSERT', 'daily_reports', 49, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 11:59:37'),
(50, 'INSERT', 'daily_reports', 50, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-29 11:59:37'),
(51, 'INSERT', 'daily_reports', 51, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 2, 1, 3)\"', '::1', '2026-05-29 12:03:55'),
(52, 'INSERT', 'daily_reports', 52, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 7, 2, 9)\"', '::1', '2026-05-29 12:03:55'),
(53, 'INSERT', 'daily_reports', 53, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 7, 1, 8)\"', '::1', '2026-05-29 12:03:55'),
(54, 'INSERT', 'daily_reports', 54, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-29 12:03:55'),
(55, 'INSERT', 'daily_reports', 55, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-29 12:03:55'),
(56, 'INSERT', 'daily_reports', 56, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-29 12:03:55'),
(57, 'INSERT', 'daily_reports', 57, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 12:03:55'),
(58, 'INSERT', 'daily_reports', 58, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 12:03:55'),
(59, 'INSERT', 'daily_reports', 59, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-29 12:03:55'),
(60, 'INSERT', 'daily_reports', 60, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-29 12:03:55'),
(61, 'INSERT', 'daily_reports', 71, 'kibrom', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'5\', \'kibrom\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 4, 1, 5)\"', '::1', '2026-05-30 07:32:17'),
(62, 'INSERT', 'daily_reports', 72, 'kibrom', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'5\', \'kibrom\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 7, 2, 9)\"', '::1', '2026-05-30 07:32:17'),
(63, 'INSERT', 'daily_reports', 73, 'kibrom', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'5\', \'kibrom\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 7, 1, 8)\"', '::1', '2026-05-30 07:32:17'),
(64, 'INSERT', 'daily_reports', 74, 'kibrom', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'5\', \'kibrom\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-30 07:32:17'),
(65, 'INSERT', 'daily_reports', 75, 'kibrom', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'5\', \'kibrom\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', -2, 0, -2)\"', '::1', '2026-05-30 07:32:17'),
(66, 'INSERT', 'daily_reports', 76, 'kibrom', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'5\', \'kibrom\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-30 07:32:17'),
(67, 'INSERT', 'daily_reports', 77, 'kibrom', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'5\', \'kibrom\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 07:32:17'),
(68, 'INSERT', 'daily_reports', 78, 'kibrom', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'5\', \'kibrom\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 07:32:17'),
(69, 'INSERT', 'daily_reports', 79, 'kibrom', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'5\', \'kibrom\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 07:32:17'),
(70, 'INSERT', 'daily_reports', 80, 'kibrom', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'5\', \'kibrom\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-30 07:32:17'),
(71, 'INSERT', 'daily_reports', 81, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 2, 1, 3)\"', '::1', '2026-05-30 07:59:44'),
(72, 'INSERT', 'daily_reports', 82, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 7, 2, 9)\"', '::1', '2026-05-30 07:59:44'),
(73, 'INSERT', 'daily_reports', 83, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 7, 1, 8)\"', '::1', '2026-05-30 07:59:44'),
(74, 'INSERT', 'daily_reports', 84, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-30 07:59:44'),
(75, 'INSERT', 'daily_reports', 85, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-30 07:59:44'),
(76, 'INSERT', 'daily_reports', 86, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-30 07:59:44'),
(77, 'INSERT', 'daily_reports', 87, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 07:59:44'),
(78, 'INSERT', 'daily_reports', 88, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 07:59:44'),
(79, 'INSERT', 'daily_reports', 89, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 07:59:44'),
(80, 'INSERT', 'daily_reports', 90, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-30 07:59:44');
INSERT INTO `audit_logs` (`log_id`, `action_type`, `table_name`, `record_id`, `user_name`, `old_data`, `new_data`, `ip_address`, `created_at`) VALUES
(81, 'INSERT', 'daily_reports', 91, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 2, 1, 3)\"', '::1', '2026-05-30 08:06:24'),
(82, 'INSERT', 'daily_reports', 92, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 8, 2, 10)\"', '::1', '2026-05-30 08:06:24'),
(83, 'INSERT', 'daily_reports', 93, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 6, 1, 7)\"', '::1', '2026-05-30 08:06:24'),
(84, 'INSERT', 'daily_reports', 94, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-30 08:06:24'),
(85, 'INSERT', 'daily_reports', 95, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-30 08:06:24'),
(86, 'INSERT', 'daily_reports', 96, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-30 08:06:24'),
(87, 'INSERT', 'daily_reports', 97, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 08:06:24'),
(88, 'INSERT', 'daily_reports', 98, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 08:06:24'),
(89, 'INSERT', 'daily_reports', 99, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 08:06:24'),
(90, 'INSERT', 'daily_reports', 100, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-30 08:06:24'),
(91, 'INSERT', 'daily_reports', 101, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 2, 1, 3)\"', '::1', '2026-05-30 08:22:53'),
(92, 'INSERT', 'daily_reports', 102, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 7, 2, 9)\"', '::1', '2026-05-30 08:22:53'),
(93, 'INSERT', 'daily_reports', 103, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 7, 1, 8)\"', '::1', '2026-05-30 08:22:53'),
(94, 'INSERT', 'daily_reports', 104, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-30 08:22:53'),
(95, 'INSERT', 'daily_reports', 105, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-30 08:22:53'),
(96, 'INSERT', 'daily_reports', 106, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-30 08:22:53'),
(97, 'INSERT', 'daily_reports', 107, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 08:22:53'),
(98, 'INSERT', 'daily_reports', 108, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 08:22:53'),
(99, 'INSERT', 'daily_reports', 109, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 08:22:53'),
(100, 'INSERT', 'daily_reports', 110, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-30 08:22:53'),
(101, 'INSERT', 'daily_reports', 111, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 2, 1, 3)\"', '::1', '2026-05-30 08:28:29'),
(102, 'INSERT', 'daily_reports', 112, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 7, 2, 9)\"', '::1', '2026-05-30 08:28:29'),
(103, 'INSERT', 'daily_reports', 113, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 7, 1, 8)\"', '::1', '2026-05-30 08:28:29'),
(104, 'INSERT', 'daily_reports', 114, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-30 08:28:29'),
(105, 'INSERT', 'daily_reports', 115, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-30 08:28:29'),
(106, 'INSERT', 'daily_reports', 116, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-30 08:28:29'),
(107, 'INSERT', 'daily_reports', 117, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 08:28:29'),
(108, 'INSERT', 'daily_reports', 118, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 08:28:29'),
(109, 'INSERT', 'daily_reports', 119, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 08:28:29'),
(110, 'INSERT', 'daily_reports', 120, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-30 08:28:29'),
(111, 'INSERT', 'daily_reports', 121, 'tadelu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-22\', \'22\\/09\\/2018\', \'6\', \'tadelu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-30 09:11:15'),
(112, 'INSERT', 'daily_reports', 122, 'tadelu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-22\', \'22\\/09\\/2018\', \'6\', \'tadelu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 6, 2, 8)\"', '::1', '2026-05-30 09:11:15'),
(113, 'INSERT', 'daily_reports', 123, 'tadelu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-22\', \'22\\/09\\/2018\', \'6\', \'tadelu\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 7, 1, 8)\"', '::1', '2026-05-30 09:11:15'),
(114, 'INSERT', 'daily_reports', 124, 'tadelu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-22\', \'22\\/09\\/2018\', \'6\', \'tadelu\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-30 09:11:15'),
(115, 'INSERT', 'daily_reports', 125, 'tadelu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-22\', \'22\\/09\\/2018\', \'6\', \'tadelu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-30 09:11:15'),
(116, 'INSERT', 'daily_reports', 126, 'tadelu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-22\', \'22\\/09\\/2018\', \'6\', \'tadelu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-30 09:11:15'),
(117, 'INSERT', 'daily_reports', 127, 'tadelu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-22\', \'22\\/09\\/2018\', \'6\', \'tadelu\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 09:11:15'),
(118, 'INSERT', 'daily_reports', 128, 'tadelu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-22\', \'22\\/09\\/2018\', \'6\', \'tadelu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 09:11:15'),
(119, 'INSERT', 'daily_reports', 129, 'tadelu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-22\', \'22\\/09\\/2018\', \'6\', \'tadelu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 09:11:15'),
(120, 'INSERT', 'daily_reports', 130, 'tadelu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-22\', \'22\\/09\\/2018\', \'6\', \'tadelu\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-30 09:11:15'),
(121, 'INSERT', 'daily_reports', 131, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'1\', \'\\u12e8\\u1218\\u1295\\u1303 \\u1348\\u1243\\u12f5 \\u12a5\\u12f5\\u1233\\u1275\', 2, 1, 3)\"', '::1', '2026-05-30 09:13:49'),
(122, 'INSERT', 'daily_reports', 132, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'1\', \'\\u12a5\\u123d\\u1270\\u123d\', \'2\', \'\\u12e8\\u1260\\u120e \\u12a5\\u12f5\\u1233\\u1275\', 7, 2, 9)\"', '::1', '2026-05-30 09:13:49'),
(123, 'INSERT', 'daily_reports', 133, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'2\', \'\\u1324\\u1293 \\u1262\\u122e\', \'11\', \'\\u1324\\u1293 \\u121d\\u122d\\u1218\\u122b\', 7, 1, 8)\"', '::1', '2026-05-30 09:13:49'),
(124, 'INSERT', 'daily_reports', 134, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'8\', \'\\u1264\\u1276\\u127d \\u120d\\u121b\\u1275\', \'4\', \'\\u12e8\\u1218\\u1295\\u130d\\u1235\\u1275 \\u1264\\u1275 \\u12cd\\u120d \\u12a5\\u12f5\\u1233\\u1275\', 1, 1, 2)\"', '::1', '2026-05-30 09:13:49'),
(125, 'INSERT', 'daily_reports', 135, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'5\', \'\\u1295\\u130d\\u12f5 \\u1348\\u1243\\u12f5 \\u121b\\u12f0\\u1235\', 0, 0, 0)\"', '::1', '2026-05-30 09:13:49'),
(126, 'INSERT', 'daily_reports', 136, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'4\', \'\\u1295\\u130d\\u12f5 \\u1262\\u122e\', \'6\', \'\\u12e8\\u1295\\u130d\\u12f5 \\u1235\\u122b \\u1348\\u1243\\u12f5\', 1, 1, 2)\"', '::1', '2026-05-30 09:13:49'),
(127, 'INSERT', 'daily_reports', 137, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'5\', \'\\u130d\\u1295\\u1263\\u1273 \\u1348\\u1243\\u12f5\', \'7\', \'\\u12e8\\u1355\\u120b\\u1295 \\u1235\\u121d\\u121d\\u1290\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 09:13:49'),
(128, 'INSERT', 'daily_reports', 138, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'12\', \'\\u12e8\\u120d\\u12f0\\u1275 \\u1230\\u122d\\u1272\\u134d\\u12ac\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 09:13:49'),
(129, 'INSERT', 'daily_reports', 139, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'6\', \'\\u12e8\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'9\', \'\\u1218\\u1273\\u12c8\\u1242\\u12eb \\u12a5\\u12f5\\u1233\\u1275\', 0, 0, 0)\"', '::1', '2026-05-30 09:13:49'),
(130, 'INSERT', 'daily_reports', 140, 'Wendmu', 'null', '\"INSERT INTO daily_reports (report_date, ethiopian_date, employee_id, employee_name, branch_id, branch_name, \\r\\n                  organization_id, organization_name, service_type_id, service_type_name, service_given, service_not_complete, total_service) \\r\\n                  VALUES (\'2018-09-20\', \'20\\/09\\/2018\', \'1\', \'Wendmu\', \'1\', \'A-MESOB\', \\r\\n                  \'7\', \'\\u1232\\u126a\\u120d \\u121d\\u12dd\\u1308\\u1263\', \'10\', \'\\u12e8\\u130b\\u1265\\u127b\', 0, 0, 0)\"', '::1', '2026-05-30 09:13:49');

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `branch_id` int(11) NOT NULL,
  `branch_code` varchar(50) NOT NULL,
  `branch_name` varchar(100) NOT NULL,
  `location` varchar(200) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`branch_id`, `branch_code`, `branch_name`, `location`, `phone`, `email`, `status`, `created_at`) VALUES
(1, 'A-MESOB', 'A-MESOB Branch', 'Addis Ababa, Arada Sub-city', NULL, NULL, 'active', '2026-05-29 08:57:21'),
(2, 'B-MESOB', 'B-MESOB Branch', 'Addis Ababa, Bole Sub-city', NULL, NULL, 'active', '2026-05-29 08:57:21'),
(3, 'HO-001', 'Head Office', 'Addis Ababa, Kirkos Sub-city', NULL, NULL, 'active', '2026-05-29 08:57:21');

-- --------------------------------------------------------

--
-- Table structure for table `daily_reports`
--

CREATE TABLE `daily_reports` (
  `report_id` int(11) NOT NULL,
  `report_date` date NOT NULL,
  `ethiopian_date` varchar(20) NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `employee_name` varchar(100) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `branch_name` varchar(100) NOT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `organization_name` varchar(200) NOT NULL,
  `service_type_id` int(11) DEFAULT NULL,
  `service_type_name` varchar(200) NOT NULL,
  `service_given` int(11) DEFAULT 0,
  `service_not_complete` int(11) DEFAULT 0,
  `total_service` int(11) DEFAULT 0,
  `missing_documents_reason` text DEFAULT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `daily_reports`
--

INSERT INTO `daily_reports` (`report_id`, `report_date`, `ethiopian_date`, `employee_id`, `employee_name`, `branch_id`, `branch_name`, `organization_id`, `organization_name`, `service_type_id`, `service_type_name`, `service_given`, `service_not_complete`, `total_service`, `missing_documents_reason`, `submitted_at`, `user_id`) VALUES
(1, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 3, 1, 4, NULL, '2026-05-29 09:00:11', NULL),
(2, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 2, 9, NULL, '2026-05-29 09:00:11', NULL),
(3, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 3, 'ጤና ምርመራ(ሜዳካል)', 7, 1, 8, NULL, '2026-05-29 09:00:11', NULL),
(4, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 3, 'ቤቶች ልማት አስተዳደር', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-29 09:00:11', NULL),
(5, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-29 09:00:11', NULL),
(6, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-29 09:00:11', NULL),
(7, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-29 09:00:11', NULL),
(8, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 8, 'የልደት ሰርቲፍኬት ማረጋገጥ', 0, 0, 0, NULL, '2026-05-29 09:00:11', NULL),
(9, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-29 09:00:11', NULL),
(10, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-29 09:00:11', NULL),
(11, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 2, 2, 4, NULL, '2026-05-29 11:54:23', NULL),
(12, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 3, 10, NULL, '2026-05-29 11:54:23', NULL),
(13, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 7, 1, 8, NULL, '2026-05-29 11:54:23', NULL),
(14, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-29 11:54:23', NULL),
(15, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-29 11:54:24', NULL),
(16, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-29 11:54:24', NULL),
(17, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-29 11:54:24', NULL),
(18, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-29 11:54:24', NULL),
(19, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-29 11:54:24', NULL),
(20, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-29 11:54:24', NULL),
(21, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 2, 2, 4, NULL, '2026-05-29 11:57:40', NULL),
(22, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 3, 10, NULL, '2026-05-29 11:57:40', NULL),
(23, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 7, 1, 8, NULL, '2026-05-29 11:57:40', NULL),
(24, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-29 11:57:40', NULL),
(25, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-29 11:57:40', NULL),
(26, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-29 11:57:40', NULL),
(27, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-29 11:57:40', NULL),
(28, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-29 11:57:40', NULL),
(29, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-29 11:57:40', NULL),
(30, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-29 11:57:40', NULL),
(31, '2018-09-20', '20/09/2018', 4, 'tadesse', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 2, 1, 3, NULL, '2026-05-29 11:58:19', NULL),
(32, '2018-09-20', '20/09/2018', 4, 'tadesse', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 2, 9, NULL, '2026-05-29 11:58:19', NULL),
(33, '2018-09-20', '20/09/2018', 4, 'tadesse', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 7, 1, 8, NULL, '2026-05-29 11:58:19', NULL),
(34, '2018-09-20', '20/09/2018', 4, 'tadesse', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-29 11:58:19', NULL),
(35, '2018-09-20', '20/09/2018', 4, 'tadesse', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-29 11:58:19', NULL),
(36, '2018-09-20', '20/09/2018', 4, 'tadesse', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-29 11:58:19', NULL),
(37, '2018-09-20', '20/09/2018', 4, 'tadesse', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-29 11:58:19', NULL),
(38, '2018-09-20', '20/09/2018', 4, 'tadesse', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-29 11:58:20', NULL),
(39, '2018-09-20', '20/09/2018', 4, 'tadesse', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-29 11:58:20', NULL),
(40, '2018-09-20', '20/09/2018', 4, 'tadesse', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-29 11:58:20', NULL),
(41, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 2, 1, 3, NULL, '2026-05-29 11:59:37', NULL),
(42, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 2, 9, NULL, '2026-05-29 11:59:37', NULL),
(43, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 7, 1, 8, NULL, '2026-05-29 11:59:37', NULL),
(44, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-29 11:59:37', NULL),
(45, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-29 11:59:37', NULL),
(46, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-29 11:59:37', NULL),
(47, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-29 11:59:37', NULL),
(48, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-29 11:59:37', NULL),
(49, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-29 11:59:37', NULL),
(50, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-29 11:59:37', NULL),
(51, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 2, 1, 3, NULL, '2026-05-29 12:03:55', NULL),
(52, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 2, 9, NULL, '2026-05-29 12:03:55', NULL),
(53, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 7, 1, 8, NULL, '2026-05-29 12:03:55', NULL),
(54, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-29 12:03:55', NULL),
(55, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-29 12:03:55', NULL),
(56, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-29 12:03:55', NULL),
(57, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-29 12:03:55', NULL),
(58, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-29 12:03:55', NULL),
(59, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-29 12:03:55', NULL),
(60, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-29 12:03:55', NULL),
(61, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 2, 1, 3, NULL, '2026-05-29 13:55:46', NULL),
(62, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 2, 9, NULL, '2026-05-29 13:55:46', NULL),
(63, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 3, 'ጤና ምርመራ(ሜዳካል)', 7, 1, 8, NULL, '2026-05-29 13:55:46', NULL),
(64, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 3, 'ቤቶች ልማት አስተዳደር', 4, 'የመንግስት ቤት ውል እድሳት', 11, 1, 12, NULL, '2026-05-29 13:55:46', NULL),
(65, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-29 13:55:46', NULL),
(66, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-29 13:55:46', NULL),
(67, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-29 13:55:46', NULL),
(68, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 8, 'የልደት ሰርቲፍኬት ማረጋገጥ', 0, 0, 0, NULL, '2026-05-29 13:55:46', NULL),
(69, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-29 13:55:46', NULL),
(70, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-29 13:55:46', NULL),
(71, '2018-09-20', '20/09/2018', 5, 'kibrom', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 4, 1, 5, NULL, '2026-05-30 07:32:17', NULL),
(72, '2018-09-20', '20/09/2018', 5, 'kibrom', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 2, 9, NULL, '2026-05-30 07:32:17', NULL),
(73, '2018-09-20', '20/09/2018', 5, 'kibrom', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 7, 1, 8, NULL, '2026-05-30 07:32:17', NULL),
(74, '2018-09-20', '20/09/2018', 5, 'kibrom', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-30 07:32:17', NULL),
(75, '2018-09-20', '20/09/2018', 5, 'kibrom', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', -2, 0, -2, NULL, '2026-05-30 07:32:17', NULL),
(76, '2018-09-20', '20/09/2018', 5, 'kibrom', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-30 07:32:17', NULL),
(77, '2018-09-20', '20/09/2018', 5, 'kibrom', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-30 07:32:17', NULL),
(78, '2018-09-20', '20/09/2018', 5, 'kibrom', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-30 07:32:17', NULL),
(79, '2018-09-20', '20/09/2018', 5, 'kibrom', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-30 07:32:17', NULL),
(80, '2018-09-20', '20/09/2018', 5, 'kibrom', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-30 07:32:17', NULL),
(81, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 2, 1, 3, NULL, '2026-05-30 07:59:44', NULL),
(82, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 2, 9, NULL, '2026-05-30 07:59:44', NULL),
(83, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 7, 1, 8, NULL, '2026-05-30 07:59:44', NULL),
(84, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-30 07:59:44', NULL),
(85, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-30 07:59:44', NULL),
(86, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-30 07:59:44', NULL),
(87, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-30 07:59:44', NULL),
(88, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-30 07:59:44', NULL),
(89, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-30 07:59:44', NULL),
(90, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-30 07:59:44', NULL),
(91, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 2, 1, 3, NULL, '2026-05-30 08:06:24', NULL),
(92, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 8, 2, 10, NULL, '2026-05-30 08:06:24', NULL),
(93, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 6, 1, 7, NULL, '2026-05-30 08:06:24', NULL),
(94, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-30 08:06:24', NULL),
(95, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-30 08:06:24', NULL),
(96, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-30 08:06:24', NULL),
(97, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-30 08:06:24', NULL),
(98, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-30 08:06:24', NULL),
(99, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-30 08:06:24', NULL),
(100, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-30 08:06:24', NULL),
(101, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 2, 1, 3, NULL, '2026-05-30 08:22:53', NULL),
(102, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 2, 9, NULL, '2026-05-30 08:22:53', NULL),
(103, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 7, 1, 8, NULL, '2026-05-30 08:22:53', NULL),
(104, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-30 08:22:53', NULL),
(105, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-30 08:22:53', NULL),
(106, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-30 08:22:53', NULL),
(107, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-30 08:22:53', NULL),
(108, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-30 08:22:53', NULL),
(109, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-30 08:22:53', NULL),
(110, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-30 08:22:53', NULL),
(111, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 2, 1, 3, NULL, '2026-05-30 08:28:29', NULL),
(112, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 2, 9, NULL, '2026-05-30 08:28:29', NULL),
(113, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 7, 1, 8, NULL, '2026-05-30 08:28:29', NULL),
(114, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-30 08:28:29', NULL),
(115, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-30 08:28:29', NULL),
(116, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-30 08:28:29', NULL),
(117, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-30 08:28:29', NULL),
(118, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-30 08:28:29', NULL),
(119, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-30 08:28:29', NULL),
(120, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-30 08:28:29', NULL),
(121, '2018-09-22', '22/09/2018', 6, 'tadelu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 1, 1, 2, NULL, '2026-05-30 09:11:15', NULL),
(122, '2018-09-22', '22/09/2018', 6, 'tadelu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 6, 2, 8, NULL, '2026-05-30 09:11:15', NULL),
(123, '2018-09-22', '22/09/2018', 6, 'tadelu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 7, 1, 8, NULL, '2026-05-30 09:11:15', NULL),
(124, '2018-09-22', '22/09/2018', 6, 'tadelu', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-30 09:11:15', NULL),
(125, '2018-09-22', '22/09/2018', 6, 'tadelu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-30 09:11:15', NULL),
(126, '2018-09-22', '22/09/2018', 6, 'tadelu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-30 09:11:15', NULL),
(127, '2018-09-22', '22/09/2018', 6, 'tadelu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-30 09:11:15', NULL),
(128, '2018-09-22', '22/09/2018', 6, 'tadelu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-30 09:11:15', NULL),
(129, '2018-09-22', '22/09/2018', 6, 'tadelu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-30 09:11:15', NULL),
(130, '2018-09-22', '22/09/2018', 6, 'tadelu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-30 09:11:15', NULL),
(131, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 1, 'የመንጃ ፈቃድ እድሳት', 2, 1, 3, NULL, '2026-05-30 09:13:49', NULL),
(132, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 1, 'እሽተሽ', 2, 'የበሎ እድሳት', 7, 2, 9, NULL, '2026-05-30 09:13:49', NULL),
(133, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 2, 'ጤና ቢሮ', 11, 'ጤና ምርመራ', 7, 1, 8, NULL, '2026-05-30 09:13:49', NULL),
(134, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 8, 'ቤቶች ልማት', 4, 'የመንግስት ቤት ውል እድሳት', 1, 1, 2, NULL, '2026-05-30 09:13:49', NULL),
(135, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 5, 'ንግድ ፈቃድ ማደስ', 0, 0, 0, NULL, '2026-05-30 09:13:49', NULL),
(136, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 4, 'ንግድ ቢሮ', 6, 'የንግድ ስራ ፈቃድ', 1, 1, 2, NULL, '2026-05-30 09:13:49', NULL),
(137, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 5, 'ግንባታ ፈቃድ', 7, 'የፕላን ስምምነት', 0, 0, 0, NULL, '2026-05-30 09:13:49', NULL),
(138, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 12, 'የልደት ሰርቲፍኬት', 0, 0, 0, NULL, '2026-05-30 09:13:49', NULL),
(139, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 6, 'የሲቪል ምዝገባ', 9, 'መታወቂያ እድሳት', 0, 0, 0, NULL, '2026-05-30 09:13:49', NULL),
(140, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 7, 'ሲቪል ምዝገባ', 10, 'የጋብቻ', 0, 0, 0, NULL, '2026-05-30 09:13:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL,
  `employee_code` varchar(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `position` varchar(100) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employee_id`, `employee_code`, `full_name`, `position`, `branch_id`, `phone`, `email`, `hire_date`, `status`, `created_at`) VALUES
(1, 'EMP001', 'Wendmu', 'Senior Service Officer', 1, NULL, NULL, NULL, 'active', '2026-05-29 08:57:21'),
(2, 'EMP002', 'Almaz Desta', 'Service Coordinator', 1, NULL, NULL, NULL, 'active', '2026-05-29 08:57:21'),
(3, 'EMP003', 'Tekle Berhan', 'Customer Service Rep', 2, NULL, NULL, NULL, 'active', '2026-05-29 08:57:21'),
(4, 'EMP7190', 'tadesse', NULL, 1, NULL, NULL, NULL, 'active', '2026-05-29 11:58:19'),
(5, 'EMP9799', 'kibrom', NULL, 1, NULL, NULL, NULL, 'active', '2026-05-30 07:32:17'),
(6, 'EMP7204', 'tadelu', NULL, 1, NULL, NULL, NULL, 'active', '2026-05-30 09:11:15');

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE `organizations` (
  `organization_id` int(11) NOT NULL,
  `organization_name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `organizations`
--

INSERT INTO `organizations` (`organization_id`, `organization_name`, `description`, `status`, `created_at`) VALUES
(1, 'እሽተሽ', 'Driver license and vehicle registration authority', 'active', '2026-05-29 08:57:21'),
(2, 'ጤና ቢሮ', 'Health Bureau - Medical examination services', 'active', '2026-05-29 08:57:21'),
(3, 'ቤቶች ልማት አስተዳደር', 'Housing Development Administration', 'active', '2026-05-29 08:57:21'),
(4, 'ንግድ ቢሮ', 'Trade Bureau - Business licensing', 'active', '2026-05-29 08:57:21'),
(5, 'ግንባታ ፈቃድ', 'Construction Permit Authority', 'active', '2026-05-29 08:57:21'),
(6, 'የሲቪል ምዝገባ', 'Civil Registration Agency', 'active', '2026-05-29 08:57:21'),
(7, 'ሲቪል ምዝገባ', NULL, 'active', '2026-05-29 09:00:11'),
(8, 'ቤቶች ልማት', NULL, 'active', '2026-05-29 11:54:23');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `reset_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_summaries`
--

CREATE TABLE `report_summaries` (
  `summary_id` int(11) NOT NULL,
  `report_date` date NOT NULL,
  `ethiopian_date` varchar(20) NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `employee_name` varchar(100) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `branch_name` varchar(100) NOT NULL,
  `total_services_given` int(11) DEFAULT 0,
  `total_services_not_complete` int(11) DEFAULT 0,
  `grand_total` int(11) DEFAULT 0,
  `total_organizations_served` int(11) DEFAULT 0,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_summaries`
--

INSERT INTO `report_summaries` (`summary_id`, `report_date`, `ethiopian_date`, `employee_id`, `employee_name`, `branch_id`, `branch_name`, `total_services_given`, `total_services_not_complete`, `grand_total`, `total_organizations_served`, `submitted_at`) VALUES
(1, '2018-09-20', '20/09/2018', 1, 'Wendmu', 1, 'A-MESOB', 163, 56, 219, 90, '2026-05-30 09:13:49'),
(4, '2018-09-20', '20/09/2018', 4, 'tadesse', 1, 'A-MESOB', 18, 6, 24, 10, '2026-05-29 11:58:20'),
(8, '2018-09-20', '20/09/2018', 5, 'kibrom', 1, 'A-MESOB', 18, 6, 24, 10, '2026-05-30 07:32:17'),
(13, '2018-09-22', '22/09/2018', 6, 'tadelu', 1, 'A-MESOB', 16, 6, 22, 10, '2026-05-30 09:11:15');

-- --------------------------------------------------------

--
-- Table structure for table `service_types`
--

CREATE TABLE `service_types` (
  `service_id` int(11) NOT NULL,
  `service_name` varchar(200) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `expected_documents` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_types`
--

INSERT INTO `service_types` (`service_id`, `service_name`, `category`, `description`, `expected_documents`, `status`, `created_at`) VALUES
(1, 'የመንጃ ፈቃድ እድሳት', 'Driver License', NULL, 'Old license, ID, medical certificate', 'active', '2026-05-29 08:57:21'),
(2, 'የበሎ እድሳት', 'Vehicle Registration', NULL, 'Old registration, insurance, inspection', 'active', '2026-05-29 08:57:21'),
(3, 'ጤና ምርመራ(ሜዳካል)', 'Medical Services', NULL, 'Referral letter, ID', 'active', '2026-05-29 08:57:21'),
(4, 'የመንግስት ቤት ውል እድሳት', 'Housing', NULL, 'Old contract, payment receipt', 'active', '2026-05-29 08:57:21'),
(5, 'ንግድ ፈቃድ ማደስ', 'Business License', NULL, 'Old license, tax clearance', 'active', '2026-05-29 08:57:21'),
(6, 'የንግድ ስራ ፈቃድ', 'Business License', NULL, 'Business plan, ID, rental agreement', 'active', '2026-05-29 08:57:21'),
(7, 'የፕላን ስምምነት', 'Construction', NULL, 'Building plan, title deed', 'active', '2026-05-29 08:57:21'),
(8, 'የልደት ሰርቲፍኬት ማረጋገጥ', 'Civil Registration', NULL, 'Birth certificate, parent ID', 'active', '2026-05-29 08:57:21'),
(9, 'መታወቂያ እድሳት', 'Civil Registration', NULL, 'Old ID, proof of residence', 'active', '2026-05-29 08:57:21'),
(10, 'የጋብቻ', 'Civil Registration', NULL, 'ID, witness statements', 'active', '2026-05-29 08:57:21'),
(11, 'ጤና ምርመራ', NULL, NULL, NULL, 'active', '2026-05-29 11:54:23'),
(12, 'የልደት ሰርቲፍኬት', NULL, NULL, NULL, 'active', '2026-05-29 11:54:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `must_change_password` tinyint(4) DEFAULT 1,
  `full_name` varchar(100) NOT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `role` enum('admin','manager','staff') DEFAULT 'staff',
  `branch_id` int(11) DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password_hash`, `must_change_password`, `full_name`, `employee_id`, `role`, `branch_id`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@mesob.com', '$2y$10$rTkZdHe1IqQ9FDHChtBuBO.BbwV.ny21b9PkdY3eg0Mql9ofvOaUW', 0, 'System Administrator', NULL, 'admin', NULL, 1, '2026-05-30 12:14:24', '2026-05-29 09:09:36', '2026-05-30 09:14:24'),
(2, 'MESOB', 'MESOB@GMAIL.COM', '$2y$10$pPN42bLszuU1caz5JtKq5.j1meaxtmWZjHQyEOcSa.kSB.X5h6u5G', 0, 'WENDMU FENTAYE', NULL, 'staff', NULL, 1, '2026-05-30 12:07:12', '2026-05-29 11:34:01', '2026-05-30 09:07:12'),
(4, 'mesobb', 'we@gmial.com', '$2y$10$A4GHPMDlLXIumIRVOBYjd.6WpCaQ8qGpiLn5.ifeUO3SlkcRH93uu', 0, 'Tadelu', NULL, 'staff', NULL, 1, '2026-05-30 12:13:09', '2026-05-30 09:09:37', '2026-05-30 09:13:09');

-- --------------------------------------------------------

--
-- Table structure for table `user_activity_log`
--

CREATE TABLE `user_activity_log` (
  `activity_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_activity_log`
--

INSERT INTO `user_activity_log` (`activity_id`, `user_id`, `action`, `details`, `ip_address`, `created_at`) VALUES
(1, 1, 'user_login', 'User logged in from IP: ::1', '::1', '2026-05-29 09:14:25'),
(2, 1, 'user_created', 'Created user: MESOB with role: staff', '::1', '2026-05-29 11:34:01'),
(3, 1, 'user_logout', 'User logged out', '::1', '2026-05-29 13:00:05'),
(4, 2, 'user_login', 'User logged in', '::1', '2026-05-29 13:01:40'),
(5, 2, 'password_changed', 'User changed password on first login', '::1', '2026-05-29 13:02:19'),
(6, 2, 'user_logout', 'User logged out', '::1', '2026-05-29 13:33:34'),
(7, 1, 'user_login', 'User logged in', '::1', '2026-05-29 13:35:16'),
(8, 1, 'user_logout', 'User logged out', '::1', '2026-05-29 13:56:00'),
(9, 2, 'user_login', 'User logged in', '::1', '2026-05-29 13:56:17'),
(10, 2, 'user_logout', 'User logged out', '::1', '2026-05-29 14:16:37'),
(11, 1, 'user_login', 'User logged in', '::1', '2026-05-29 14:45:00'),
(12, 1, 'user_logout', 'User logged out', '::1', '2026-05-29 14:47:52'),
(13, 2, 'user_login', 'User logged in', '::1', '2026-05-29 14:48:06'),
(14, 2, 'user_logout', 'User logged out', '::1', '2026-05-29 14:56:08'),
(15, 1, 'user_login', 'User logged in', '::1', '2026-05-29 14:56:24'),
(16, 1, 'user_login', 'User logged in', '::1', '2026-05-30 06:22:47'),
(17, 1, 'user_logout', 'User logged out', '::1', '2026-05-30 06:40:08'),
(18, 1, 'user_login', 'User logged in', '::1', '2026-05-30 06:40:35'),
(19, 1, 'user_logout', 'User logged out', '::1', '2026-05-30 07:21:12'),
(20, 2, 'user_login', 'User logged in', '::1', '2026-05-30 07:28:58'),
(21, 2, 'user_logout', 'User logged out', '::1', '2026-05-30 08:56:58'),
(22, 2, 'user_login', 'User logged in', '::1', '2026-05-30 09:07:12'),
(23, 2, 'user_logout', 'User logged out', '::1', '2026-05-30 09:07:29'),
(24, 1, 'user_login', 'User logged in', '::1', '2026-05-30 09:08:05'),
(25, 1, 'user_logout', 'User logged out', '::1', '2026-05-30 09:08:09'),
(26, 1, 'user_login', 'User logged in', '::1', '2026-05-30 09:08:21'),
(27, 1, 'user_logout', 'User logged out', '::1', '2026-05-30 09:09:53'),
(28, 4, 'user_login', 'User logged in', '::1', '2026-05-30 09:10:06'),
(29, 4, 'password_changed', 'User changed password on first login', '::1', '2026-05-30 09:10:28'),
(30, 4, 'user_logout', 'User logged out', '::1', '2026-05-30 09:11:44'),
(31, 4, 'user_login', 'User logged in', '::1', '2026-05-30 09:13:09'),
(32, 4, 'user_logout', 'User logged out', '::1', '2026-05-30 09:14:05'),
(33, 1, 'user_login', 'User logged in', '::1', '2026-05-30 09:14:24');

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `session_id` varchar(128) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text DEFAULT NULL,
  `last_activity` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branch_id`),
  ADD UNIQUE KEY `branch_code` (`branch_code`);

--
-- Indexes for table `daily_reports`
--
ALTER TABLE `daily_reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `organization_id` (`organization_id`),
  ADD KEY `service_type_id` (`service_type_id`),
  ADD KEY `idx_report_date` (`report_date`),
  ADD KEY `idx_employee` (`employee_id`),
  ADD KEY `idx_branch` (`branch_id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`employee_id`),
  ADD UNIQUE KEY `employee_code` (`employee_code`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `organizations`
--
ALTER TABLE `organizations`
  ADD PRIMARY KEY (`organization_id`),
  ADD UNIQUE KEY `organization_name` (`organization_name`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`reset_id`),
  ADD KEY `idx_token` (`token`),
  ADD KEY `idx_email` (`email`);

--
-- Indexes for table `report_summaries`
--
ALTER TABLE `report_summaries`
  ADD PRIMARY KEY (`summary_id`),
  ADD UNIQUE KEY `unique_report` (`report_date`,`employee_id`,`branch_id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `service_types`
--
ALTER TABLE `service_types`
  ADD PRIMARY KEY (`service_id`),
  ADD UNIQUE KEY `service_name` (`service_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `idx_username` (`username`),
  ADD KEY `idx_email` (`email`);

--
-- Indexes for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `idx_user_activity` (`user_id`,`created_at`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_last_activity` (`last_activity`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `daily_reports`
--
ALTER TABLE `daily_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `organizations`
--
ALTER TABLE `organizations`
  MODIFY `organization_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `reset_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_summaries`
--
ALTER TABLE `report_summaries`
  MODIFY `summary_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `service_types`
--
ALTER TABLE `service_types`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `daily_reports`
--
ALTER TABLE `daily_reports`
  ADD CONSTRAINT `daily_reports_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `daily_reports_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `daily_reports_ibfk_3` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`organization_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `daily_reports_ibfk_4` FOREIGN KEY (`service_type_id`) REFERENCES `service_types` (`service_id`) ON DELETE SET NULL;

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`) ON DELETE SET NULL;

--
-- Constraints for table `report_summaries`
--
ALTER TABLE `report_summaries`
  ADD CONSTRAINT `report_summaries_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `report_summaries_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`) ON DELETE SET NULL;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`) ON DELETE SET NULL;

--
-- Constraints for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  ADD CONSTRAINT `user_activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
