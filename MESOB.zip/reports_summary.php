<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$conn = mysqli_connect("localhost", "root", "", "mesob_db");
if (!$conn) die("Connection failed");

$user_role = $_SESSION['role'] ?? 'staff';
$user_name = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'User';

$total_reports = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM daily_reports"))['c'];
$total_given = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(service_given) as s FROM daily_reports"))['s'];
$total_missing = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(service_not_complete) as s FROM daily_reports"))['s'];
$grand_total = ($total_given ?: 0) + ($total_missing ?: 0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reports Summary</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#edf2f7;
    padding:2px;
    font-size:11px;
}

.container{
    max-width:1200px;
    margin:auto;
    background:#fff;
    border-radius:2px;
    overflow:hidden;
}

.header{
    background:#1f3b57;
    color:#fff;
    padding:6px;
    text-align:center;
}

.header h1{
    font-size:18px;
}

.nav-bar{
    background:#f8fafc;
    padding:4px 8px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
}

.nav-links{
    display:flex;
    gap:3px;
    flex-wrap:wrap;
}

.nav-links a{
    color:#1f3b57;
    text-decoration:none;
    padding:3px 8px;
    border-radius:2px;
    font-size:10px;
}

.nav-links a:hover{
    background:#1f3b57;
    color:#fff;
}

.logout-btn{
    background:#dc3545;
    color:#fff;
    padding:3px 8px;
    border-radius:2px;
    text-decoration:none;
    font-size:10px;
}

.summary-cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(140px,1fr));
    gap:4px;
    padding:4px;
}

.card{
    background:linear-gradient(135deg,#1f3b57,#2c5a7a);
    color:#fff;
    padding:6px;
    border-radius:3px;
    text-align:center;
}

.card h3{
    font-size:11px;
    margin-bottom:2px;
}

.card .number{
    font-size:22px;
    font-weight:bold;
    line-height:1.1;
}

h3{
    font-size:13px;
    padding:0 6px;
}

.table-wrapper{
    padding:4px;
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
    font-size:10px;
}

th{
    background:#1f3b57;
    color:#fff;
    padding:3px 4px;
    border:1px solid #ddd;
    height:22px;
    white-space:nowrap;
}

td{
    padding:2px 4px;
    border:1px solid #ddd;
    height:20px;
    white-space:nowrap;
}

tbody tr:nth-child(even){
    background:#fafafa;
}

tbody tr:hover{
    background:#eef5ff;
}

.footer{
    text-align:center;
    padding:4px;
    color:#666;
    border-top:1px solid #eee;
    font-size:10px;
}

@media(max-width:768px){

    .header h1{
        font-size:15px;
    }

    .nav-links a,
    .logout-btn{
        font-size:9px;
        padding:2px 6px;
    }

    .summary-cards{
        grid-template-columns:repeat(2,1fr);
        gap:2px;
    }

    .card{
        padding:4px;
    }

    .card .number{
        font-size:18px;
    }

    table{
        font-size:9px;
    }

    th,
    td{
        padding:1px 3px;
        height:16px;
    }
}
</style>
</head>
<body>
<div class="container">
    <div class="header"><h1>📊 Reports Summary Dashboard</h1></div>
    <div class="nav-bar">
        <div class="nav-links">
            <?php if($user_role == 'staff'): ?>
                <a href="mesob.php">📝 New Report</a>
                <a href="view_reports.php">📋 View Reports</a>
            <?php else: ?>
                <a href="admin_dashboard.php">📊 Dashboard</a>
                <a href="admin_reports.php">📋 All Reports</a>
                <a href="manage_users.php">👥 Manage Users</a>
            <?php endif; ?>
            <a href="reports_summary.php">📈 Summary</a>
        </div>
        <div>
            <span style="margin-right:15px">👤 <?php echo htmlspecialchars($user_name); ?> (<?php echo strtoupper($user_role); ?>)</span>
            <a href="logout.php" class="logout-btn">🚪 Logout</a>
        </div>
    </div>

    <div class="summary-cards">
        <div class="card"><h3>Total Reports</h3><div class="number"><?php echo $total_reports; ?></div></div>
        <div class="card"><h3>Services Given</h3><div class="number"><?php echo number_format($total_given ?: 0); ?></div></div>
        <div class="card"><h3>Missing Docs</h3><div class="number"><?php echo number_format($total_missing ?: 0); ?></div></div>
        <div class="card"><h3>Grand Total</h3><div class="number"><?php echo number_format($grand_total); ?></div></div>
    </div>

    <h3 style="padding:0 20px;">Monthly Summary</h3>
    <div style="padding:20px; overflow-x:auto;">
        <table>
            <thead><tr><th>Month</th><th>Reports</th><th>Services Given</th><th>Missing Docs</th><th>Total</th></tr></thead>
            <tbody>
                <?php
                $monthly = mysqli_query($conn, "SELECT DATE_FORMAT(report_date, '%Y-%m') as month, COUNT(*) as reports, SUM(service_given) as given, SUM(service_not_complete) as missing, SUM(total_service) as total FROM daily_reports GROUP BY DATE_FORMAT(report_date, '%Y-%m') ORDER BY month DESC LIMIT 12");
                while($row = mysqli_fetch_assoc($monthly)){
                    echo "<tr><td>{$row['month']}</td><td>{$row['reports']}</td><td>{$row['given']}</td><td>{$row['missing']}</td><td>{$row['total']}</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <div class="footer">MESOB HQ Reporting System</div>
</div>
</body>
</html>
<?php mysqli_close($conn); ?>