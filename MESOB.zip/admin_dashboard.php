<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$conn = mysqli_connect("localhost", "root", "", "mesob_db");
if (!$conn) die("Connection failed");

$user_name = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'Admin';

$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM users"))['c'];
$total_reports = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM daily_reports"))['c'];
$total_services = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_service) as s FROM daily_reports"))['s'];
$total_given = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(service_given) as s FROM daily_reports"))['s'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
   <style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#edf2f7;
    padding:1px;
    font-size:10px;
}

.container{
    max-width:1200px;
    margin:auto;
}

.header{
    background:#1f3b57;
    color:#fff;
    padding:2px 4px;
    border-radius:1px;
    margin-bottom:2px;
}

.header h1{
    font-size:15px;
    line-height:1.2;
}

.header p{
    font-size:10px;
}

.stats{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
    gap:1px;
    margin-bottom:2px;
}

.stat-card{
    background:#fff;
    padding:2px;
    border-radius:1px;
    text-align:center;
    box-shadow:0 1px 2px rgba(0,0,0,.08);
}

.stat-card h3{
    font-size:10px;
    margin-bottom:1px;
}

.stat-card .number{
    font-size:20px;
    font-weight:bold;
    color:#1f3b57;
    line-height:1;
}

.nav-links{
    display:flex;
    gap:1px;
    margin-bottom:2px;
    flex-wrap:wrap;
}

.nav-links a{
    background:#fff;
    color:#1f3b57;
    text-decoration:none;
    padding:2px 5px;
    border-radius:1px;
    font-size:10px;
}

.nav-links a:hover{
    background:#1f3b57;
    color:#fff;
}

.warning-box{
    background:#fff3cd;
    color:#856404;
    padding:2px 4px;
    margin-bottom:2px;
    border-radius:1px;
    border-left:1px solid #ffc107;
    font-size:10px;
}

.view-only{
    background:#ffc107;
    color:#856404;
    padding:1px 2px;
    border-radius:1px;
    font-size:9px;
    margin-left:4px;
}

h2{
    font-size:13px;
    margin-bottom:2px;
}

table{
    width:100%;
    border-collapse:collapse;
    background:#fff;
    border-radius:1px;
    overflow:hidden;
    font-size:9px;
}

th{
    background:#1f3b57;
    color:#fff;
    padding:2px 3px;
    border:1px solid #ddd;
    height:18px;
    white-space:nowrap;
}

td{
    padding:1px 3px;
    border:1px solid #ddd;
    height:16px;
    white-space:nowrap;
}

tbody tr:nth-child(even){
    background:#fafafa;
}

tbody tr:hover{
    background:#eef5ff;
}

@media(max-width:768px){

    body{
        font-size:9px;
    }

    .header h1{
        font-size:12px;
    }

    .stat-card .number{
        font-size:16px;
    }

    th,
    td{
        padding:1px 2px;
        height:14px;
        font-size:8px;
    }

    .nav-links a{
        font-size:9px;
        padding:1px 4px;
    }
}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>👑 Admin Dashboard <span class="view-only">VIEW ONLY</span></h1>
        <p>Welcome, <?php echo htmlspecialchars($user_name); ?></p>
    </div>

    <div class="warning-box">
        🔒 <strong>Read Only Access:</strong> You have VIEW ONLY permissions. You cannot create, edit, or delete reports.
    </div>

    <div class="nav-links">
        <a href="admin_dashboard.php">📊 Dashboard</a>
        <a href="admin_reports.php">📋 All Reports</a>
        <a href="reports_summary.php">📈 Summary</a>
        <a href="manage_users.php">👥 Manage Users</a>
        <a href="logout.php">🚪 Logout</a>
    </div>

    <div class="stats">
        <div class="stat-card"><h3>👥 Users</h3><div class="number"><?php echo $total_users; ?></div></div>
        <div class="stat-card"><h3>📋 Reports</h3><div class="number"><?php echo $total_reports; ?></div></div>
        <div class="stat-card"><h3>✅ Services Given</h3><div class="number"><?php echo number_format($total_given ?: 0); ?></div></div>
        <div class="stat-card"><h3>📊 Total Services</h3><div class="number"><?php echo number_format($total_services ?: 0); ?></div></div>
    </div>

    <h2>Recent Reports (Last 10)</h2>
    <table>
        <thead><tr><th>Date</th><th>Employee</th><th>Branch</th><th>Given</th><th>Missing</th><th>Total</th></tr></thead>
        <tbody>
            <?php
            $recent = mysqli_query($conn, "SELECT * FROM daily_reports ORDER BY report_id DESC LIMIT 10");
            while($row = mysqli_fetch_assoc($recent)) {
                echo "<tr><td>{$row['ethiopian_date']}</td><td>{$row['employee_name']}</td><td>{$row['branch_name']}</td><td>{$row['service_given']}</td><td>{$row['service_not_complete']}</td><td><strong>{$row['total_service']}</strong></td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
</body>
</html>
<?php mysqli_close($conn); ?>