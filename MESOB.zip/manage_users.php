<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$conn = mysqli_connect("localhost", "root", "", "mesob_db");
if (!$conn) die("Connection failed");

// Add new user
if(isset($_POST['add_user'])){
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $full_name = trim($_POST['full_name']);
    $role = $_POST['role'];
    
    $insert = "INSERT INTO users (username, email, password_hash, full_name, role, must_change_password) VALUES (?, ?, ?, ?, ?, 1)";
    $stmt = mysqli_prepare($conn, $insert);
    mysqli_stmt_bind_param($stmt, "sssss", $username, $email, $password, $full_name, $role);
    if(mysqli_stmt_execute($stmt)){
        $success = "User added successfully!";
    } else {
        $error = "Username or email already exists!";
    }
}

// Delete user
if(isset($_GET['delete']) && $_GET['delete'] != $_SESSION['user_id']){
    $delete = "DELETE FROM users WHERE user_id = ?";
    $stmt = mysqli_prepare($conn, $delete);
    mysqli_stmt_bind_param($stmt, "i", $_GET['delete']);
    mysqli_stmt_execute($stmt);
    header("Location: manage_users.php");
    exit();
}

$users = mysqli_query($conn, "SELECT * FROM users ORDER BY user_id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
      <style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#edf2f7;
    padding:4px;
    font-size:11px;
}

.container{
    max-width:1200px;
    margin:auto;
    background:#fff;
    border-radius:3px;
    overflow:hidden;
}

.header{
    background:#1f3b57;
    color:#fff;
    padding:8px;
    text-align:center;
}

.header h1{
    font-size:18px;
}

.nav-bar{
    background:#f8fafc;
    padding:4px 8px;
    display:flex;
    gap:4px;
    flex-wrap:wrap;
}

.nav-bar a{
    color:#1f3b57;
    text-decoration:none;
    padding:3px 8px;
    border-radius:2px;
    font-size:11px;
}

.nav-bar a:hover{
    background:#1f3b57;
    color:#fff;
}

.form-container{
    padding:8px;
    background:#f8fafc;
    border-bottom:1px solid #ddd;
}

.form-container h3{
    font-size:13px;
    margin-bottom:5px;
}

.form-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
    gap:5px;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group input,
.form-group select{
    padding:4px 6px;
    border:1px solid #ddd;
    border-radius:2px;
    font-size:11px;
    height:28px;
}

.btn{
    background:#28a745;
    color:white;
    padding:4px 8px;
    border:none;
    border-radius:2px;
    cursor:pointer;
    font-size:11px;
    height:28px;
}

.table-container{
    padding:5px;
    overflow-x:auto;
}

.table-container h3{
    font-size:13px;
    margin-bottom:5px;
}

table{
    width:100%;
    border-collapse:collapse;
    font-size:10px;
}

th{
    background:#1f3b57;
    color:white;
    padding:4px;
    border:1px solid #ddd;
    text-align:left;
    height:24px;
    white-space:nowrap;
}

td{
    padding:3px 4px;
    border:1px solid #ddd;
    text-align:left;
    height:22px;
    white-space:nowrap;
}

tr:nth-child(even){
    background:#fafafa;
}

tr:hover{
    background:#eef5ff;
}

.delete-btn{
    background:#dc3545;
    color:white;
    padding:2px 6px;
    border-radius:2px;
    text-decoration:none;
    font-size:10px;
}

.alert-success{
    background:#d4edda;
    color:#155724;
    padding:5px 8px;
    margin:5px;
    border-radius:2px;
    font-size:11px;
}

.footer{
    text-align:center;
    padding:5px;
    color:#666;
    border-top:1px solid #eee;
    font-size:10px;
}

@media(max-width:768px){

    .header{
        padding:6px;
    }

    .header h1{
        font-size:15px;
    }

    .nav-bar{
        gap:3px;
    }

    .nav-bar a{
        padding:2px 6px;
        font-size:10px;
    }

    .form-grid{
        grid-template-columns:1fr;
    }

    table{
        font-size:9px;
    }

    th,
    td{
        padding:2px 3px;
        height:18px;
    }
}
</style>
    </style>
</head>
<body>
<div class="container">
    <div class="header"><h1>👥 Manage Users</h1></div>
    <div class="nav-bar">
        <a href="admin_dashboard.php">📊 Dashboard</a>
        <a href="admin_reports.php">📋 Reports</a>
        <a href="reports_summary.php">📈 Summary</a>
        <a href="logout.php">🚪 Logout</a>
    </div>

    <?php if(isset($success)): ?>
        <div class="alert-success">✅ <?php echo $success; ?></div>
    <?php endif; ?>

    <div class="form-container">
        <h3>Add New User</h3>
        <form method="POST" class="form-grid">
            <div class="form-group"><input type="text" name="full_name" placeholder="Full Name" required></div>
            <div class="form-group"><input type="text" name="username" placeholder="Username" required></div>
            <div class="form-group"><input type="email" name="email" placeholder="Email" required></div>
            <div class="form-group"><input type="password" name="password" placeholder="Password" required></div>
            <div class="form-group">
                <select name="role">
                    <option value="staff">Staff</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <div class="form-group"><button type="submit" name="add_user" class="btn">➕ Add User</button></div>
        </form>
    </div>

    <div class="table-container">
        <h3>Existing Users</h3>
        <table>
            <thead><tr><th>ID</th><th>Username</th><th>Full Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
                <?php while($user = mysqli_fetch_assoc($users)): ?>
                <tr>
                    <td><?php echo $user['user_id']; ?></td>
                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo ucfirst($user['role']); ?></td>
                    <td><?php echo $user['is_active'] ? '✅ Active' : '❌ Inactive'; ?></td>
                    <td>
                        <?php if($user['user_id'] != $_SESSION['user_id']): ?>
                            <a href="?delete=<?php echo $user['user_id']; ?>" class="delete-btn" onclick="return confirm('Delete user?')">🗑️ Delete</a>
                        <?php else: ?>
                            <span style="color:#999;">Current</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <div class="footer">Admin - User Management</div>
</div>
</body>
</html>
<?php mysqli_close($conn); ?>